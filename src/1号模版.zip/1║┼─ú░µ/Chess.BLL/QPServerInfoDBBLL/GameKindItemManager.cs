using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPServerInfoDBModels;
using Chess.DAL.QPServerInfoDBDAL;

namespace Chess.BLL.QPServerInfoDBBLL
{
    public class GameKindItemManager
    {
        GameKindItemService gamekinditems = new GameKindItemService();
        public bool InsertGameKindItem(GameKindItemModel gamekinditemmodel)
        {
            return gamekinditems.InsertGameKindItem(gamekinditemmodel);
        }
        public bool UpdateGameKindItem(GameKindItemModel gamekinditemmodel)
        {
            return gamekinditems.UpdateGameKindItem(gamekinditemmodel);
        }
        public bool DeleteGameKindItem(int KindID)
        {
            return gamekinditems.DeleteGameKindItem(KindID);
        }
        public List<GameKindItemModel> GetAllGameKindItem()
        {
            return gamekinditems.GetAllGameKindItem();
        }
        public GameKindItemModel GetGameKindItemById(int KindID)
        {
            return gamekinditems.GetGameKindItemById(KindID);
        }
    }
}
