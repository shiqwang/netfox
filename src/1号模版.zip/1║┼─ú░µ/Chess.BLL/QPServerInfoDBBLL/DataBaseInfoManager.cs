using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPServerInfoDBDAL;
using Chess.Models.QPServerInfoDBModels;

namespace Chess.BLL.QPServerInfoDBBLL
{
    public class DataBaseInfoManager
    {
        DataBaseInfoService databaseinfos = new DataBaseInfoService();
        public bool InsertDataBaseInfo(DataBaseInfoModel databaseinfomodel)
        {
            return databaseinfos.InsertDataBaseInfo(databaseinfomodel);
        }
        public bool UpdateDataBaseInfo(DataBaseInfoModel databaseinfomodel)
        {
            return databaseinfos.UpdateDataBaseInfo(databaseinfomodel);
        }
        public bool DeleteDataBaseInfo(string DBAddr)
        {
            return databaseinfos.DeleteDataBaseInfo(DBAddr);
        }
        public List<DataBaseInfoModel> GetAllDataBaseInfo()
        {
            return databaseinfos.GetAllDataBaseInfo();
        }
        public DataBaseInfoModel GetDataBaseInfoByDBAddr(string DBAddr)
        {
            return databaseinfos.GetDataBaseInfoByDBAddr(DBAddr);
        }
    }
}
