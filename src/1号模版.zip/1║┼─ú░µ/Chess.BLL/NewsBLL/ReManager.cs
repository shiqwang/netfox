using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class ReManager
    {
        ReService res = new ReService();
        public bool InsertRe(ReModel remodel)
        {
            return res.InsertRe(remodel);
        }
        public bool UpdateRe(ReModel remodel)
        {
            return res.UpdateRe(remodel);
        }
        public bool DeleteRe(int ID)
        {
            return res.DeleteRe(ID);
        }
        public List<ReModel> GetAllRe()
        {
            return res.GetAllRe();
        }
        public ReModel GetReById(int ID)
        {
            return res.GetReById(ID);
        }
    }
}
