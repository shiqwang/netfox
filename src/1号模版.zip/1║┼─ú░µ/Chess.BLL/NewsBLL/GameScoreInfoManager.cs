using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using Chess.DAL.NewsDAL;

namespace Chess.BLL.NewsBLL
{
    public class GameScoreInfoManager
    {
        GameScoreInfoService gamescoreinfos = new GameScoreInfoService();
        public bool InsertGameScoreInfo(GameScoreInfoModel gamescoreinfo)
        {
            return gamescoreinfos.InsertGameScoreInfo(gamescoreinfo);
        }
        public bool UpdateGameScoreInfo(GameScoreInfoModel gamescoreinfo)
        {
            return gamescoreinfos.UpdateGameScoreInfo(gamescoreinfo);
        }
        public bool DeleteGameScoreInfo(int G_id)
        {
            return gamescoreinfos.DeleteGameScoreInfo(G_id);
        }
        public List<GameScoreInfoModel> GetAllGameScoreInfo()
        {
            return gamescoreinfos.GetAllGameScoreInfo();
        }
        public GameScoreInfoModel GetGameScoreInfoById(int G_id)
        {
            return gamescoreinfos.GetGameScoreInfoById(G_id);
        }
    }
}
