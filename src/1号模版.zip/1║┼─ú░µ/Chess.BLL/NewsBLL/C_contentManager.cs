using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class C_contentManager
    {
        C_contentService C_contents = new C_contentService();
        public bool InsertC_content(C_contentModel contentmodel)
        {
            return C_contents.InsertC_content(contentmodel);
        }
        public bool UpdateC_content(C_contentModel contentmodel)
        {
            return C_contents.UpdateC_content(contentmodel);
        }
        public bool DeleteC_content(int C_id)
        {
            return C_contents.DeleteC_content(C_id);
        }
        public List<C_contentModel> GetAllC_content()
        {
            return C_contents.GetAllC_content();
        }
        public C_contentModel GetC_contentByID(int C_id)
        {
            return C_contents.GetC_contentByID(C_id);
        }
    }
}
