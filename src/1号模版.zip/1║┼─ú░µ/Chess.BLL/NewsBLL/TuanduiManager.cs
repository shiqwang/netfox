using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class TuanduiManager
    {
        TuanduiService tuanduis = new TuanduiService();
        public bool InsertTuandui(TuanduiModel tuanduimodel)
        {
            return tuanduis.InsertTuandui(tuanduimodel);
        }
        public bool UpdateTuandui(TuanduiModel tuanduimodel)
        {
            return tuanduis.UpdateTuandui(tuanduimodel);
        }
        public bool DeleteTuandui(int T_id)
        {
            return tuanduis.DeleteTuandui(T_id);
        }
        public List<TuanduiModel> GetAllTuandui()
        {
            return tuanduis.GetAllTuandui();
        }
        public TuanduiModel GetTuanduiByID(int T_id)
        {
            return tuanduis.GetTuanduiByID(T_id);
        }
    }
}
