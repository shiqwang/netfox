﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class GuanggaoManager
    {
        GuanggaoService guanggaos = new GuanggaoService();
        public bool InsertGuanggao(GuanggaoModel guanggaomodel)
        {
            return guanggaos.InsertGuanggao(guanggaomodel);
        }
        public bool UpdateGuanggao(GuanggaoModel guanggaomodel)
        {
            return guanggaos.UpdateGuanggao(guanggaomodel);
        }
        public bool DeleteGuanggao(int G_id)
        {
            return guanggaos.DeleteGuanggao(G_id);
        }
        public List<GuanggaoModel> GetAllGuanggao()
        {
            return guanggaos.GetAllGuanggao();
        }
        public GuanggaoModel GetGuanggaoById(int G_id)
        {
            return guanggaos.GetGuanggaoById(G_id);
        }
    }
}
