using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class HdManager
    {
        HdService hds = new HdService();
        public List<HdModel> GetHdByTypeId(int typeid)
        {
            return hds.GetHdByTypeId(typeid);
        }
        public HdModel GetHdById(int id)
        {
            return hds.GetHdById(id);
        }
        public List<HdModel> GetHdNewUserHelpByTypeId(int typeid)
        {
            return hds.GetHdNewUserHelpByTypeId(typeid);
        }
        public List<HdModel> GetHdListByTypeId(int typeid)
        {
            return hds.GetHdListByTypeId(typeid);
        }
        public List<HdModel> GetHdList(int typeID, int? top)
        {
            return hds.GetHdList(typeID, top);
        }

        public List<HdModel> GetHdList(int? top)
        {
            return hds.GetHdList(top);
        }

        public List<HdModel> GetHdList()
        {
            return hds.GetHdList();
        }
        public List<HdModel> GetHdListtop5(int typeid)
        {
            return hds.GetHdListtop5(typeid);
        }
        public List<HdModel> GetHdListRight(int typeID, int? top)
        {
            return hds.GetHdListRight(typeID, top);
        }
        public List<HdModel> GetHdNewsById(int id)
        {
            return hds.GetHdNewsById(id);
        }
        public List<HdModel> GetHdList1(int typeid)
        {
            return hds.GetHdList(typeid);
        }

       
    }
}
