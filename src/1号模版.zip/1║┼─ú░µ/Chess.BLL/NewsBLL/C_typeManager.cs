using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class C_typeManager
    {
        C_typeService C_types = new C_typeService();
        public bool InsertC_type(C_typeModel typemodel)
        {
            return C_types.InsertC_type(typemodel);
        }
        public bool UpdateC_type(C_typeModel typemodel)
        {
            return C_types.UpdateC_type(typemodel);
        }
        public bool DeleteC_type(int ID)
        {
            return C_types.DeleteC_type(ID);
        }
        public List<C_typeModel> GetAllC_type()
        {
            return C_types.GetAllC_type();
        }
        public C_typeModel GetC_typeByID(int ID)
        {
            return C_types.GetC_typeByID(ID);
        }
    }
}
