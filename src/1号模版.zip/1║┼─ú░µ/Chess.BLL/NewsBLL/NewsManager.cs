﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using Chess.DAL.NewsDAL;

namespace Chess.BLL.NewsBLL
{
    public class NewsManager
    {
        NewsService newss = new NewsService();
        public bool InsertNews(NewsModel newsmodel)
        {
            return newss.InsertNews(newsmodel);
        }
        public bool UpdateNews(NewsModel newsmodel)
        {
            return newss.UpdateNews(newsmodel);
        }
        public bool DeleteNews(int id)
        {
            return newss.DeleteNews(id);
        }
        public List<NewsModel> GetAllNews()
        {
            return newss.GetAllNews();
        }
        public NewsModel GetNewsById(int id)
        {
            return newss.GetNewsById(id);
        }
        public List<NewsModel> GetNewsByClasscode(string classcode)
        {
            return newss.GetNewsByClasscode(classcode);
        }
    }
}
