using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class AdminManager
    {
        AdminService admins = new AdminService();
        public bool InsertAdmin(AdminModel adminmodel)
        {
            return admins.InsertAdmin(adminmodel);
        }
        public bool UpdateAdmin(AdminModel adminmodel)
        {
            return admins.UpdateAdmin(adminmodel);
        }
        public bool DeleteAdmin(int id)
        {
            return admins.DeleteAdmin(id);
        }
        public List<AdminModel> GetAllAdmin()
        {
            return admins.GetAllAdmin();
        }
        public AdminModel GetAllAdminByID(int id)
        {
            return admins.GetAllAdminByID(id);
        }
    }
}
