using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class Wm_ggManager
    {
        Wm_ggService wm_ggs = new Wm_ggService();
        public bool InsertWm_gg(Wm_ggModel wm_ggmodel)
        {
            return wm_ggs.InsertWm_gg(wm_ggmodel);
        }
        public bool UpdateWm_gg(Wm_ggModel wm_ggmodel)
        {
            return wm_ggs.UpdateWm_gg(wm_ggmodel);
        }
        public bool DeleteWm_gg(int t_id)
        {
            return wm_ggs.DeleteWm_gg(t_id);
        }
        public List<Wm_ggModel> GetAllWm_gg()
        {
            return wm_ggs.GetAllWm_gg();
        }
        public Wm_ggModel GetWm_ggById(int t_id)
        {
            return wm_ggs.GetWm_ggById(t_id);
        }
    }
}
