using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class JiangpinManager
    {
        JiangpinService jiangpins = new JiangpinService();
        public bool InsertJiangpin(JiangpinModel jiangpinmodel)
        {
            return jiangpins.InsertJiangpin(jiangpinmodel);
        }
        public bool UpdateJiangpin(JiangpinModel jiangpinmodel)
        {
            return jiangpins.UpdateJiangpin(jiangpinmodel);
        }
        public bool DeleteJiangpin(int C_id)
        {
            return jiangpins.DeleteJiangpin(C_id);
        }
        public List<JiangpinModel> GetAllJiangpin()
        {
            return jiangpins.GetAllJiangpin();
        }
        public JiangpinModel GetJiangpinByID(int C_id)
        {
            return jiangpins.GetJiangpinByID(C_id);
        }
    }
}
