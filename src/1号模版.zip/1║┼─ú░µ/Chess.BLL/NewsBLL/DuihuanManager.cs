using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class DuihuanManager
    {
        DuihuanService duihuans = new DuihuanService();
        public bool InsertDuihuan(DuihuanModel duihuanmodel)
        {
            return duihuans.InsertDuihuan(duihuanmodel);
        }
        public bool UpdateDuihuan(DuihuanModel duihuanmodel)
        {
            return duihuans.UpdateDuihuan(duihuanmodel);
        }
        public bool DeleteDuihuan(int id)
        {
            return duihuans.DeleteDuihuan(id);
        }
        public List<DuihuanModel> GetAllDuihuan()
        {
            return duihuans.GetAllDuihuan();
        }
        public DuihuanModel GetDuihuanById(int id)
        {
            return duihuans.GetDuihuanById(id);
        }
    }
}
