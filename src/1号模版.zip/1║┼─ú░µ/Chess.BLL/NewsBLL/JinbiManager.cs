using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class JinbiManager
    {
        JinbiService jinbis = new JinbiService();
        public bool InsertJinbi(JinbiModel jinbimodel)
        {
            return jinbis.InsertJinbi(jinbimodel);
        }
        public bool UpdateJinbi(JinbiModel jinbimodel)
        {
            return jinbis.UpdateJinbi(jinbimodel);
        }
        public bool DeleteJinbi(int id)
        {
            return jinbis.DeleteJinbi(id);
        }
        public List<JinbiModel> GetAllJinbi()
        {
            return jinbis.GetAllJinbi();
        }
        public JinbiModel GetJinbiById(int id)
        {
            return jinbis.GetJinbiById(id);
        }
    }
}
