using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class MatchUserInfoManager
    {
        MatchUserInfoService matchuserinfos = new MatchUserInfoService();
        public bool InsertMatchUserInfo(MatchUserInfoModel matchuserinfo)
        {
            return matchuserinfos.InsertMatchUserInfo(matchuserinfo);
        }
        public bool UpdateMatchUserInfo(MatchUserInfoModel matchuserinfomodel)
        {
            return matchuserinfos.UpdateMatchUserInfo(matchuserinfomodel);
        }
        public bool DeleteMatchUserInfo(int UserID)
        {
            return matchuserinfos.DeleteMatchUserInfo(UserID);
        }
        public List<MatchUserInfoModel> GetAllMatchUserInfo()
        {
            return matchuserinfos.GetAllMatchUserInfo();
        }
        public MatchUserInfoModel GetMatchUserInfoById(int UserID)
        {
            return matchuserinfos.GetMatchUserInfoById(UserID);
        }
    }
}
