using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class JiazManager
    {
        JiazService jiazs = new JiazService();
        public bool InsertJiaz(JiazModel jiazmodel)
        {
            return jiazs.InsertJiaz(jiazmodel);
        }
        public bool UpdateJiaz(JiazModel jiazmodel)
        {
            return jiazs.UpdateJiaz(jiazmodel);
        }
        public bool DeleteJiaz(int J_id)
        {
            return jiazs.DeleteJiaz(J_id);
        }
        public List<JiazModel> GetAllJiaz()
        {
            return jiazs.GetAllJiaz();
        }
        public JiazModel GetJiazById(int J_id)
        {
            return jiazs.GetJiazById(J_id);
        }
    }
}
