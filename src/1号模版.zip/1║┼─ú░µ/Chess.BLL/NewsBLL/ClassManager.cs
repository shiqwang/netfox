using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.NewsDAL;
using Chess.Models.NewsModels;

namespace Chess.BLL.NewsBLL
{
    public class ClassManager
    {
        ClassService classs = new ClassService();
        public bool InsertClass(ClassModel classmodel)
        {
            return classs.InsertClass(classmodel);
        }
        public bool UpdateClass(ClassModel classmodel)
        {
            return classs.UpdateClass(classmodel);
        }
        public bool DeleteClass(int id)
        {
            return classs.DeleteClass(id);
        }
        public List<ClassModel> GetAllClass()
        {
            return classs.GetAllClass();
        }
        public ClassModel GetClassById(int id)
        {
            return classs.GetClassById(id);
        }
    }
}
