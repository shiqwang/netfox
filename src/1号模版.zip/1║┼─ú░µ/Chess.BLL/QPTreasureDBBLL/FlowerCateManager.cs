using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class FlowerCateManager
    {
        FlowerCateService flowercates = new FlowerCateService();
        public bool InsertFlowerCate(FlowerCateModel flowercatemodel)
        {
            return flowercates.InsertFlowerCate(flowercatemodel);
        }
        public bool UpdateFlowerCate(FlowerCateModel flowercatemodel)
        {
            return flowercates.UpdateFlowerCate(flowercatemodel);
        }
        public bool DeleteFlowerCate(int ID)
        {
            return flowercates.DeleteFlowerCate(ID);
        }
        public List<FlowerCateModel> GetAllFlowerCate()
        {
            return flowercates.GetAllFlowerCate();
        }
        public FlowerCateModel GetFlowerCateByID(int ID)
        {
            return flowercates.GetFlowerCateByID(ID);
        }
    }
}
