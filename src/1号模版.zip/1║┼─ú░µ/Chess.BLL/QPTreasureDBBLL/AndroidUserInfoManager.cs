using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class AndroidUserInfoManager
    {
        AndroidUserInfoService androiduserinfos = new AndroidUserInfoService();
        public bool InsertAndroidUserInfo(AndroidUserInfoModel androiduserinfomodel)
        {
            return androiduserinfos.InsertAndroidUserInfo(androiduserinfomodel);
        }
        public bool UpdateAndroidUserInfo(AndroidUserInfoModel androiduserinfomodel)
        {
            return androiduserinfos.UpdateAndroidUserInfo(androiduserinfomodel);
        }
        public bool DeleteAndroidUserInfo(int UserID, int KindID, int ServerID)
        {
            return androiduserinfos.DeleteAndroidUserInfo(UserID, KindID, ServerID);
        }
        public List<AndroidUserInfoModel> GetAllAndroidUserInfo()
        {
            return androiduserinfos.GetAllAndroidUserInfo();
        }
        public List<AndroidUserInfoModel> GetAndroidUserInfoModel(int UserID, int KindID, int ServerID)
        {
            return androiduserinfos.GetAndroidUserInfoModel(UserID, KindID, ServerID);
        }
    }
}
