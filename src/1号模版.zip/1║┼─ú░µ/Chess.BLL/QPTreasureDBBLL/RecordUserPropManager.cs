using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class RecordUserPropManager
    {
        RecordUserPropService recorduserprops = new RecordUserPropService();
        public bool InsertRecordUserProp(RecordUserPropModel recorduserpropmodel)
        {
            return recorduserprops.InsertRecordUserProp(recorduserpropmodel);
        }
        public bool UpdateRecordUserProp(RecordUserPropModel recorduserpropmodel)
        {
            return recorduserprops.UpdateRecordUserProp(recorduserpropmodel);
        }
        public bool DeleteRecordUserProp(int RecordID)
        {
            return recorduserprops.DeleteRecordUserProp(RecordID);
        }
        public List<RecordUserPropModel> GetAllRecordUserProp()
        {
            return recorduserprops.GetAllRecordUserProp();
        }
        public RecordUserPropModel GetRecordUserPropById(int RecordID)
        {
            return recorduserprops.GetRecordUserPropById(RecordID);
        }
    }
}
