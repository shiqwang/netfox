using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class GameShopCateManager
    {
        GameShopCateService gameshopcates = new GameShopCateService();
        public bool InsertGameShopCate(GameShopCateModel gameshopcatemodel)
        {
            return gameshopcates.InsertGameShopCate(gameshopcatemodel);
        }
        public bool UpdateGameShopCate(GameShopCateModel gameshopcatemodel)
        {
            return gameshopcates.UpdateGameShopCate(gameshopcatemodel);
        }
        public bool DeleteGameShopCate(int CateID)
        {
            return gameshopcates.DeleteGameShopCate(CateID);
        }
        public List<GameShopCateModel> GetAllGameShopCate()
        {
            return gameshopcates.GetAllGameShopCate();
        }
        public GameShopCateModel GetGameShopCateById(int CateID)
        {
            return gameshopcates.GetGameShopCateById(CateID);
        }
    }
}
