using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class SystemStreamInfoManager
    {
        SystemStreamInfoService systemstreaminfos = new SystemStreamInfoService();
        public bool InsertSystemStreamInfo(SystemStreamInfoModel systemstreaminfomodel)
        {
            return systemstreaminfos.InsertSystemStreamInfo(systemstreaminfomodel);
        }
        public bool UpdateSystemStreamInfo(SystemStreamInfoModel systemstreaminfomodel)
        {
            return systemstreaminfos.UpdateSystemStreamInfo(systemstreaminfomodel);
        }
        public bool DeleteSystemStreamInfo(int DateID, int KindID, int ServerID)
        {
            return systemstreaminfos.DeleteSystemStreamInfo(DateID, KindID, ServerID);
        }
        public List<SystemStreamInfoModel> GetAllSystemStreamInfo()
        {
            return systemstreaminfos.GetAllSystemStreamInfo();
        }
        public List<SystemStreamInfoModel> GetSystemStreamInfo(int DateID, int KindID, int ServerID)
        {
            return systemstreaminfos.GetSystemStreamInfo(DateID, KindID, ServerID);
        }
    }
}
