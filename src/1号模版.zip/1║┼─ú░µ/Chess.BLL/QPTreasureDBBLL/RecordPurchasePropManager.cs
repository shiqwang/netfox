using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class RecordPurchasePropManager
    {
        RecordPurchasePropService recordpurchaseprops = new RecordPurchasePropService();
        public bool InsertRecordPurchaseProp(RecordPurchasePropModel recordpurchasepropmodel)
        {
            return recordpurchaseprops.InsertRecordPurchaseProp(recordpurchasepropmodel);
        }
        public bool UpdateRecordPurchaseProp(RecordPurchasePropModel recordpurchasepropmodel)
        {
            return recordpurchaseprops.UpdateRecordPurchaseProp(recordpurchasepropmodel);
        }
        public bool DeleteRecordPurchaseProp(int RecordID)
        {
            return recordpurchaseprops.DeleteRecordPurchaseProp(RecordID);
        }
        public List<RecordPurchasePropModel> GetAllRecordPurchaseProp()
        {
            return recordpurchaseprops.GetAllRecordPurchaseProp();
        }
        public RecordPurchasePropModel GetRecordPurchasePropById(int RecordID)
        {
            return recordpurchaseprops.GetRecordPurchasePropById(RecordID);
        }
        public RecordPurchasePropModel GetRecordPurchasePropByUserID(int UserID)
        {
            return recordpurchaseprops.GetRecordPurchasePropByUserID(UserID);
        }
        public bool DeleteByUserID(int UserID)
        {
            return recordpurchaseprops.DeleteByUserID(UserID);
        }
    }
}
