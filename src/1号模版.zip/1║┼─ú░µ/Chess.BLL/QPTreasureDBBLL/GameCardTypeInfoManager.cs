using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class GameCardTypeInfoManager
    {
        GameCardTypeInfoService gamecardtypeinfos = new GameCardTypeInfoService();
        public GameCardTypeInfoModel GetGameCardTypeInfoByID(int cardid)
        {
            return gamecardtypeinfos.GetGameCardTypeInfoByID(cardid);
        }
    }
}
