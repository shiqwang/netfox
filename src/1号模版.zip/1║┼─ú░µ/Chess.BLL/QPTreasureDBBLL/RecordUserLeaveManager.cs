using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPServerInfoDBModels
{
    public class DataBaseInfoModel
    {
        private string _dbaddr;
        private int _dbport;
        private string _dbuser;
        private string _dbpassword;
        private string _information;
        /// <summary>
        /// ���ݿ��ַ
        /// </summary>
        public string DBAddr
        {
            set { _dbaddr = value; }
            get { return _dbaddr; }
        }
        /// <summary>
        /// ���ݿ�˿�
        /// </summary>
        public int DBPort
        {
            set { _dbport = value; }
            get { return _dbport; }
        }
        /// <summary>
        /// ���ݿ��û�
        /// </summary>
        public string DBUser
        {
            set { _dbuser = value; }
            get { return _dbuser; }
        }
        /// <summary>
        /// ���ݿ�����
        /// </summary>
        public string DBPassword
        {
            set { _dbpassword = value; }
            get { return _dbpassword; }
        }
        /// <summary>
        /// ��ע��Ϣ
        /// </summary>
        public string Information
        {
            set { _information = value; }
            get { return _information; }
        }
    }
}
