using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class RecordFlowerGrantManager
    {
        RecordFlowerGrantService recordflowergrants = new RecordFlowerGrantService();
        public bool InsertRecordFlowerGrant(RecordFlowerGrantModel recordflowergrantmodel)
        {
           return recordflowergrants.InsertRecordFlowerGrant(recordflowergrantmodel);
        }
        public bool UpdateRecordFlowerGrant(RecordFlowerGrantModel recordflowergrantmodel)
        {
           return recordflowergrants.UpdateRecordFlowerGrant(recordflowergrantmodel);
        }
        public bool DeleteRecordFlowerGrant(int RecordID)
        {
           return recordflowergrants.DeleteRecordFlowerGrant(RecordID);
        }
        public List<RecordFlowerGrantModel> GetAllRecordFlowerGrant()
        {
           return recordflowergrants.GetAllRecordFlowerGrant();
        }
        public RecordFlowerGrantModel GetRecordFlowerGrantById(int RecordID)
        {
           return recordflowergrants.GetRecordFlowerGrantById(RecordID);
        }
    }
}
