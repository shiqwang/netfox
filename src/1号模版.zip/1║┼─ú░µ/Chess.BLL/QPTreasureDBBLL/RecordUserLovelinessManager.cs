using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class RecordUserLovelinessManager
    {
        RecordUserLovelinessService recorduserlovelinesss = new RecordUserLovelinessService();
        public bool InsertRecordUserLoveliness(RecordUserLovelinessModel recorduserlovelinessmodel)
        {
            return recorduserlovelinesss.InsertRecordUserLoveliness(recorduserlovelinessmodel);
        }
        public bool UpdateRecordUserLoveliness(RecordUserLovelinessModel recorduserlovelinessmodel)
        {
            return recorduserlovelinesss.UpdateRecordUserLoveliness(recorduserlovelinessmodel);
        }
        public bool DeleteRecordUserLoveliness(int RecordID)
        {
            return recorduserlovelinesss.DeleteRecordUserLoveliness(RecordID);
        }
        public List<RecordUserLovelinessModel> GetAllRecordUserLoveliness()
        {
            return recorduserlovelinesss.GetAllRecordUserLoveliness();
        }
        public RecordUserLovelinessModel GetRecordUserLovelinessById(int RecordID)
        {
            return recorduserlovelinesss.GetRecordUserLovelinessById(RecordID);
        }
    }
}
