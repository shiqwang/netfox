using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class RecordUserEnterManager
    {
        RecordUserEnterService recorduserenters = new RecordUserEnterService();
        public bool InsertRecordUserEnter(RecordUserEnterModel recorduserentermodel)
        {
            return recorduserenters.InsertRecordUserEnter(recorduserentermodel);
        }
        public bool UpdateRecordUserEnter(RecordUserEnterModel recorduserentermodel)
        {
            return recorduserenters.UpdateRecordUserEnter(recorduserentermodel);
        }
        public bool DeleteRecordUserEnter(int UserID)
        {
            return recorduserenters.DeleteRecordUserEnter(UserID);
        }
        public List<RecordUserEnterModel> GetAllRecordUserEnter()
        {
            return recorduserenters.GetAllRecordUserEnter();
        }
        public RecordUserEnterModel GetRecordUserEnterById(int UserID)
        {
            return recorduserenters.GetRecordUserEnterById(UserID);
        }
        public RecordUserEnterModel GetRecordUserEnterNewByID(int UserID)
        {
            return recorduserenters.GetRecordUserEnterNewByID(UserID);
        }
    }
}
