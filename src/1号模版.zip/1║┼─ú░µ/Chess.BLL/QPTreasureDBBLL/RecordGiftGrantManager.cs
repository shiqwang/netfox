using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class RecordGiftGrantManager
    {
        RecordGiftGrantService recordgiftgrants = new RecordGiftGrantService();
        public bool InsertRecordGiftGrant(RecordGiftGrantModel recordgiftgrantmodel)
        {
            return recordgiftgrants.InsertRecordGiftGrant(recordgiftgrantmodel);
        }
        public bool UpdateRecordGiftGrant(RecordGiftGrantModel recordgiftgrantmodel)
        {
            return recordgiftgrants.UpdateRecordGiftGrant(recordgiftgrantmodel);
        }
        public bool DeleteRecordGiftGrant(int RecordID)
        {
            return recordgiftgrants.DeleteRecordGiftGrant(RecordID);
        }
        public List<RecordGiftGrantModel> GetAllRecordGiftGrant()
        {
            return recordgiftgrants.GetAllRecordGiftGrant();
        }
        public RecordGiftGrantModel GetRecordGiftGrantById(int RecordID)
        {
            return recordgiftgrants.GetRecordGiftGrantById(RecordID);
        }
    }
}
