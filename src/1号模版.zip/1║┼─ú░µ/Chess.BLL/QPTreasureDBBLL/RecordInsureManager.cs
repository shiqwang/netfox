using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class RecordInsureManager
    {
        RecordInsureService recordinsures = new RecordInsureService();
        public bool InsertRecordInsure(RecordInsureModel recordinsuremodel)
        {
            return recordinsures.InsertRecordInsure(recordinsuremodel);
        }
        public bool UpdateRecordInsure(RecordInsureModel recordinsuremodel)
        {
            return recordinsures.UpdateRecordInsure(recordinsuremodel);
        }
        public bool DeleteRecordInsure(int InsureID)
        {
            return recordinsures.DeleteRecordInsure(InsureID);
        }
        public List<RecordInsureModel> GetAllRecordInsure()
        {
            return recordinsures.GetAllRecordInsure();
        }
        public RecordInsureModel GetRecordInsureById(int InsureID)
        {
            return recordinsures.GetRecordInsureById(InsureID);
        }
        public List<RecordInsureModel> GetRecordInsureByName(string name)
        {
            return recordinsures.GetRecordInsureByName(name);
        }
        public List<RecordInsureModel> GetRecordInsureListByName(string Name)
        {
            return recordinsures.GetRecordInsureListByName(Name);
        }
        public List<RecordInsureModel> GetRecordInsureListByID(int UserID)
        {
            return recordinsures.GetRecordInsureListByID(UserID);
        }
        public List<RecordInsureModel> GetRecordInsureListByUserID(int UserID)
        {
            return recordinsures.GetRecordInsureListByUserID(UserID);
        }
        public List<RecordInsureModel> GetRecordInsureListByUserName(string Name)
        {
            return recordinsures.GetRecordInsureListByUserName(Name);
        }
    }
}
