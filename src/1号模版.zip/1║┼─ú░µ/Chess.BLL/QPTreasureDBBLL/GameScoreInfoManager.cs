using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class GameScoreInfoManager
    {
        GameScoreInfoService gamescoreinfos = new GameScoreInfoService();
        public bool InsertGameScoreInfo(GameScoreInfoModel gamescoreinfomodel)
        {
            return gamescoreinfos.InsertGameScoreInfo(gamescoreinfomodel);
        }
        public bool UpdateGameScoreInfo(GameScoreInfoModel gamescoreinfomodel)
        {
            return gamescoreinfos.UpdateGameScoreInfo(gamescoreinfomodel);
        }
        public bool DeleteGameScoreInfo(int UserID)
        {
            return gamescoreinfos.DeleteGameScoreInfo(UserID);
        }
        public List<GameScoreInfoModel> GetAllGameScoreInfo()
        {
            return gamescoreinfos.GetAllGameScoreInfo();
        }
        public GameScoreInfoModel GetGameScoreInfoById(int UserID)
        {
            return gamescoreinfos.GetGameScoreInfoById(UserID);
        }
        public List<GameScoreInfoModel> GetScore()
        {
            return gamescoreinfos.GetScore();
        }
        public List<GameScoreInfoModel> GetScoretop()
        {
            return gamescoreinfos.GetScoretop();
        }
        public bool UpdateScore(int userid, long score, long insurescore)
        {
            return gamescoreinfos.UpdateScore(userid, score, insurescore);
        }
        public bool UpdateInsureScore(int userid, long inscurescore)
        {
            return gamescoreinfos.UpdateInsureScore(userid, inscurescore);
        }
        public bool UpdateScores(int userid, long score)
        {
            return gamescoreinfos.UpdateScores(userid, score);
        }

        public GameScoreInfoModel GetGameScroseInfoByID(int UserID)
        {
            return gamescoreinfos.GetGameScoreInfoById(UserID);
        }
    }
}
