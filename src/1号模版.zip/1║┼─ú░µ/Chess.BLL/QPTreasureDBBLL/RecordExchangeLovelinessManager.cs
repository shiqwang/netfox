using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class RecordExchangeLovelinessManager
    {
        RecordExchangeLovelinessService recordexchangelovelinesss = new RecordExchangeLovelinessService();
        public bool InsertRecordExchangeLoveliness(RecordExchangeLovelinessModel recordexchaneloveliness)
        {
            return recordexchangelovelinesss.InsertRecordExchangeLoveliness(recordexchaneloveliness);
        }
        public bool UpdateRecordExchangeLoveliness(RecordExchangeLovelinessModel recordexchaneloveliness)
        {
            return recordexchangelovelinesss.UpdateRecordExchangeLoveliness(recordexchaneloveliness);
        }
        public bool DeleteRecordExchangeLoveliness(int RecordID)
        {
            return recordexchangelovelinesss.DeleteRecordExchangeLoveliness(RecordID);
        }
        public List<RecordExchangeLovelinessModel> GetAllRecordExchangeLoveliness()
        {
            return recordexchangelovelinesss.GetAllRecordExchangeLoveliness();
        }
        public RecordExchangeLovelinessModel GetRecordExchangeLovelinessById(int RecordID)
        {
            return recordexchangelovelinesss.GetRecordExchangeLovelinessById(RecordID);
        }
    }
}
