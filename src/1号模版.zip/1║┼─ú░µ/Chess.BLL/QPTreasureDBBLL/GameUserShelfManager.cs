using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class GameUserShelfManager
    {
        GameUserShelfService gameusershelfs = new GameUserShelfService();
        public bool InsertGameUserShelf(GameUserShelfModel gameusershelfmodel)
        {
           return  gameusershelfs.InsertGameUserShelf(gameusershelfmodel);
        }
        public bool UpdateGameUserShelf(GameUserShelfModel gameusershelfmodel)
        {
           return  gameusershelfs.UpdateGameUserShelf(gameusershelfmodel);
        }
        public bool DeleteGameUserShelf(int UserID)
        {
           return gameusershelfs.DeleteGameUserShelf(UserID);
        }
        public List<GameUserShelfModel> GetAllGameUserShelf()
        {
            return gameusershelfs.GetAllGameUserShelf();
        }
        public GameUserShelfModel GetGameUserShelfById(int UserID, int CateID)
        {
            return gameusershelfs.GetGameUserShelfById(UserID,CateID);
        }
        public bool UpdateGameUserShelfByCateID(int CateID, long PropCount, string WriteDate)
        {
            return gameusershelfs.UpdateGameUserShelfByCateID(CateID, PropCount, WriteDate);
        }
    }
}
