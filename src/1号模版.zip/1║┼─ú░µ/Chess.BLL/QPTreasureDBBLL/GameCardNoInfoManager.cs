using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class GameCardNoInfoManager
    {
        GameCardNoInfoService gamecardnoinfos = new GameCardNoInfoService();
        public GameCardNoInfoModel GetGameCardNoInfoByCardNo(string cardno)
        {
            return gamecardnoinfos.GetGameCardNoInfoByCardNo(cardno);
        }
        public bool UpdateGameNoInfoByCardNo(string cardno, bool nullity, string usedate, int userid, string username)
        {
            return gamecardnoinfos.UpdateGameNoInfoByCardNo(cardno, nullity, usedate, userid, username);
        }

        public bool GetCardNoBe(string cardno)
        {
            return gamecardnoinfos.GetCardNoBe(cardno);
        }
    }
}
