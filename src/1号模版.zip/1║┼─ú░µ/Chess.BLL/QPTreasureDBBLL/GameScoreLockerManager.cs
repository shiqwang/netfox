using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPTreasureDBDAL;
using Chess.Models.QPTreasureDBModels;

namespace Chess.BLL.QPTreasureDBBLL
{
    public class GameScoreLockerManager
    {
        GameScoreLockerService gamescorelockers = new GameScoreLockerService();
        public bool InsertGameScoreLocker(GameScoreLockerModel gamescorelockermodel)
        {
            return gamescorelockers.InsertGameScoreLocker(gamescorelockermodel);
        }
        public bool UpdateGameScoreLocker(GameScoreLockerModel gamescorelockermodel)
        {
            return gamescorelockers.UpdateGameScoreLocker(gamescorelockermodel);
        }
        public bool DeleteGameScoreLocker(int UserID, int KindID, int ServerID)
        {
            return gamescorelockers.DeleteGameScoreLocker(UserID, KindID, ServerID);
        }
        public List<GameScoreLockerModel> GetAllGameScoreLocker()
        {
            return gamescorelockers.GetAllGameScoreLocker();
        }
        public List<GameScoreLockerModel> GetGameScoreLocker(int UserID, int KindID, int ServerID)
        {
            return gamescorelockers.GetGameScoreLocker(UserID, KindID, ServerID);
        }
    }
}
