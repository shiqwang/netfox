﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPAdminModels;
using Chess.DAL.QPAdminDAL;

namespace Chess.BLL.QPAdminBLL
{
    public class HdManager
    {
        HdService hds = new HdService();
        public List<HdModel> GetHdListByTypeID(int typeID)
        {
            return hds.GetHdlistByTypeID(typeID);
        }
        public List<HdModel> GetHdListByTypeIDLeft(int typeID)
        {
            return hds.GetHdListByTypeIDLeft(typeID);
        }

        public List<HdModel> GetHdList()
        {
            return hds.GetHdList();
        }

        public HdModel GetHdById(int id)
        {
            return hds.GetHdById(id);
        }
    }
}
