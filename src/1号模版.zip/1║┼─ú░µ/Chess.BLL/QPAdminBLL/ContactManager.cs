﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPAdminModels;
using Chess.DAL.QPAdminDAL;

namespace Chess.BLL.QPAdminBLL
{
    public class ContactManager
    {
        ContactService cont = new ContactService();
        public ContactModel GetContact()
        {
            return cont.GetContact();
        }
    }
}
