﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPAdminDAL;
using Chess.Models.QPAdminModels;

namespace Chess.BLL.QPAdminBLL
{
    public class AdInfoManager
    {
        AdInfoService adin = new AdInfoService();
        public AdInfoModel GetAdInfo()
        {
            return adin.GetAdInfo();
        }
    }
}
