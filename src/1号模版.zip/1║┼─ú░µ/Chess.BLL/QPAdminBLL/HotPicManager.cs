﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPAdminModels;
using Chess.DAL.QPAdminDAL;

namespace Chess.BLL.QPAdminBLL
{
    public class HotPicManager
    {
        HotPicService hotpic = new HotPicService();
        public List<HotPicmodel> GetHotPic()
        {
            return hotpic.GetHotPic();
        }
    }
}
