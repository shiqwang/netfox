using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class IndividualDatumManager
    {
        IndividualDatumService individualdatums = new IndividualDatumService();
        public bool InsertIndividualDatum(IndividualDatumModel individualdatummodel)
        {
            return individualdatums.InsertIndividualDatum(individualdatummodel);
        }
        public bool UpdateIndividualDatum(IndividualDatumModel individualdatummodel)
        {
            return individualdatums.UpdateIndividualDatum(individualdatummodel);
        }
        public bool DeleteIndividualDatum(int UserID)
        {
            return individualdatums.DeleteIndividualDatum(UserID);
        }
        public List<IndividualDatumModel> GetAllIndividualDatum()
        {
            return individualdatums.GetAllIndividualDatum();
        }
        public IndividualDatumModel GetIndividualDatumById(int UserID)
        {
            return individualdatums.GetIndividualDatumById(UserID);
        }
    }
}
