using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class SystemStreamInfoManager
    {
        SystemStreamInfoService systemstreaminfos = new SystemStreamInfoService();
        public bool InsertSystemStreamInfo(SystemStreamInfoModel systemstreaminfomodel)
        {
            return systemstreaminfos.InsertSystemStreamInfo(systemstreaminfomodel);
        }
        public bool UpdateSystemStreamInfo(SystemStreamInfoModel systemstreaminfomodel)
        {
            return systemstreaminfos.UpdateSystemStreamInfo(systemstreaminfomodel);
        }
        public bool DeleteSystemStreamInfo(int DateID)
        {
            return systemstreaminfos.DeleteSystemStreamInfo(DateID);
        }
        public List<SystemStreamInfoModel> GetAllSystemStreamInfo()
        {
            return systemstreaminfos.GetAllSystemStreamInfo();
        }
        public SystemStreamInfoModel GetSystemStreamInfoById(int DateID)
        {
            return systemstreaminfos.GetSystemStreamInfoById(DateID);
        }
    }
}
