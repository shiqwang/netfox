using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class ConfineContentManager
    {
        ConfineContentService confinecontents = new ConfineContentService();
        public bool InsertConfineContent(ConfineContentModel confinecontentmodel)
        {
            return confinecontents.InsertConfineContent(confinecontentmodel);
        }
        public bool UpdateConfineContent(ConfineContentModel confinecontentmodel)
        {
            return confinecontents.UpdateConfineContent(confinecontentmodel);
        }
        public bool DeleteConfineContent(string String)
        {
            return confinecontents.DeleteConfineContent(String);
        }
        public List<ConfineContentModel> GetAllConfineContent()
        {
            return confinecontents.GetAllConfineContent();
        }
        public ConfineContentModel GetConfineContentByString(string String)
        {
            return confinecontents.GetConfineContentByString(String);
        }
    }
}
