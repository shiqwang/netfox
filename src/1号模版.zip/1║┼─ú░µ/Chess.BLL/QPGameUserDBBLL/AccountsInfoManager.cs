using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;
using System.Collections;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class AccountsInfoManager
    {
        AccountsInfoService accountsinfos = new AccountsInfoService();
        public bool InsertAccountsInfo(AccountsInfoModel accountsinfomodel)
        {
            return accountsinfos.InsertAccountsInfo(accountsinfomodel);
        }
        public bool UpdateAccountsInfo(AccountsInfoModel accountsinfomodel)
        {
            return accountsinfos.UpdateAccountsInfo(accountsinfomodel);
        }
        public bool DeleteAccountsInfo(int UserID)
        {
            return accountsinfos.DeleteAccountsInfo(UserID);
        }
        public List<AccountsInfoModel> GetAccountsInfoListByUserID(int UserID)
        {
            return accountsinfos.GetAccountsInfoListByUserID(UserID);
        }
        public List<AccountsInfoModel> GetAccountsInfoListByUserName(string UserName)
        {
            return accountsinfos.GetAccountsInfoListByUserName(UserName);
        }
        public List<AccountsInfoModel> GetAllAccountsInfo()
        {
            return accountsinfos.GetAllAccountsInfo();
        }
        public AccountsInfoModel GetAccountsInfoByName(string Name)
        {
            return accountsinfos.GetAccountsInfoByName(Name);
        }
        /// <summary>
        /// �û���¼
        /// </summary>
        /// <param name="Name"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        public string Login(string Name, string Password)
        {
            IList<AccountsInfoModel> ilist = new List<AccountsInfoModel>();
            if ((ilist = accountsinfos.GetAccountsByName(Name)).Count>0)
            {
                AccountsInfoModel accountsinfomodel = (AccountsInfoModel)ilist[0];
                if (accountsinfomodel.LogonPass == Password)
                {
                    return "�ɹ�";
                }
                else
                {
                    return "�������";
                }
            }
            else
            {
                return "�޴��û�";
            }
        }

        /// <summary>
        /// �һ����뷽��
        /// by: lex.lin 
        /// </summary>
        /// <param name="LoginName"></param>
        /// <param name="QQ"></param>
        /// <returns></returns>
        public AccountsInfoModel FindPwd(string LoginName, string QQ)
        {
            IList<AccountsInfoModel> ilist = new List<AccountsInfoModel>();
            if ((ilist = accountsinfos.GetAccountsByName(LoginName)).Count > 0)
            {
                AccountsInfoModel accountsinfomodel = (AccountsInfoModel)ilist[0];
                if (accountsinfomodel.QQ == QQ)
                {
                    return accountsinfomodel;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        /// �Ƿ����
        /// </summary>
        /// <param name="gameid"></param>
        /// <returns></returns>
        public bool IsGameID(int gameid)
        {
            return accountsinfos.IsGameID(gameid);
        }
        /// <summary>
        /// ���ID
        /// </summary>
        /// <returns></returns>
        public AccountsInfoModel GetMaxID()
        {
            return accountsinfos.GetMaxID();
        }
         public AccountsInfoModel GetAccountsInfoById(int UserID)
        {
            return accountsinfos.GetAccountsInfoById(UserID);
        }
        public IList<AccountsInfoModel> GetAccountsByName(string Name)
        {
            return accountsinfos.GetAccountsByName(Name);
        }
        public List<AccountsInfoModel> GetLoveliness()
        {
            return accountsinfos.GetLoveliness();
        }
        public List<AccountsInfoModel> GetScore(int UserID)
        {
            return accountsinfos.GetScore(UserID);
        }
        public bool AddAccountsInfo(AccountsInfoModel accountsinfomodel)
        {
            return accountsinfos.AddAccountsInfo(accountsinfomodel);
        }
        public bool UpdateMemberOrderByUserID(int UserID, int MemberOrder, string MemberOverDate)
        {
            return accountsinfos.UpdateMemberOrderByUserID(UserID, MemberOrder, MemberOverDate);
        }
        public bool UpdateMemberOrderByID(int ID, int MemberOrder)
        {
            return accountsinfos.UpdateMemberOrderByID(ID, MemberOrder);
        }
        public bool UpdateUserInfoByName(string name, string RegAccounts, string password)
        {
            return accountsinfos.UpdateUserInfoByName(name, RegAccounts, password);
        }
        public bool UpdateLastLoginTime(string name, string time)
        {
            return accountsinfos.UpdateLastLoginTime(name, time);
        }
        public bool UpdateAccInfo(string username, string question, string underwrite, int gender, string qq, string mobile,string answer)
        {
            return accountsinfos.UpdateAccInfo(username, question, underwrite, gender, qq, mobile,answer);
        }
        public bool UpdateQuesByName(string name, string ques, string answ)
        {
            return accountsinfos.UpdateQuesByName(name, ques, answ);
        }
        public bool UpdatePassWord(string username, string pwd)
        {
            return accountsinfos.UpdatePassWord(username, pwd);
        }
        public bool UpdateInsurePass(string username, string pwd)
        {
            return accountsinfos.UpdateInsurePass(username, pwd);
        }
        public bool UpdateGameID(string username, int gameid)
        {
            return accountsinfos.UpdateGameID(username, gameid);
        }
        public bool UpdateSpreaderID(string name, string SpreaderID)
        {
            return accountsinfos.UpdateSpreaderID(name, SpreaderID);
        }
        public List<AccountsInfoModel> GetScoretop()
        {
            return accountsinfos.GetScoretop();
        }
        public List<AccountsInfoModel> GetAccountsInfoListBySpreaderID(string SpreaderID)
        {
            return accountsinfos.GetAccountsInfoListBySpreaderID(SpreaderID);
        }
        /// <summary>
        /// ��IP
        /// </summary>
        /// <param name="ip"></param>
        /// <returns></returns>
        public bool isIP(string ip)
        {
            return accountsinfos.isIP(ip);
        }
        /// <summary>
        /// ����ԭgameID
        /// </summary>
        /// <param name="GameID"></param>
        /// <param name="newID"></param>
        public void GetUserInfo(int GameID)
        {
            Chess.BLL.Command.RegCom reg = new Chess.BLL.Command.RegCom();
            int ia = Convert.ToInt32(GetMaxID().UserID);
            int newID = Convert.ToInt32(GetMaxID().UserID) + 99999;
            accountsinfos.GetUserInfo(GameID, reg._isGoodHao(newID));
        }
        public void UpdateLoginInfo(string userName, string ip)
        {
            accountsinfos.UpdateLoginInfo(userName, ip);
        }

        public List<AccountsInfoModel> GetAccountsOrderByLove(int? top, bool desc)
        {
            List<AccountsInfoModel> list = accountsinfos.GetAccountsOrderByLove(top, desc);
            foreach (AccountsInfoModel accountsInfoModel in list)
            {
                if (string.IsNullOrEmpty(accountsInfoModel.RegAccounts))
                    accountsInfoModel.RegAccounts = "_";
                else
                {
                    accountsInfoModel.RegAccounts = accountsInfoModel.RegAccounts.Length > 6
                                                            ? accountsInfoModel.RegAccounts.Substring(0, 5) + "..."
                                                            : accountsInfoModel.RegAccounts;
                }
            }
            return list;
        }

        public bool IsReg(string account)
        {
            return accountsinfos.IsReg(account);
        }

        public bool HasRegAccount(string regAcc)
        {
            return accountsinfos.HasRegAccount(regAcc);
        }

        public bool GetAccountsBe(string username)
        {
            return accountsinfos.GetAccountsBe(username);
        }
    }
}
