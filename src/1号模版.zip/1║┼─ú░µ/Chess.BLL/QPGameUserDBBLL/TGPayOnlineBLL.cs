using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class TGPayOnlineBLL
    {
        TGPayOnlineDAL tgpayonlinedal = new TGPayOnlineDAL();
        public bool InsertTGPayOnline(TGPayOnlineModel tgpayonlinemodel)
        {
            return tgpayonlinedal.InsertTGPayOnline(tgpayonlinemodel);
        }
        public bool UpdateTGPayOnline(int UserID, long UsePayScore, long Score)
        {
            return tgpayonlinedal.UpdateTGPayOnline(UserID, UsePayScore, Score);
        }
        public TGPayOnlineModel GetTGPayOnlineByUserID(int UserID)
        {
            return tgpayonlinedal.GetTGPayOnlineByUserID(UserID);
        }
    }
}
