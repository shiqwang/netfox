using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class ConfineAddressManager
    {
        ConfineAddressService confineaddresss = new ConfineAddressService();
        public bool InsertConfineAddress(ConfineAddressModel confineaddressmodel)
        {
            return confineaddresss.InsertConfineAddress(confineaddressmodel);
        }
        public bool UpdateConfineAddress(ConfineAddressModel confineaddressmodel)
        {
            return confineaddresss.UpdateConfineAddress(confineaddressmodel);
        }
        public bool DeleteConfineAddress(string AddrString)
        {
            return confineaddresss.DeleteConfineAddress(AddrString);
        }
        public List<ConfineAddressModel> GetAllConfineAddress()
        {
            return confineaddresss.GetAllConfineAddress();
        }
        public ConfineAddressModel GetConfineAddressByAddrString(string AddrString)
        {
            return confineaddresss.GetConfineAddressByAddrString(AddrString);
        }
    }
}
