using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class Cls_LogManager
    {
        Cls_LogService cls_logs = new Cls_LogService();
        public bool InsertCls_Log(Cls_LogModel cls_logmodel)
        {
            return cls_logs.InsertCls_Log(cls_logmodel);
        }
        public bool UpdateCls_Log(Cls_LogModel cls_logmodel)
        {
            return cls_logs.UpdateCls_Log(cls_logmodel);
        }
        public bool DeleteCls_Log(int id)
        {
            return cls_logs.DeleteCls_Log(id);
        }
        public List<Cls_LogModel> GetAllCls_Log()
        {
            return cls_logs.GetAllCls_Log();
        }
        public Cls_LogModel GetCls_LogById(int id)
        {
            return cls_logs.GetCls_LogById(id);
        }
    }
}
