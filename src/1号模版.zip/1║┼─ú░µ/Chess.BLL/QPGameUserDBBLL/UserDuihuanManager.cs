using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class UserDuihuanManager
    {
        UserDuihuanService userduihuans = new UserDuihuanService();
        public bool InsertDuihuan(UserDuihuanModel userduihuan)
        {
            return userduihuans.InsertDuihuan(userduihuan);
        }
        public bool UpdateDuihuan(UserDuihuanModel userduihuan)
        {
            return userduihuans.UpdateDuihuan(userduihuan);
        }
        public UserDuihuanModel GetUserDuihuanByName(string Name)
        {
            return userduihuans.GetUserDuihuanByName(Name);
        }
    }
}
