using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class ddManager
    {
        ddService dds = new ddService();
        public List<ddModel> GetAlldd()
        {
            return dds.GetAlldd();
        }
        public List<ddModel> GetddByID(int ID)
        {
            return dds.GetddByID(ID);
        }
        public List<ddModel> GetddByName(string Name)
        {
            return dds.GetddByName(Name);
        }
        public ddModel GetddInfoByID(int ID)
        {
            return dds.GetddInfoByID(ID);
        }
        public ddModel GetddInfoByName(string Name)
        {
            return dds.GetddInfoByName(Name);
        }
        public ddModel GetSumByName(string Name)
        {
            return dds.GetSumByName(Name);
        }
    }
}
