using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class ReserveIdentifierManager
    {
        ReserveIdentifierService reserveidentifiers = new ReserveIdentifierService();
        public bool InsertReserveIdentifier(ReserveIdentifierModel reserveidentifiermodel)
        {
            return reserveidentifiers.InsertReserveIdentifier(reserveidentifiermodel);
        }
        public bool UpdateReserveIdentifier(ReserveIdentifierModel reserveidentifiermodel)
        {
            return reserveidentifiers.UpdateReserveIdentifier(reserveidentifiermodel);
        }
        public bool DeleteReserveIdentifier(int GameID)
        {
            return reserveidentifiers.DeleteReserveIdentifier(GameID);
        }
        public List<ReserveIdentifierModel> GetAllReserveIdentifier()
        {
            return reserveidentifiers.GetAllReserveIdentifier();
        }
        public ReserveIdentifierModel GetReserveIdentifierById(int GameID)
        {
            return reserveidentifiers.GetReserveIdentifierById(GameID);
        }
    }
}
