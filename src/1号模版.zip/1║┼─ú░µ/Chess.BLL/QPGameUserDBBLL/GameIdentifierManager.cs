using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class GameIdentifierManager
    {
        GameIdentifierService gameidentifiers = new GameIdentifierService();
        public bool InsertGameIdentifier(GameIdentifierModel gameidentifiermodel)
        {
            return gameidentifiers.InsertGameIdentifier(gameidentifiermodel);
        }
        public bool UpdateGameIdentifier(GameIdentifierModel gameidentifiermodel)
        {
            return gameidentifiers.UpdateGameIdentifier(gameidentifiermodel);
        }
        public bool DeleteGameIdentifier(int UserID)
        {
            return gameidentifiers.DeleteGameIdentifier(UserID);
        }
        public List<GameIdentifierModel> GetAllGameIdentifier()
        {
            return gameidentifiers.GetAllGameIdentifier();
        }
        public GameIdentifierModel GetGameIdentifierById(int UserID)
        {
            return gameidentifiers.GetGameIdentifierById(UserID);
        }
    }
}
