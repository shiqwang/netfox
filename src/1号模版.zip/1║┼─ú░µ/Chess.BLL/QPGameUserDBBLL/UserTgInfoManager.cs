using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class UserTgInfoManager
    {
        UserTgInfoService usertginfos = new UserTgInfoService();
        public bool InsertUserTgInfo(UserTgInfoModel usertginfomodel)
        {
            return usertginfos.InsertUserTgInfo(usertginfomodel);
        }
        public UserTgInfoModel GetUserTgInfoByTgID(int TgID)
        {
            return usertginfos.GetUserTgInfoByTgID(TgID);
        }
        public List<UserTgInfoModel> GetUserTgByTgID(int TgID)
        {
            return usertginfos.GetUserTgByTgID(TgID);
        }
        public bool UpdateUserTgInfo(int GameID, int PlayTimeCount, int OnLineTimeCount)
        {
            return usertginfos.UpdateUserTgInfo(GameID, PlayTimeCount, OnLineTimeCount);
        }
    }
}
