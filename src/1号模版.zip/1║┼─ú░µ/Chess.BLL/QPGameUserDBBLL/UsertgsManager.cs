using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using Chess.DAL.QPGameUserDBDAL;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class UsertgsManager
    {
        UsertgsService usertgss = new UsertgsService();
        public bool InsertUsertgs(UsertgsModel usertgsmodel)
        {
            return usertgss.InsertUsertgs(usertgsmodel);
        }
        public UsertgsModel GetUsertgByName(string username)
        {
            return usertgss.GetUsertgByName(username);
        }
        public bool UpdateGameID(string username, int gameid)
        {
            return usertgss.UpdateUsertgs(username, gameid);
        }
        public bool UpdateTgScore(string UserName, int TgScore)
        {
            return usertgss.UpdateTgScore(UserName, TgScore);
        }
    }
}
