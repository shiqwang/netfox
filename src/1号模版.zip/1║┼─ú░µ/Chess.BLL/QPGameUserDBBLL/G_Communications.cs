﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class G_Communications
    {
        G_CommunicationsDal dal = new G_CommunicationsDal();
        public bool InsertG_Communications(G_CommunicationsModel model)
        {
            return dal.InsertG_Communications(model);
        }
        public bool UpdateG_Communications(G_CommunicationsModel model)
        {
            return dal.UpdateG_Communications(model);
        }
        public bool DeleteG_Communications(int ID)
        {
            return dal.DeleteG_Communications(ID);
        }
        public G_CommunicationsModel GetModel(int UserID)
        {
            return dal.GetModel(UserID);
        }
    }
}
