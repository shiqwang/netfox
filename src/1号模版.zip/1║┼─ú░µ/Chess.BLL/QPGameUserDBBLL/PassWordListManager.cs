using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class PassWordListManager
    {
        PassWordListService passwordlists = new PassWordListService();
        public bool InsertPassWordList(PassWordListModel passwordlistmodel)
        {
            return passwordlists.InsertPassWordList(passwordlistmodel);
        }
        public bool UpdatePassWordList(PassWordListModel passwordlistmodel)
        {
            return passwordlists.UpdatePassWordList(passwordlistmodel);
        }
        public bool DeletePassWordList(int ID)
        {
            return passwordlists.DeletePassWordList(ID);
        }
        public List<PassWordListModel> GetAllPassWordList()
        {
            return passwordlists.GetAllPassWordList();
        }
        public PassWordListModel GetPassWordListByID(int ID)
        {
            return passwordlists.GetPassWordListByID(ID);
        }
    }
}
