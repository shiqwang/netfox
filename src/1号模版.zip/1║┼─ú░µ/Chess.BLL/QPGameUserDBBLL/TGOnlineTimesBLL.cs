using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class TGOnlineTimesBLL
    {
        TGOnlineTimesDAL tgonlinetimesdal = new TGOnlineTimesDAL();
        public bool InsertTGOnlineTimes(TGOnlineTimesModel tgonlinetimesmodel)
        {
            return tgonlinetimesdal.InsertTGOnlineTimes(tgonlinetimesmodel);
        }
        public bool UpdateTGOnlineTimes(int UserID, int UseOnlineTime, int Count, long Score)
        {
            return tgonlinetimesdal.UpdateTGOnlineTimes(UserID, UseOnlineTime, Count, Score);
        }
        public TGOnlineTimesModel GetTGOnlineTimesByUserID(int UserID)
        {
            return tgonlinetimesdal.GetTGOnlineTimesByUserID(UserID);
        }
    }
}
