using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class ConfineMachineManager
    {
        ConfineMachineService confinemachines = new ConfineMachineService();
        public bool InsertConfineMachine(ConfineMachineModel confinemachinemodel)
        {
            return confinemachines.InsertConfineMachine(confinemachinemodel);
        }
        public bool UpdateConfineMachine(ConfineMachineModel confinemachinemodel)
        {
            return confinemachines.UpdateConfineMachine(confinemachinemodel);
        }
        public bool DeleteConfineMachine(string MachineSerial)
        {
            return confinemachines.DeleteConfineMachine(MachineSerial);
        }
        public List<ConfineMachineModel> GetAllConfineMachine()
        {
            return confinemachines.GetAllConfineMachine();
        }
        public ConfineMachineModel GetConfineMachineByMachineSerial(string MachineSerial)
        {
            return confinemachines.GetConfineMachineByMachineSerial(MachineSerial);
        }
    }
}
