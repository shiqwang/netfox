using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class CustomFaceInfoManager
    {
    }
}
