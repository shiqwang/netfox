using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using Chess.DAL.QPGameUserDBDAL;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class VipidManager
    {
        VipidDAL vipiddal = new VipidDAL();
        public bool InsertVipid(VipidModel vipidmodel)
        {
            return vipiddal.InsertVipid(vipidmodel);
        }
        public List<VipidModel> Search(string where)
        {
            return vipiddal.Search(where);
        }
        public bool IsGameID(int gameid)
        {
            return vipiddal.IsGameID(gameid);
        }
        public VipidModel GetVipidModel(int GameID)
        {
            return vipiddal.GetVipidModel(GameID);
        }
        public bool Update(VipidModel model)
        {
            return vipiddal.Update(model);
        }
    }
}
