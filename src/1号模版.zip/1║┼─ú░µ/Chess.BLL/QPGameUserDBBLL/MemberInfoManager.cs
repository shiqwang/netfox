using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.QPGameUserDBDAL;
using Chess.Models.QPGameUserDBModels;

namespace Chess.BLL.QPGameUserDBBLL
{
    public class MemberInfoManager
    {
        MemberInfoService memberinfos = new MemberInfoService();
        public bool InsertMemberInfo(MemberInfoModel memberinfomodel)
        {
            return memberinfos.InsertMemberInfo(memberinfomodel);
        }
        public bool UpdateMemberInfo(int ID,int MemberOrder)
        {
            return memberinfos.UpdateMemberInfo(ID,MemberOrder);
        }
        public bool DeleteMemberInfo(int UserID, int MemberOrder)
        {
            return memberinfos.DeleteMemberInfo(UserID, MemberOrder);
        }
        public List<MemberInfoModel> GetAllMemberInfo()
        {
            return memberinfos.GetAllMemberInfo();
        }
        public List<MemberInfoModel> GetMemberinfo(int UserID, int MemberOrder)
        {
            return memberinfos.GetMemberinfo(UserID, MemberOrder);
        }
        public MemberInfoModel GetMemberInfoByID(int ID, int MemberOrder)
        {
            return memberinfos.GetMemberInfoByID(ID, MemberOrder);
        }
    }
}
