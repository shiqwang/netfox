using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Text.RegularExpressions;
using System.Web.UI;

#region  ��д��˵��
/************************************/
//��дʱ��:10-08-31
//��д��:General
//˵��:��ϵͳ������ȡ�ַ��������ж��֣�δ��������ԭ���ǹ��˲��ϴ��ںܶ�bug
#endregion

namespace Chess.BLL.Command
{
    public class RegCom
    {
        #region AAAAAA
        public bool AAAAAA(string str)
        {
            if (str.Length == 6)
            {
                if (str.Replace(str.Substring(0, 1), "").Length == 0)
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region ABBBBB
        /// <summary>
        /// �ж�ABBBBB
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public bool ABBBBB(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 1) != str.Substring(1, 1))
                {
                    int Lenght = str.Replace(str.Substring(1, 1), "").Length;
                    if (Lenght == 1)
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region AAAAAB
        public bool AAAAAB(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 5).Replace(str.Substring(0, 1), "").Length == 0)
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region AABBBB
        public bool AABBBB(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 1) == str.Substring(1, 1))
                {
                    if (str.Substring(2, 4).Replace(str.Substring(2, 1), "").Length == 0)
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region AAAABB
        public bool AAAABB(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(4, 1) == str.Substring(5, 1))
                {
                    if (str.Substring(0, 4).Replace(str.Substring(0, 1), "").Length == 0)
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region AAABBB
        public bool AAABBB(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 3).Replace(str.Substring(0, 1), "").Length == 0)
                {
                    if (str.Substring(3, 3).Replace(str.Substring(3, 1), "").Length == 0)
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region ABBBBC
        public bool ABBBBC(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 1) != str.Substring(1, 1) && str.Substring(0, 0) != str.Substring(5, 1) && str.Substring(1, 1) != str.Substring(5, 1))
                {
                    if (str.Substring(1, 4).Replace(str.Substring(1, 1), "").Length == 0)
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region ABCCCC
        public bool ABCCCC(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 1) != str.Substring(1, 1) && str.Substring(0, 1) != str.Substring(2, 2) && str.Substring(1, 1) != str.Substring(2, 2))
                {
                    if (str.Substring(2, 4).Replace(str.Substring(2, 1), "").Length == 0)
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region AABBCC
        public bool AABBCC(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 1) == str.Substring(1, 1) && str.Substring(2, 1) == str.Substring(3, 1) && str.Substring(4, 1) == str.Substring(5, 1))
                {
                    if (str.Substring(0, 1) != str.Substring(2, 1) && str.Substring(2, 1) != str.Substring(4, 1) && str.Substring(4, 1) != str.Substring(0, 1))
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region ABCABC
        public bool ABCABC(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 1) != str.Substring(1, 1) && str.Substring(0, 1) != str.Substring(2, 1) && str.Substring(1, 1) != str.Substring(2, 1))
                {
                    if (str.Substring(0, 3) == str.Substring(3, 3))
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region ABCDEF
        public bool ABCDEF(string str)
        {
            Regex reg = new Regex(@"(?:0(?=1)|1(?=2)|2(?=3)|3(?=4)|4(?=5)|5(?=6)|6(?=7)|7(?=8)|8(?=9)){5}\d");
            return reg.IsMatch(str);
        }
        #endregion

        #region FEDCBA
        public bool FEDCBA(string str)
        {
            char[] charArray = str.ToCharArray();
            Array.Reverse(charArray);
            string reg_ = new string(charArray);

            //Regex reg = new Regex(@"(?:9(?=8)|8(?=7)|7(?=6)|6(?=5)|5(?=4)|4(?=3)|3(?=2)|2(?=1)|1(?=0)){5}\d");
            Regex reg = new Regex(@"(?:0(?=1)|1(?=2)|2(?=3)|3(?=4)|4(?=5)|5(?=6)|6(?=7)|7(?=8)|8(?=9)){5}\d");

            return reg.IsMatch(reg_);
        }
        #endregion

        #region ABBCCC
        public bool ABBCCC(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 1) != str.Substring(1, 1) && str.Substring(1, 1) != str.Substring(3, 1) && str.Substring(3, 1) != str.Substring(0, 1))
                {
                    if (str.Substring(1, 1) == str.Substring(2, 1) && str.Substring(3, 3).Replace(str.Substring(3, 1), "").Length == 0)
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region ABBBCC
        public bool ABBBCC(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 1) != str.Substring(1, 1) && str.Substring(0, 1) != str.Substring(5, 1) && str.Substring(1, 1) != str.Substring(5, 1))
                {
                    if (str.Substring(4, 1) == str.Substring(5, 1))
                    {
                        if (str.Substring(1, 3).Replace(str.Substring(1, 1), "").Length == 0)
                        {
                            return true;
                        }
                        else
                            return false;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region AABBAB
        public bool AABBAB(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 1) == str.Substring(1, 1) && str.Substring(2, 1) == str.Substring(3, 1))
                {
                    if (str.Substring(0, 1) == str.Substring(4, 1) && str.Substring(2, 1) == str.Substring(5, 1))
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region AABBAA
        public bool AABBAA(string str)
        {
            if (str.Length == 6)
            {
                if (str.Substring(0, 2) == str.Substring(4, 2) && str.Substring(0, 2) != str.Substring(2, 2) && str.Substring(0, 1) == str.Substring(1, 1))
                {
                    if (str.Substring(2, 1) == str.Substring(3, 1))
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        #endregion

        #region �����жϷ���
        /// <summary>
        /// �����жϷ���
        /// </summary>
        /// <param name="str">�ַ���</param>
        /// <returns></returns>
        public string istype(string str)
        {
            if (AAAAAA(str))
            {
                return "true," + "30000000" + ",AAAAAA";
            }
            if (ABBBBB(str))
            {
                return "true," + "10000000" + ",ABBBBB";
            }
            if (AAAAAB(str))
            {
                return "true," + "10000000" + ",AAAAAB";
            }
            if (AABBBB(str))
            {
                return "true," + "8000000" + ",AABBBB";
            }
            if (AAAABB(str))
            {
                return "true," + "8000000" + ",AAAABB";
            }
            if (AAABBB(str))
            {
                return "true," + "5000000" + ",AAABBB";
            }
            if (ABBBBC(str))
            {
                return "true," + "5000000" + ",ABBBBC";
            }
            if (ABCCCC(str))
            {
                return "true," + "5000000" + ",ABCCCC";
            }
            if (AABBCC(str))
            {
                return "true," + "5000000" + ",AABBCC";
            }
            if (ABCABC(str))
            {
                return "true," + "5000000" + ",ABCABC";
            }
            if (ABCDEF(str))
            {
                return "true," + "20000000" + ",ABCDEF";
            }
            if (FEDCBA(str))
            {
                return "true," + "20000000" + ",FEDCBA";
            }
            if (ABBCCC(str))
            {
                return "true," + "5000000" + ",ABBCCC";
            }
            if (ABBBCC(str))
            {
                return "true," + "5000000" + ",ABBBCC";
            }
            if (AABBAB(str))
            {
                return "true," + "5000000" + ",AABBAB";
            }
            if (AABBAA(str))
            {
                return "true," + "5000000" + ",AABBAA";
            }
            return "false";
        }
        #endregion

        #region ���
        /// <summary>
        /// ���
        /// </summary>
        /// <param name="gameid"></param>
        /// <returns></returns
        public int isGoodHao(int gameid)
        {
            Chess.BLL.QPGameUserDBBLL.AccountsInfoManager abll = new Chess.BLL.QPGameUserDBBLL.AccountsInfoManager();
            if (istype(gameid.ToString()).IndexOf("false") == -1)
            {
                bool isgameid = false;
                while (isgameid == false)
                {
                    gameid = gameid + 1;
                    if (istype(Convert.ToString(gameid)).IndexOf("false") > -1 && abll.IsGameID(gameid) != true)
                    {
                        isgameid = true;
                    }
                }
                return gameid;
            }
            else
                return gameid;
        }
        public int _isGoodHao(int gameid)
        {
            Chess.BLL.QPGameUserDBBLL.AccountsInfoManager abll= new Chess.BLL.QPGameUserDBBLL.AccountsInfoManager();
            bool isgameid = false;
            while (isgameid == false)
            {
                if(abll.IsGameID(gameid) != true)
                {
                    isgameid =true;
                    gameid = isGoodHao(gameid);
                }
                else
                {
                    gameid++;
                }
            }
            return gameid;
        }
        #endregion
    }

    #region ҳ�洦�����������������
    public class PageHelp
    {
        /// <summary>
        /// ����URLת��
        /// </summary>
        /// <param name="page"></param>
        /// <param name="_str"></param>
        /// <returns></returns>
        public static string Gettong(Page page, string _str)
        {
            return ConvertTool.ToString(page.Request.QueryString[_str]);
        }
        /// <summary>
        /// ת��ΪINT
        /// </summary>
        /// <param name="page"></param>
        /// <param name="_int"></param>
        /// <returns></returns>
        public static int GetInt(Page page, string _int)
        {
            return ConvertTool.ToInt(page.Request.QueryString[_int]);
        }
    }
    #endregion

    #region ת���Ƚ�ʵ��
    public class ConvertTool
    {
        public static string ToString(object obj)
        {
            if (obj != null)
            {
                return obj.ToString();
            }
            return string.Empty;
        }
        public static int ToInt(object obj)
        {
            int result = 0;
            if (obj != null)
            {
                int.TryParse(obj.ToString(), out result);
            }
            return result;
        }
    }
    #endregion
}
