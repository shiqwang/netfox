using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameMatchDB;
using Chess.DAL.QPGameMatchDB;

namespace Chess.BLL.QPGameMatchDB
{
    public class GameScoreInfoManager
    {
        GameScoreInfoService gamescoreinfos = new GameScoreInfoService();
        public bool InsertGameScoreInfo(GameScoreInfoModel gamescoreinfomodel)
        {
            return gamescoreinfos.InsertGameScoreInfo(gamescoreinfomodel);
        }
        public bool UpdateGameScoreInfo(int UserID, int UserRight)
        {
            return gamescoreinfos.UpdateGameScoreInfo(UserID, UserRight);
        }
        public GameScoreInfoModel GetCount()
        {
            return gamescoreinfos.GetCount();
        }
    }
}
