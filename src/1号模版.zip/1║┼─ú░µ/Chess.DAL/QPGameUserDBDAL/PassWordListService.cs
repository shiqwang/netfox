using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class PassWordListService
    {
        public bool InsertPassWordList(PassWordListModel passwordlistmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into PassWordList values (");
            sb.Append(passwordlistmodel.UserID);
            sb.Append(",'");
            sb.Append(passwordlistmodel.Email);
            sb.Append(",'");
            sb.Append(passwordlistmodel.Passw);
            sb.Append(",'");
            sb.Append(passwordlistmodel.Passd);
            sb.Append(",'");
            sb.Append(passwordlistmodel.Code);
            sb.Append(",'");
            sb.Append(passwordlistmodel.Adder);
            sb.Append(",'");
            sb.Append(passwordlistmodel.TelMail);
            sb.Append(",'");
            sb.Append(passwordlistmodel.Txt);
            sb.Append(",'");
            sb.Append(passwordlistmodel.IsCut);
            sb.Append(",'");
            sb.Append(passwordlistmodel.SSDate);
            sb.Append(",'");
            sb.Append(passwordlistmodel.PassWord);
            sb.Append(",'");
            sb.Append(passwordlistmodel.PassWord2);
            sb.Append("')");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdatePassWordList(PassWordListModel passwordlistmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update PassWordList set ");
            sb.Append("UserID='" + passwordlistmodel.UserID + "',");
            sb.Append("Email='" + passwordlistmodel.Email + "',");
            sb.Append("Passw='" + passwordlistmodel.Passw + "',");
            sb.Append("Passd='" + passwordlistmodel.Passd + "',");
            sb.Append("Code='" + passwordlistmodel.Code + "',");
            sb.Append("Adder='" + passwordlistmodel.Adder + "',");
            sb.Append("TelMail='" + passwordlistmodel.TelMail + "',");
            sb.Append("Txt='" + passwordlistmodel.Txt + "',");
            sb.Append("IsCut=" + passwordlistmodel.IsCut + ",");
            sb.Append("SSDate='" + passwordlistmodel.SSDate + "',");
            sb.Append("PassWord='" + passwordlistmodel.PassWord + "',");
            sb.Append("PassWord2='" + passwordlistmodel.PassWord2 + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where ID=" + passwordlistmodel.ID + " ");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeletePassWordList(int ID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from PassWordList ");
            sb.Append(" where ID=" + ID + " ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<PassWordListModel> GetAllPassWordList()
        {
            List<PassWordListModel> list = new List<PassWordListModel>();
            string sql = string.Format("select * from PassWordList");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                PassWordListModel passwordlistmodel = new PassWordListModel();
                passwordlistmodel.ID =(int)dr["ID"];
                passwordlistmodel.UserID = dr["UserID"].ToString();
                passwordlistmodel.Email = dr["Email"].ToString();
                passwordlistmodel.Passw = dr["Passw"].ToString();
                passwordlistmodel.Passd = dr["Passd"].ToString();
                passwordlistmodel.Code = dr["Code"].ToString();
                passwordlistmodel.Adder = dr["Adder"].ToString();
                passwordlistmodel.TelMail = dr["TelMail"].ToString();
                passwordlistmodel.Txt = dr["Txt"].ToString();
                passwordlistmodel.IsCut = (int)dr["IsCut"];
                passwordlistmodel.SSDate = (DateTime)dr["SSDate"];
                passwordlistmodel.PassWord = dr["PassWord"].ToString();
                passwordlistmodel.PassWord2 = dr["PassWord2"].ToString();
                list.Add(passwordlistmodel);
            }
            dr.Close();
            return list;
        }
        public PassWordListModel GetPassWordListByID(int ID)
        {
            string sql = string.Format("select * from PassWordList where ID={0}",ID);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            PassWordListModel passwordlistmodel = new PassWordListModel();
            if (dr.Read())
            {
                passwordlistmodel.ID = (int)dr[0];
                passwordlistmodel.UserID = dr[1].ToString();
                passwordlistmodel.Email = dr[2].ToString();
                passwordlistmodel.Passw = dr[3].ToString();
                passwordlistmodel.Passd = dr[4].ToString();
                passwordlistmodel.Code = dr[5].ToString();
                passwordlistmodel.Adder = dr[6].ToString();
                passwordlistmodel.TelMail = dr[7].ToString();
                passwordlistmodel.Txt = dr[8].ToString();
                passwordlistmodel.IsCut = (int)dr[9];
                passwordlistmodel.SSDate = (DateTime)dr[10];
                passwordlistmodel.PassWord = dr[11].ToString();
                passwordlistmodel.PassWord2 = dr[12].ToString();
            }
            dr.Close();
            return passwordlistmodel;
        }
    }
}
