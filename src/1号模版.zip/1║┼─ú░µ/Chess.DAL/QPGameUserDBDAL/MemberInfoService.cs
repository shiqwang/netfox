using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class MemberInfoService
    {
        public bool InsertMemberInfo(MemberInfoModel memberinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into MemberInfo values (");
            sb.Append(memberinfomodel.UserID);
            sb.Append(",");
            sb.Append(memberinfomodel.MemberOrder);
            sb.Append(",'");
            sb.Append(memberinfomodel.MemberOverDate);
            sb.Append("')");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateMemberInfo(int ID, int MemberOrder)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update MemberInfo set ");
            sb.Append("MemberOverDate=dateadd (" + "m" + ",1, MemberOverDate)");
            sb.Append(" where UserID=" + ID + " and MemberOrder=" + MemberOrder + " ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool DeleteMemberInfo(int UserID, int MemberOrder)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from MemberInfo ");
            sb.Append(" where UserID=" + UserID + " and MemberOrder=" + MemberOrder + " ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public MemberInfoModel GetMemberInfoByID(int ID, int MemberOrder)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from MemberInfo where UserID=");
            sb.Append(ID);
            sb.Append(" and MemberOrder=");
            sb.Append(MemberOrder);
            sb.Append("");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            MemberInfoModel memberinfomodel = new MemberInfoModel();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    memberinfomodel.UserID = (int)dr["UserID"];
                    memberinfomodel.MemberOrder = int.Parse(dr["MemberOrder"].ToString());
                    memberinfomodel.MemberOverDate = dr["MemberOverDate"].ToString();
                }
            }
            dr.Close();
            return memberinfomodel;
        }
        public List<MemberInfoModel> GetAllMemberInfo()
        {
            List<MemberInfoModel> list = new List<MemberInfoModel>();
            string sql = string.Format("select * from MemberInfo");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                MemberInfoModel memberinfomodel = new MemberInfoModel();
                memberinfomodel.UserID = (int)dr["UserID"];
                memberinfomodel.MemberOrder = (int)dr["MemberOrder"];
                memberinfomodel.MemberOverDate = dr["MemberOverDate"].ToString();
                list.Add(memberinfomodel);
            }
            dr.Close();
            return list;
        }
        private MemberInfoModel GetMember(SqlDataReader dr)
        {
            MemberInfoModel memberinfomodel = new MemberInfoModel();
            memberinfomodel.UserID = (int)dr[0];
            memberinfomodel.MemberOrder = (int)dr[1];
            memberinfomodel.MemberOverDate = dr[2].ToString();
            return memberinfomodel;
        }
        public List<MemberInfoModel> GetMemberinfo(int UserID, int MemberOrder)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from MemberInfo ");
            sb.Append(" where UserID=" + UserID + " and MemberOrder=" + MemberOrder + " ");
            List<MemberInfoModel> list = new List<MemberInfoModel>();
            MemberInfoModel memberinfomodel = new MemberInfoModel();
            try
            {
                SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
                while (dr.Read())
                {
                    list.Add(GetMember(dr));
                }
                dr.Close();
                return list;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
