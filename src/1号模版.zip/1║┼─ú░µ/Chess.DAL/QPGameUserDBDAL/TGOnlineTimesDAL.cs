using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class TGOnlineTimesDAL
    {
        public bool InsertTGOnlineTimes(TGOnlineTimesModel tgonlinetimesmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into TGOnlineTimes values (");
            sb.Append(tgonlinetimesmodel.UserID);
            sb.Append(",");
            sb.Append(tgonlinetimesmodel.GameID);
            sb.Append(",'");
            sb.Append(tgonlinetimesmodel.Account);
            sb.Append("',");
            sb.Append(tgonlinetimesmodel.UseOnlineTime);
            sb.Append(",");
            sb.Append(tgonlinetimesmodel.Count);
            sb.Append(",");
            sb.Append(tgonlinetimesmodel.Score);
            sb.Append(")");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateTGOnlineTimes(int UserID, int UseOnlineTime, int Count, long Score)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update TGOnlineTimes set ");
            sb.Append("UseOnlineTime=");
            sb.Append(UseOnlineTime);
            sb.Append(",");
            sb.Append("Count=");
            sb.Append(Count);
            sb.Append(",");
            sb.Append("Score=");
            sb.Append(Score);
            sb.Append(" where UserID=");
            sb.Append(UserID);
            sb.Append("");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public TGOnlineTimesModel GetTGOnlineTimesByUserID(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from TGOnlineTimes where UserID=");
            sb.Append(UserID);
            sb.Append("");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            TGOnlineTimesModel tgonlinetimesmodel = new TGOnlineTimesModel();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    tgonlinetimesmodel.ID = int.Parse(dr["ID"].ToString());
                    tgonlinetimesmodel.UserID = int.Parse(dr["UserID"].ToString());
                    tgonlinetimesmodel.GameID = int.Parse(dr["GameID"].ToString());
                    tgonlinetimesmodel.Account = dr["Account"].ToString();
                    tgonlinetimesmodel.UseOnlineTime = int.Parse(dr["UseOnlineTime"].ToString());
                    tgonlinetimesmodel.Count = int.Parse(dr["Count"].ToString());
                    tgonlinetimesmodel.Score = long.Parse(dr["Score"].ToString());
                }
            }
            dr.Close();
            return tgonlinetimesmodel;
        }
    }
}
