﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class G_CommunicationsDal
    {
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public bool InsertG_Communications(G_CommunicationsModel model)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" insert into G_Communications (");
            sb.Append(" G_QQ,");
            sb.Append(" G_Mobile,");
            sb.Append(" G_UserID");
            sb.Append(")values (");
            sb.Append(model.G_QQ + ",");
            sb.Append(model.G_Mobile + ",");
            sb.Append(model.G_UserID + ")");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateG_Communications(G_CommunicationsModel model)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(" update G_Communications set ");
            sb.Append(" G_QQ='" + model.G_QQ + "',");
            sb.Append(" G_Mobile='" + model.G_Mobile + "',");
            sb.Append(" G_UserID='" + model.G_UserID + "'");
            sb.Append(" where [ID]=" + model.ID);
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0);
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteG_Communications(int ID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from G_Communications ");
            sb.Append(" where [ID]=" + ID + " ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public G_CommunicationsModel GetModel(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            G_CommunicationsModel model = new G_CommunicationsModel();
            sb.Append("select * from G_Communications where G_UserID='");
            sb.Append(UserID);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    model.G_QQ = dr["G_QQ"].ToString();
                    model.G_Mobile = dr["G_Mobile"].ToString();
                    model.G_UserID = (int)dr["G_UserID"];
                    model.ID = (int)dr["ID"];
                }
            }
            dr.Close();
            return model;
        }
    }
}
