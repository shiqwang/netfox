using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class UserDuihuanService
    {
        public bool InsertDuihuan(UserDuihuanModel userduihuan)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into UserDuihuan values (");
            sb.Append(userduihuan.UserID);
            sb.Append(",");
            sb.Append(userduihuan.GameID);
            sb.Append(",'");
            sb.Append(userduihuan.Account);
            sb.Append("','");
            sb.Append(userduihuan.RegAccounts);
            sb.Append("',");
            sb.Append(userduihuan.LastUseTime);
            sb.Append(",");
            sb.Append(userduihuan.LastScore);
            sb.Append(",");
            sb.Append(userduihuan.UseTime);
            sb.Append(",");
            sb.Append(userduihuan.Score);
            sb.Append(")");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateDuihuan(UserDuihuanModel userduihuan)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update UserDuihuan set ");
            sb.Append("UserID=");
            sb.Append(userduihuan.UserID);
            sb.Append(",");
            sb.Append("GameID=");
            sb.Append(userduihuan.GameID);
            sb.Append(",");
            sb.Append("Account='");
            sb.Append(userduihuan.Account);
            sb.Append("',");
            sb.Append("RegAccounts='");
            sb.Append(userduihuan.RegAccounts);
            sb.Append("',");
            sb.Append("LastUseTime=");
            sb.Append(userduihuan.LastUseTime);
            sb.Append(",");
            sb.Append("LastScore=");
            sb.Append(userduihuan.LastScore);
            sb.Append(",");
            sb.Append("UseTime=");
            sb.Append(userduihuan.UseTime);
            sb.Append(",");
            sb.Append("Score=");
            sb.Append(userduihuan.Score);
            sb.Append(" where UserID=");
            sb.Append(userduihuan.UserID);
            sb.Append("");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public UserDuihuanModel GetUserDuihuanByName(string Name)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from UserDuihuan where Account='");
            sb.Append(Name);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            UserDuihuanModel userduihuanmodel = new UserDuihuanModel();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    userduihuanmodel.UserID = (int)dr["UserID"];
                    userduihuanmodel.GameID = (int)dr["GameID"];
                    userduihuanmodel.Account = dr["Account"].ToString();
                    userduihuanmodel.RegAccounts = dr["RegAccounts"].ToString();
                    userduihuanmodel.LastUseTime = (int)dr["LastUseTime"];
                    userduihuanmodel.LastScore = long.Parse(dr["LastScore"].ToString());
                    userduihuanmodel.UseTime = (int)dr["UseTime"];
                    userduihuanmodel.Score = long.Parse(dr["Score"].ToString());
                }
            }
            dr.Close();
            return userduihuanmodel;
        }
    }
}
