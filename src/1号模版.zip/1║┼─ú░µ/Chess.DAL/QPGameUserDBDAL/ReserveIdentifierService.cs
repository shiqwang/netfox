using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class ReserveIdentifierService
    {
        public bool InsertReserveIdentifier(ReserveIdentifierModel reserveidentifiermodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into ReserveIdentifier values (");
            sb.Append(reserveidentifiermodel.IDLevel);
            sb.Append(",'");
            sb.Append(reserveidentifiermodel.Distribute);
            sb.Append("')");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateReserveIdentifier(ReserveIdentifierModel reserveidentifiermodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update ReserveIdentifier set ");
            sb.Append("IDLevel=" + reserveidentifiermodel.IDLevel + ",");
            sb.Append("Distribute=" + (reserveidentifiermodel.Distribute ? 1 : 0) + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where GameID=" + reserveidentifiermodel.GameID + " ");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteReserveIdentifier(int GameID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from ReserveIdentifier ");
            sb.Append(" where GameID=" + GameID + " ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<ReserveIdentifierModel> GetAllReserveIdentifier()
        {
            List<ReserveIdentifierModel> list = new List<ReserveIdentifierModel>();
            string sql = string.Format("select * from ReserveIdentifier");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                ReserveIdentifierModel reserveidentifier = new ReserveIdentifierModel();
                reserveidentifier.GameID = (int)dr["GameID"];
                reserveidentifier.IDLevel = (int)dr["IDLevel"];
                reserveidentifier.Distribute = (bool)dr["Distribute"];
                list.Add(reserveidentifier);
            }
            dr.Close();
            return list;
        }
        public ReserveIdentifierModel GetReserveIdentifierById(int GameID)
        {
            string sql = string.Format("select * from ReserveIdentifier where GameID={0}",GameID);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            ReserveIdentifierModel reserveidentifier = new ReserveIdentifierModel();
            if (dr.Read())
            {
                reserveidentifier.GameID = (int)dr[0];
                reserveidentifier.IDLevel = (int)dr[1];
                reserveidentifier.Distribute = (bool)dr[2];
            }
            dr.Close();
            return reserveidentifier;
        }
    }
}
