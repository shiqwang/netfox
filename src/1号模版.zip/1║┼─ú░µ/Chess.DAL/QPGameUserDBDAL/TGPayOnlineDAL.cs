using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class TGPayOnlineDAL
    {
        public bool InsertTGPayOnline(TGPayOnlineModel tgpayonlinemodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into TGPayOnline values (");
            sb.Append(tgpayonlinemodel.UserID);
            sb.Append(",");
            sb.Append(tgpayonlinemodel.GameID);
            sb.Append(",'");
            sb.Append(tgpayonlinemodel.Account);
            sb.Append("',");
            sb.Append(tgpayonlinemodel.UsePayScore);
            sb.Append(",");
            sb.Append(tgpayonlinemodel.Score);
            sb.Append(")");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateTGPayOnline(int UserID, long UsePayScore, long Score)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update TGPayOnline set ");
            sb.Append("UsePayScore=");
            sb.Append(UsePayScore);
            sb.Append(",");
            sb.Append("Score=");
            sb.Append(Score);
            sb.Append(" where UserID=");
            sb.Append(UserID);
            sb.Append("");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public TGPayOnlineModel GetTGPayOnlineByUserID(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from TGPayOnline where UserID=");
            sb.Append(UserID);
            sb.Append("");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            TGPayOnlineModel tgpayonlinemodel = new TGPayOnlineModel();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    tgpayonlinemodel.ID = int.Parse(dr["ID"].ToString());
                    tgpayonlinemodel.UserID = int.Parse(dr["UserID"].ToString());
                    tgpayonlinemodel.GameID = int.Parse(dr["GameID"].ToString());
                    tgpayonlinemodel.Account = dr["Account"].ToString();
                    tgpayonlinemodel.UsePayScore = long.Parse(dr["UsePayScore"].ToString());
                    tgpayonlinemodel.Score = long.Parse(dr["Score"].ToString());
                }
            }
            dr.Close();
            return tgpayonlinemodel;
        }
    }
}
