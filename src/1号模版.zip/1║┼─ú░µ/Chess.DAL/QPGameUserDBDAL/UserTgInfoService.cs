using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class UserTgInfoService
    {
        public bool InsertUserTgInfo(UserTgInfoModel usertginfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into UserTgInfo values (");
            sb.Append(usertginfomodel.TgID);
            sb.Append(",");
            sb.Append(usertginfomodel.GameID);
            sb.Append(",'");
            sb.Append(usertginfomodel.Accounts);
            sb.Append("',");
            sb.Append(usertginfomodel.TgUserScore);
            sb.Append(",'");
            sb.Append(usertginfomodel.RegisterIP);
            sb.Append("','");
            sb.Append(usertginfomodel.LastLogonIP);
            sb.Append("','");
            sb.Append(usertginfomodel.RegisterDate);
            sb.Append("','");
            sb.Append(usertginfomodel.LastLogonDate);
            sb.Append("',");
            sb.Append(usertginfomodel.AllLogonTimes);
            sb.Append(",");
            sb.Append(usertginfomodel.PlayTimeCount);
            sb.Append(",");
            sb.Append(usertginfomodel.OnLineTimeCount);
            sb.Append(")");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateUserTgInfo(int GameID, int PlayTimeCount, int OnLineTimeCount)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update UserTgInfo set ");
            sb.Append("PlayTimeCount=");
            sb.Append(PlayTimeCount);
            sb.Append(",");
            sb.Append("OnLineTimeCount=");
            sb.Append(OnLineTimeCount);
            sb.Append(" where GameID=");
            sb.Append(GameID);
            sb.Append("");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public List<UserTgInfoModel> GetUserTgByTgID(int TgID)
        {
            List<UserTgInfoModel> list = new List<UserTgInfoModel>();
            StringBuilder sb = new StringBuilder();
            string sql = string.Format("select Accounts,PlayTimeCount from UserTgInfo where TgID={0}", TgID);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                UserTgInfoModel usertginfomodel = new UserTgInfoModel();
                usertginfomodel.Accounts = dr[0].ToString();
                usertginfomodel.PlayTimeCount = int.Parse(dr[1].ToString());
                list.Add(usertginfomodel);
            }
            dr.Close();
            return list;
        }
        public UserTgInfoModel GetUserTgInfoByTgID(int TgID)
        {
            string sql = string.Format("select sum(PlayTimeCount) as PlayTimeCount from UserTgInfo where TgID={0}", TgID);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            UserTgInfoModel usertginfomodel = new UserTgInfoModel();
            try
            {
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        usertginfomodel.PlayTimeCount = (int)dr["PlayTimeCount"];
                    }
                }
                dr.Close();
                return usertginfomodel;
            }
            catch (Exception)
            {
                return null;
            }
            
        }
        //public UserTgInfoModel GetUserTgByTgID(int TgID)
        //{
        //    string sql = string.Format("select Accounts,PlayTimeCount from UserTgInfo where TgID={0}", TgID);
        //    SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
        //    UserTgInfoModel usertginfomodel = new UserTgInfoModel();
        //    if (dr.Read())
        //    {
        //        usertginfomodel.Accounts = dr[0].ToString();
        //        usertginfomodel.PlayTimeCount = int.Parse(dr[1].ToString());
        //    }
        //    dr.Close();
        //    return usertginfomodel;
        //}
    }
}
