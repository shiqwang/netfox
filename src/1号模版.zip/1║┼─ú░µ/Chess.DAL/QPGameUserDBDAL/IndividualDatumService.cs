using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class IndividualDatumService
    {
        public bool InsertIndividualDatum(IndividualDatumModel individualdatummodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into IndividualDatum values (");
            sb.Append(individualdatummodel.Compellation);
            sb.Append(",'");
            sb.Append(individualdatummodel.QQ);
            sb.Append(",'");
            sb.Append(individualdatummodel.EMail);
            sb.Append(",'");
            sb.Append(individualdatummodel.SeatPhone);
            sb.Append(",'");
            sb.Append(individualdatummodel.MobilePhone);
            sb.Append(",'");
            sb.Append(individualdatummodel.DwellingPlace);
            sb.Append(",'");
            sb.Append(individualdatummodel.PostalCode);
            sb.Append(",'");
            sb.Append(individualdatummodel.CollectDate);
            sb.Append(",'");
            sb.Append(individualdatummodel.UserNote);
            sb.Append("')");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateIndividualDatum(IndividualDatumModel individualdatummodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update IndividualDatum set ");
            sb.Append("Compellation='" + individualdatummodel.Compellation + "',");
            sb.Append("QQ='" + individualdatummodel.QQ + "',");
            sb.Append("EMail='" + individualdatummodel.EMail + "',");
            sb.Append("SeatPhone='" + individualdatummodel.SeatPhone + "',");
            sb.Append("MobilePhone='" + individualdatummodel.MobilePhone + "',");
            sb.Append("DwellingPlace='" + individualdatummodel.DwellingPlace + "',");
            sb.Append("PostalCode='" + individualdatummodel.PostalCode + "',");
            sb.Append("CollectDate='" + individualdatummodel.CollectDate + "',");
            sb.Append("UserNote='" + individualdatummodel.UserNote + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where UserID=" + individualdatummodel.UserID + " ");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteIndividualDatum(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from IndividualDatum ");
            sb.Append(" where UserID=" + UserID + " ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<IndividualDatumModel> GetAllIndividualDatum()
        {
            List<IndividualDatumModel> list = new List<IndividualDatumModel>();
            string sql = string.Format("select * from IndividualDatum");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                IndividualDatumModel individualdatummodel = new IndividualDatumModel();
                individualdatummodel.UserID = (int)dr["UserID"];
                individualdatummodel.Compellation = dr["Compellation"].ToString();
                individualdatummodel.QQ = dr["QQ"].ToString();
                individualdatummodel.EMail = dr["EMail"].ToString();
                individualdatummodel.SeatPhone = dr["SeatPhone"].ToString();
                individualdatummodel.MobilePhone = dr["MobilePhone"].ToString();
                individualdatummodel.DwellingPlace = dr["DwellingPlace"].ToString();
                individualdatummodel.PostalCode = dr["PostalCode"].ToString();
                individualdatummodel.CollectDate = (DateTime)dr["CollectDate"];
                individualdatummodel.UserNote = dr["UserNote"].ToString();
                list.Add(individualdatummodel);
            }
            dr.Close();
            return list;
        }
        public IndividualDatumModel GetIndividualDatumById(int UserID)
        {
            string sql = string.Format("select * from IndividualDatum where UserID={0}",UserID);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            IndividualDatumModel individualdatummodel = new IndividualDatumModel();
            if (dr.Read())
            {
                individualdatummodel.UserID = (int)dr[0];
                individualdatummodel.Compellation = dr[1].ToString();
                individualdatummodel.QQ = dr[2].ToString();
                individualdatummodel.EMail = dr[3].ToString();
                individualdatummodel.SeatPhone = dr[4].ToString();
                individualdatummodel.MobilePhone = dr[5].ToString();
                individualdatummodel.DwellingPlace = dr[6].ToString();
                individualdatummodel.PostalCode = dr[7].ToString();
                individualdatummodel.CollectDate = (DateTime)dr[8];
                individualdatummodel.UserNote = dr[9].ToString();
            }
            dr.Close();
            return individualdatummodel;
        }
    }
}
