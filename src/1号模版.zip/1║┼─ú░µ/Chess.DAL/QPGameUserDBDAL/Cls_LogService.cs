using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class Cls_LogService
    {
        public bool InsertCls_Log(Cls_LogModel cls_logmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into Cls_Log values (");
            sb.Append(cls_logmodel.UserID);
            sb.Append(",'");
            sb.Append(cls_logmodel.Game);
            sb.Append(",'");
            sb.Append(cls_logmodel.ClsDate);
            sb.Append(",'");
            sb.Append(cls_logmodel.Score);
            sb.Append("')");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateCls_Log(Cls_LogModel cls_logmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update Cls_Log set ");
            sb.Append("UserID=" + cls_logmodel.UserID + ",");
            sb.Append("Game='" + cls_logmodel.Game + "',");
            sb.Append("ClsDate='" + cls_logmodel.ClsDate + "',");
            sb.Append("Score=" + cls_logmodel.Score + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where id=" + cls_logmodel.id + " ");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteCls_Log(int id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from Cls_Log ");
            sb.Append(" where id=" + id + " ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<Cls_LogModel> GetAllCls_Log()
        {
            List<Cls_LogModel> list = new List<Cls_LogModel>();
            string sql = string.Format("select * from Cls_Log");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                Cls_LogModel cls_logmodel = new Cls_LogModel();
                cls_logmodel.id = (int)dr["id"];
                cls_logmodel.UserID = (int)dr["UserID"];
                cls_logmodel.Game = dr["Game"].ToString();
                cls_logmodel.ClsDate = (DateTime)dr["ClsDate"];
                cls_logmodel.Score = (int)dr["Score"];
                list.Add(cls_logmodel);
            }
            dr.Close();
            return list;
        }
        public Cls_LogModel GetCls_LogById(int id)
        {
            string sql = string.Format("select * from Cls_Log where id={0}",id);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            Cls_LogModel cls_logmodel = new Cls_LogModel();
            if (dr.Read())
            {
                cls_logmodel.id = (int)dr[0];
                cls_logmodel.UserID = (int)dr[1];
                cls_logmodel.Game = dr[2].ToString();
                cls_logmodel.ClsDate = (DateTime)dr[3];
                cls_logmodel.Score = (int)dr[4];
            }
            dr.Close();
            return cls_logmodel;
        }
    }
}
