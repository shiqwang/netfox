using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class SystemStreamInfoService
    {
        public bool InsertSystemStreamInfo(SystemStreamInfoModel systemstreaminfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into SystemStreamInfo values (");
            sb.Append(systemstreaminfomodel.WebLogonSuccess);
            sb.Append(",'");
            sb.Append(systemstreaminfomodel.WebRegisterSuccess);
            sb.Append(",'");
            sb.Append(systemstreaminfomodel.GameLogonSuccess);
            sb.Append(",'");
            sb.Append(systemstreaminfomodel.GameRegisterSuccess);
            sb.Append(",'");
            sb.Append(systemstreaminfomodel.CollectDate);
            sb.Append("')");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateSystemStreamInfo(SystemStreamInfoModel systemstreaminfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update SystemStreamInfo set ");
            sb.Append("WebLogonSuccess=" + systemstreaminfomodel.WebLogonSuccess + ",");
            sb.Append("WebRegisterSuccess=" + systemstreaminfomodel.WebRegisterSuccess + ",");
            sb.Append("GameLogonSuccess=" + systemstreaminfomodel.GameLogonSuccess + ",");
            sb.Append("GameRegisterSuccess=" + systemstreaminfomodel.GameRegisterSuccess + ",");
            sb.Append("CollectDate='" + systemstreaminfomodel.CollectDate + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where DateID=" + systemstreaminfomodel.DateID + " ");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteSystemStreamInfo(int DateID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from SystemStreamInfo ");
            sb.Append(" where DateID=" + DateID + " ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<SystemStreamInfoModel> GetAllSystemStreamInfo()
        {
            List<SystemStreamInfoModel> list = new List<SystemStreamInfoModel>();
            string sql = string.Format("select * from SystemStreamInfo");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                SystemStreamInfoModel systemstreaminfo = new SystemStreamInfoModel();
                systemstreaminfo.DateID = (int)dr["DateID"];
                systemstreaminfo.WebLogonSuccess = (int)dr["WebLogonSuccess"];
                systemstreaminfo.WebRegisterSuccess = (int)dr["WebRegisterSuccess"];
                systemstreaminfo.GameLogonSuccess = (int)dr["GameLogonSuccess"];
                systemstreaminfo.GameRegisterSuccess = (int)dr["GameRegisterSuccess"];
                systemstreaminfo.CollectDate = (DateTime)dr["CollectDate"];
                list.Add(systemstreaminfo);
            }
            dr.Close();
            return list;
        }
        public SystemStreamInfoModel GetSystemStreamInfoById(int DateID)
        {
            string sql = string.Format("select * from SystemStreamInfo where DateID={0}", DateID);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            SystemStreamInfoModel systemstreaminfo = new SystemStreamInfoModel();
            if (dr.Read())
            {
                systemstreaminfo.DateID = (int)dr[0];
                systemstreaminfo.WebLogonSuccess = (int)dr[1];
                systemstreaminfo.WebRegisterSuccess = (int)dr[2];
                systemstreaminfo.GameLogonSuccess = (int)dr[3];
                systemstreaminfo.GameRegisterSuccess = (int)dr[4];
                systemstreaminfo.CollectDate = (DateTime)dr[5];
            }
            dr.Close();
            return systemstreaminfo;
        }
    }
}
