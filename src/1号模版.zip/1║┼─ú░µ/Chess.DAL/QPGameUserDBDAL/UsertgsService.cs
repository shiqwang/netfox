using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class UsertgsService
    {
        public bool InsertUsertgs(UsertgsModel usertgsmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into Usertgs values (");
            sb.Append(usertgsmodel.UserID);
            sb.Append(",");
            sb.Append(usertgsmodel.GameID);
            sb.Append(",'");
            sb.Append(usertgsmodel.Account);
            sb.Append("',");
            sb.Append(usertgsmodel.TgScore);
            sb.Append(",");
            sb.Append(usertgsmodel.TgCount);
            sb.Append(")");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateUsertgs(string UserName,int TgCount)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update Usertgs set ");
            sb.Append("TgCount="+TgCount+"");
            sb.Append(" where Account='"+UserName+"'");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateTgScore(string UserName, int TgScore)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update Usertgs set ");
            sb.Append("TgScore=" + TgScore + "");
            sb.Append(" where Account='" + UserName + "'");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public UsertgsModel GetUsertgByName(string username)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from Usertgs where Account='");
            sb.Append(username);
            sb.Append("'");
            try
            {
                SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
                UsertgsModel usertgsmodel = new UsertgsModel();
                while (dr.Read())
                {
                    usertgsmodel.TgID = int.Parse(dr["TgID"].ToString());
                    usertgsmodel.UserID = int.Parse(dr["UserID"].ToString());
                    usertgsmodel.GameID = int.Parse(dr["GameID"].ToString());
                    usertgsmodel.Account = dr["Account"].ToString();
                    usertgsmodel.TgScore = int.Parse(dr["TgScore"].ToString());
                    usertgsmodel.TgCount = int.Parse(dr["TgCount"].ToString());
                }
                dr.Close();
                return usertgsmodel;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
