using System;
using System.Collections.Generic;
using System.Text;
using Chess.DAL.DBHelper;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;
using System.Collections;
using System.Data;
using System.Configuration;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class AccountsInfoService
    {
        public bool InsertAccountsInfo(AccountsInfoModel accountsinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into AccountsInfo values (");
            sb.Append(accountsinfomodel.GameID);
            sb.Append(",");
            sb.Append(accountsinfomodel.ProtectID);
            sb.Append(",'");
            sb.Append(accountsinfomodel.Accounts);
            sb.Append("','");
            sb.Append(accountsinfomodel.RegAccounts);
            sb.Append("','");
            sb.Append(accountsinfomodel.UnderWrite);
            sb.Append("','");
            sb.Append(accountsinfomodel.LogonPass);
            sb.Append("','");
            sb.Append(accountsinfomodel.InsurePass);
            sb.Append("','");
            sb.Append(accountsinfomodel.QQ);
            sb.Append("','");
            sb.Append(accountsinfomodel.Phone);
            sb.Append("','");
            sb.Append(accountsinfomodel.SpreaderID);
            sb.Append("',");
            sb.Append(accountsinfomodel.FaceID);
            sb.Append(",");
            sb.Append(accountsinfomodel.Experience);
            sb.Append(",");
            sb.Append(accountsinfomodel.UserRight);
            sb.Append(",");
            sb.Append(accountsinfomodel.MasterRight);
            sb.Append(",");
            sb.Append(accountsinfomodel.ServiceRight);
            sb.Append(",");
            sb.Append(accountsinfomodel.MasterOrder);
            sb.Append(",");
            sb.Append(accountsinfomodel.MemberOrder);
            sb.Append(",'");
            sb.Append(accountsinfomodel.MemberOverDate);
            sb.Append("',");
            sb.Append(accountsinfomodel.Loveliness);
            sb.Append(",");
            sb.Append(accountsinfomodel.Gender);
            sb.Append(",'");
            sb.Append(accountsinfomodel.Nullity);
            sb.Append("','");
            sb.Append(accountsinfomodel.StunDown);
            sb.Append("',");
            sb.Append(accountsinfomodel.MoorMachine);
            sb.Append(",'");
            sb.Append(accountsinfomodel.MachineSerial);
            sb.Append("',");
            sb.Append(accountsinfomodel.WebLogonTimes);
            sb.Append(",");
            sb.Append(accountsinfomodel.GameLogonTimes);
            sb.Append(",'");
            sb.Append(accountsinfomodel.RegisterIP);
            sb.Append("','");
            sb.Append(accountsinfomodel.LastLogonIP);
            sb.Append("','");
            sb.Append(accountsinfomodel.RegisterDate);
            sb.Append("','");
            sb.Append(accountsinfomodel.LastLogonDate);
            sb.Append("','");
            sb.Append(accountsinfomodel.CustomFaceVer);
            sb.Append("','");
            sb.Append(accountsinfomodel.C_IDNO);
            sb.Append("','");
            sb.Append(accountsinfomodel.C_ADDRESS);
            sb.Append("','");
            sb.Append(accountsinfomodel.C_EMAIL);
            sb.Append("','");
            sb.Append(accountsinfomodel.C_PROTECTQUES);
            sb.Append("','");
            sb.Append(accountsinfomodel.C_PROTECTANSW);
            sb.Append("','");
            sb.Append(accountsinfomodel.C_BOXPASSWORD);
            sb.Append("','");
            sb.Append(accountsinfomodel.OlePassWord);
            sb.Append("','");
            sb.Append(accountsinfomodel.IsCheckPassWord);
            sb.Append("','");
            sb.Append(accountsinfomodel.IsBoxPassWord);
            sb.Append("','");
            sb.Append(accountsinfomodel.PassWordCode);
            sb.Append("','");
            sb.Append(accountsinfomodel.LoginKick);
            sb.Append("','");
            sb.Append(accountsinfomodel.UserCode);
            sb.Append("',");
            sb.Append(accountsinfomodel.Del);
            sb.Append(",");
            sb.Append(accountsinfomodel.yy);
            sb.Append(",'");
            sb.Append(accountsinfomodel.LoginDateTime);
            sb.Append("','");
            sb.Append(accountsinfomodel.YYCar);
            sb.Append("')");

            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
            //try
            //{
            //    return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            //}
            //catch (Exception)
            //{
            //    return false;
            //}
        }
        public bool UpdateAccountsInfo(AccountsInfoModel accountsinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AccountsInfo set ");
            sb.Append("GameID=" + accountsinfomodel.GameID + ",");
            sb.Append("ProtectID=" + accountsinfomodel.ProtectID + ",");
            sb.Append("Accounts='" + accountsinfomodel.Accounts + "',");
            sb.Append("RegAccounts='" + accountsinfomodel.RegAccounts + "',");
            sb.Append("UnderWrite='" + accountsinfomodel.UnderWrite + "',");
            sb.Append("LogonPass='" + accountsinfomodel.LogonPass + "',");
            sb.Append("InsurePass='" + accountsinfomodel.InsurePass + "',");
            sb.Append("QQ='" + accountsinfomodel.QQ + "',");
            sb.Append("Phone='" + accountsinfomodel.Phone + "',");
            sb.Append("SpreaderID='" + accountsinfomodel.SpreaderID + "',");
            sb.Append("FaceID=" + accountsinfomodel.FaceID + ",");
            sb.Append("Experience=" + accountsinfomodel.Experience + ",");
            sb.Append("UserRight=" + accountsinfomodel.UserRight + ",");
            sb.Append("MasterRight=" + accountsinfomodel.MasterRight + ",");
            sb.Append("ServiceRight=" + accountsinfomodel.ServiceRight + ",");
            sb.Append("MasterOrder=" + accountsinfomodel.MasterOrder + ",");
            sb.Append("MemberOrder=" + accountsinfomodel.MemberOrder + ",");
            sb.Append("MemberOverDate='" + accountsinfomodel.MemberOverDate + "',");
            sb.Append("Loveliness=" + accountsinfomodel.Loveliness + ",");
            sb.Append("Gender=" + accountsinfomodel.Gender + ",");
            sb.Append("Nullity=" + (accountsinfomodel.Nullity ? 1 : 0) + ",");
            sb.Append("StunDown=" + (accountsinfomodel.StunDown ? 1 : 0) + ",");
            sb.Append("MoorMachine=" + accountsinfomodel.MoorMachine + ",");
            sb.Append("MachineSerial='" + accountsinfomodel.MachineSerial + "',");
            sb.Append("WebLogonTimes=" + accountsinfomodel.WebLogonTimes + ",");
            sb.Append("GameLogonTimes=" + accountsinfomodel.GameLogonTimes + ",");
            sb.Append("RegisterIP='" + accountsinfomodel.RegisterIP + "',");
            sb.Append("LastLogonIP='" + accountsinfomodel.LastLogonIP + "',");
            sb.Append("RegisterDate='" + accountsinfomodel.RegisterDate + "',");
            sb.Append("LastLogonDate='" + accountsinfomodel.LastLogonDate + "',");
            sb.Append("CustomFaceVer=" + accountsinfomodel.CustomFaceVer + ",");
            sb.Append("C_IDNO='" + accountsinfomodel.C_IDNO + "',");
            sb.Append("C_ADDRESS='" + accountsinfomodel.C_ADDRESS + "',");
            sb.Append("C_EMAIL='" + accountsinfomodel.C_EMAIL + "',");
            sb.Append("C_PROTECTQUES='" + accountsinfomodel.C_PROTECTQUES + "',");
            sb.Append("C_PROTECTANSW='" + accountsinfomodel.C_PROTECTANSW + "',");
            sb.Append("C_BOXPASSWORD='" + accountsinfomodel.C_BOXPASSWORD + "',");
            sb.Append("OlePassWord='" + accountsinfomodel.OlePassWord + "',");
            sb.Append("IsCheckPassWord=" + (accountsinfomodel.IsCheckPassWord ? 1 : 0) + ",");
            sb.Append("IsBoxPassWord=" + (accountsinfomodel.IsBoxPassWord ? 1 : 0) + ",");
            sb.Append("PassWordCode='" + accountsinfomodel.PassWordCode + "',");
            sb.Append("LoginKick='" + accountsinfomodel.LoginKick + "',");
            sb.Append("UserCode='" + accountsinfomodel.UserCode + "',");
            sb.Append("Del=" + accountsinfomodel.Del + ",");
            sb.Append("yy=" + accountsinfomodel.yy + ",");
            sb.Append("LoginDateTime='" + accountsinfomodel.LoginDateTime + "',");
            sb.Append("YYCar=" + accountsinfomodel.YYCar + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where UserID=" + accountsinfomodel.UserID + " ");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateAccInfo(string username, string question, string underwrite, int gender, string qq, string mobile, string answer)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AccountsInfo set ");
            sb.Append("C_PROTECTQUES='" + question + "',");
            sb.Append("C_PROTECTANSW='" + answer + "',");
            sb.Append("UnderWrite='" + underwrite + "',");
            sb.Append("Gender=" + gender + ",");
            sb.Append("QQ='" + qq + "',");
            sb.Append("Phone='" + mobile + "'");
            sb.Append(" where Accounts ='" + username + "'");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateMemberOrderByUserID(int UserID, int MemberOrder, string MemberOverDate)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AccountsInfo set ");
            sb.Append("MemberOrder=" + MemberOrder + ",");
            sb.Append("MemberOverDate='");
            sb.Append(MemberOverDate);
            sb.Append("' where UserID=" + UserID + "");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateMemberOrderByID(int ID, int MemberOrder)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AccountsInfo set ");
            sb.Append("MemberOrder=" + MemberOrder + ",");
            sb.Append("MemberOverDate=dateadd (" + "m" + ",1, MemberOverDate)");
            //sb.Append("MemberOverDate=dateadd (");
            //sb.Append("");
            sb.Append(" where UserID=" + ID + "");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateLastLoginTime(string name, string time)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AccountsInfo set ");
            sb.Append("LastLogonDate=" + time + "");
            sb.Append(" where Accounts='" + name + "'");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateSpreaderID(string name, string SpreaderID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AccountsInfo set ");
            sb.Append("SpreaderID='" + SpreaderID + "'");
            sb.Append(" where Accounts='" + name + "'");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateGameID(string username, int gameid)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AccountsInfo set ");
            sb.Append("GameID=" + gameid + "");
            sb.Append(" where Accounts='" + username + "'");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdatePassWord(string username, string pwd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AccountsInfo set ");
            sb.Append("LogonPass='" + pwd + "'");
            sb.Append(" where Accounts ='" + username + "'");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateQuesByName(string name, string ques, string answ)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AccountsInfo set ");
            sb.Append("C_PROTECTQUES='" + ques + "',");
            sb.Append("C_PROTECTANSW='" + answ + "'");
            sb.Append(" where Accounts='" + name + "'");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateUserInfoByName(string name, string RegAccounts, string password)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AccountsInfo set ");
            sb.Append("RegAccounts='" + RegAccounts + "',");
            sb.Append("LogonPass='" + password + "'");
            sb.Append(" where Accounts ='" + name + "'");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateInsurePass(string username, string pwd)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AccountsInfo set ");
            sb.Append("InsurePass='" + pwd + "'");
            sb.Append(" where Accounts ='" + username + "'");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool DeleteAccountsInfo(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from AccountsInfo ");
            sb.Append(" where UserID=" + UserID + " ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<AccountsInfoModel> GetAccountsInfoListBySpreaderID(string SpreaderID)
        {
            List<AccountsInfoModel> list = new List<AccountsInfoModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from AccountsInfo where SpreaderID='");
            sb.Append(SpreaderID);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
                    accountsinfomodel.UserID = (int)dr["UserID"];
                    accountsinfomodel.GameID = (int)dr["GameID"];
                    accountsinfomodel.ProtectID = (int)dr["ProtectID"];
                    accountsinfomodel.Accounts = dr["Accounts"].ToString();
                    accountsinfomodel.RegAccounts = dr["RegAccounts"].ToString();
                    accountsinfomodel.UnderWrite = dr["UnderWrite"].ToString();
                    accountsinfomodel.LogonPass = dr["LogonPass"].ToString();
                    accountsinfomodel.InsurePass = dr["InsurePass"].ToString();
                    accountsinfomodel.QQ = dr["QQ"].ToString();
                    accountsinfomodel.Phone = dr["Phone"].ToString();
                    accountsinfomodel.SpreaderID = dr["SpreaderID"].ToString();

                    accountsinfomodel.FaceID = int.Parse(dr["FaceID"].ToString());
                    accountsinfomodel.Experience = (int)dr["Experience"];
                    accountsinfomodel.UserRight = (int)dr["UserRight"];
                    accountsinfomodel.MasterRight = (int)dr["MasterRight"];
                    accountsinfomodel.ServiceRight = (int)dr["ServiceRight"];

                    accountsinfomodel.MasterOrder = int.Parse(dr["MasterOrder"].ToString());

                    accountsinfomodel.MemberOrder = int.Parse(dr["MemberOrder"].ToString());
                    accountsinfomodel.MemberOverDate = dr["MemberOverDate"].ToString();
                    accountsinfomodel.Loveliness = (int)dr["Loveliness"];

                    accountsinfomodel.Gender = int.Parse(dr["Gender"].ToString());
                    accountsinfomodel.Nullity = (bool)dr["Nullity"];
                    accountsinfomodel.StunDown = (bool)dr["StunDown"];

                    accountsinfomodel.MoorMachine = int.Parse(dr["MoorMachine"].ToString());
                    accountsinfomodel.MachineSerial = dr["MachineSerial"].ToString();
                    accountsinfomodel.WebLogonTimes = (int)dr["WebLogonTimes"];
                    accountsinfomodel.GameLogonTimes = (int)dr["GameLogonTimes"];
                    accountsinfomodel.RegisterIP = dr["RegisterIP"].ToString();
                    accountsinfomodel.LastLogonIP = dr["LastLogonIP"].ToString();
                    accountsinfomodel.RegisterDate = dr["RegisterDate"].ToString();
                    accountsinfomodel.LastLogonDate = dr["LastLogonDate"].ToString();

                    accountsinfomodel.CustomFaceVer = int.Parse(dr["CustomFaceVer"].ToString());
                    accountsinfomodel.C_IDNO = dr["C_IDNO"].ToString();
                    accountsinfomodel.C_ADDRESS = dr["C_ADDRESS"].ToString();
                    accountsinfomodel.C_EMAIL = dr["C_EMAIL"].ToString();
                    accountsinfomodel.C_PROTECTQUES = dr["C_PROTECTQUES"].ToString();
                    accountsinfomodel.C_PROTECTANSW = dr["C_PROTECTANSW"].ToString();
                    accountsinfomodel.C_BOXPASSWORD = dr["C_BOXPASSWORD"].ToString();
                    accountsinfomodel.OlePassWord = dr["OlePassWord"].ToString();
                    accountsinfomodel.IsCheckPassWord = (bool)dr["IsCheckPassWord"];
                    accountsinfomodel.IsBoxPassWord = (bool)dr["IsBoxPassWord"];
                    accountsinfomodel.PassWordCode = dr["PassWordCode"].ToString();
                    accountsinfomodel.LoginKick = dr["LoginKick"].ToString();
                    accountsinfomodel.UserCode = dr["UserCode"].ToString();

                    accountsinfomodel.yy = (int)dr["yy"];
                    accountsinfomodel.LoginDateTime = dr["LoginDateTime"].ToString();
                    accountsinfomodel.YYCar = (int)dr["YYCar"];
                    list.Add(accountsinfomodel);
                }
            }
            dr.Close();
            return list;
        }
        public List<AccountsInfoModel> GetAccountsInfoListByUserID(int UserID)
        {
            List<AccountsInfoModel> list = new List<AccountsInfoModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from AccountsInfo where UserID=");
            sb.Append(UserID);
            sb.Append("");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
                    accountsinfomodel.UserID = (int)dr["UserID"];
                    accountsinfomodel.GameID = (int)dr["GameID"];
                    accountsinfomodel.ProtectID = (int)dr["ProtectID"];
                    accountsinfomodel.Accounts = dr["Accounts"].ToString();
                    accountsinfomodel.RegAccounts = dr["RegAccounts"].ToString();
                    accountsinfomodel.UnderWrite = dr["UnderWrite"].ToString();
                    accountsinfomodel.LogonPass = dr["LogonPass"].ToString();
                    accountsinfomodel.InsurePass = dr["InsurePass"].ToString();
                    accountsinfomodel.QQ = dr["QQ"].ToString();
                    accountsinfomodel.Phone = dr["Phone"].ToString();
                    accountsinfomodel.SpreaderID = dr["SpreaderID"].ToString();
                    accountsinfomodel.FaceID = int.Parse(dr["FaceID"].ToString());
                    accountsinfomodel.Experience = (int)dr["Experience"];
                    accountsinfomodel.UserRight = (int)dr["UserRight"];
                    accountsinfomodel.MasterRight = (int)dr["MasterRight"];
                    accountsinfomodel.ServiceRight = (int)dr["ServiceRight"];
                    accountsinfomodel.MasterOrder = int.Parse(dr["MasterOrder"].ToString());
                    accountsinfomodel.MemberOrder = int.Parse(dr["MemberOrder"].ToString());
                    accountsinfomodel.MemberOverDate = dr["MemberOverDate"].ToString();
                    accountsinfomodel.Loveliness = (int)dr["Loveliness"];
                    accountsinfomodel.Gender = int.Parse(dr["Gender"].ToString());
                    accountsinfomodel.Nullity = (bool)dr["Nullity"];
                    accountsinfomodel.StunDown = (bool)dr["StunDown"];
                    accountsinfomodel.MoorMachine = int.Parse(dr["MoorMachine"].ToString());
                    accountsinfomodel.MachineSerial = dr["MachineSerial"].ToString();
                    accountsinfomodel.WebLogonTimes = (int)dr["WebLogonTimes"];
                    accountsinfomodel.GameLogonTimes = (int)dr["GameLogonTimes"];
                    accountsinfomodel.RegisterIP = dr["RegisterIP"].ToString();
                    accountsinfomodel.LastLogonIP = dr["LastLogonIP"].ToString();
                    accountsinfomodel.RegisterDate = dr["RegisterDate"].ToString();
                    accountsinfomodel.LastLogonDate = dr["LastLogonDate"].ToString();
                    accountsinfomodel.CustomFaceVer = int.Parse(dr["CustomFaceVer"].ToString());
                    accountsinfomodel.C_IDNO = dr["C_IDNO"].ToString();
                    accountsinfomodel.C_ADDRESS = dr["C_ADDRESS"].ToString();
                    accountsinfomodel.C_EMAIL = dr["C_EMAIL"].ToString();
                    accountsinfomodel.C_PROTECTQUES = dr["C_PROTECTQUES"].ToString();
                    accountsinfomodel.C_PROTECTANSW = dr["C_PROTECTANSW"].ToString();
                    accountsinfomodel.C_BOXPASSWORD = dr["C_BOXPASSWORD"].ToString();
                    accountsinfomodel.OlePassWord = dr["OlePassWord"].ToString();
                    accountsinfomodel.IsCheckPassWord = (bool)dr["IsCheckPassWord"];
                    accountsinfomodel.IsBoxPassWord = (bool)dr["IsBoxPassWord"];
                    accountsinfomodel.PassWordCode = dr["PassWordCode"].ToString();
                    accountsinfomodel.LoginKick = dr["LoginKick"].ToString();
                    accountsinfomodel.UserCode = dr["UserCode"].ToString();
                    accountsinfomodel.yy = (int)dr["yy"];
                    accountsinfomodel.LoginDateTime = dr["LoginDateTime"].ToString();
                    accountsinfomodel.YYCar = (int)dr["YYCar"];
                    list.Add(accountsinfomodel);
                }
            }
            dr.Close();
            return list;
        }
        public List<AccountsInfoModel> GetAccountsInfoListByUserName(string UserName)
        {
            List<AccountsInfoModel> list = new List<AccountsInfoModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from AccountsInfo where Accounts='");
            sb.Append(UserName);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
                    accountsinfomodel.UserID = (int)dr["UserID"];
                    accountsinfomodel.GameID = (int)dr["GameID"];
                    accountsinfomodel.ProtectID = (int)dr["ProtectID"];
                    accountsinfomodel.Accounts = dr["Accounts"].ToString();
                    accountsinfomodel.RegAccounts = dr["RegAccounts"].ToString();
                    accountsinfomodel.UnderWrite = dr["UnderWrite"].ToString();
                    accountsinfomodel.LogonPass = dr["LogonPass"].ToString();
                    accountsinfomodel.InsurePass = dr["InsurePass"].ToString();
                    accountsinfomodel.QQ = dr["QQ"].ToString();
                    accountsinfomodel.Phone = dr["Phone"].ToString();
                    accountsinfomodel.SpreaderID = dr["SpreaderID"].ToString();
                    accountsinfomodel.FaceID = int.Parse(dr["FaceID"].ToString());
                    accountsinfomodel.Experience = (int)dr["Experience"];
                    accountsinfomodel.UserRight = (int)dr["UserRight"];
                    accountsinfomodel.MasterRight = (int)dr["MasterRight"];
                    accountsinfomodel.ServiceRight = (int)dr["ServiceRight"];
                    accountsinfomodel.MasterOrder = int.Parse(dr["MasterOrder"].ToString());
                    accountsinfomodel.MemberOrder = int.Parse(dr["MemberOrder"].ToString());
                    accountsinfomodel.MemberOverDate = dr["MemberOverDate"].ToString();
                    accountsinfomodel.Loveliness = (int)dr["Loveliness"];
                    accountsinfomodel.Gender = int.Parse(dr["Gender"].ToString());
                    accountsinfomodel.Nullity = (bool)dr["Nullity"];
                    accountsinfomodel.StunDown = (bool)dr["StunDown"];
                    accountsinfomodel.MoorMachine = int.Parse(dr["MoorMachine"].ToString());
                    accountsinfomodel.MachineSerial = dr["MachineSerial"].ToString();
                    accountsinfomodel.WebLogonTimes = (int)dr["WebLogonTimes"];
                    accountsinfomodel.GameLogonTimes = (int)dr["GameLogonTimes"];
                    accountsinfomodel.RegisterIP = dr["RegisterIP"].ToString();
                    accountsinfomodel.LastLogonIP = dr["LastLogonIP"].ToString();
                    accountsinfomodel.RegisterDate = dr["RegisterDate"].ToString();
                    accountsinfomodel.LastLogonDate = dr["LastLogonDate"].ToString();
                    accountsinfomodel.CustomFaceVer = int.Parse(dr["CustomFaceVer"].ToString());
                    accountsinfomodel.C_IDNO = dr["C_IDNO"].ToString();
                    accountsinfomodel.C_ADDRESS = dr["C_ADDRESS"].ToString();
                    accountsinfomodel.C_EMAIL = dr["C_EMAIL"].ToString();
                    accountsinfomodel.C_PROTECTQUES = dr["C_PROTECTQUES"].ToString();
                    accountsinfomodel.C_PROTECTANSW = dr["C_PROTECTANSW"].ToString();
                    accountsinfomodel.C_BOXPASSWORD = dr["C_BOXPASSWORD"].ToString();
                    accountsinfomodel.OlePassWord = dr["OlePassWord"].ToString();
                    accountsinfomodel.IsCheckPassWord = (bool)dr["IsCheckPassWord"];
                    accountsinfomodel.IsBoxPassWord = (bool)dr["IsBoxPassWord"];
                    accountsinfomodel.PassWordCode = dr["PassWordCode"].ToString();
                    accountsinfomodel.LoginKick = dr["LoginKick"].ToString();
                    accountsinfomodel.UserCode = dr["UserCode"].ToString();
                    accountsinfomodel.yy = (int)dr["yy"];
                    accountsinfomodel.LoginDateTime = dr["LoginDateTime"].ToString();
                    accountsinfomodel.YYCar = (int)dr["YYCar"];
                    list.Add(accountsinfomodel);
                }
            }
            dr.Close();
            return list;
        }
        public bool isIP(string ip)
        {
            bool Isip = false;
            string sql = "select * from AccountsInfo where RegisterIP='" + ip + "'";
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    int CreatTime = Convert.ToInt32(Convert.ToDateTime(dr["RegisterDate"]).ToString("MMddHHmmss"));
                    int NowTime = Convert.ToInt32(DateTime.Now.ToString("MMddHHmmss"));
                    if (NowTime - CreatTime > Convert.ToInt32(ConfigurationManager.AppSettings["IP"]))
                    {
                        Isip = false;
                    }
                    else
                        Isip = true;
                }
            }
            else
            {
                Isip = false;
            }
            dr.Close();
            return Isip;
        }
        public List<AccountsInfoModel> GetAllAccountsInfo()
        {
            List<AccountsInfoModel> list = new List<AccountsInfoModel>();
            string sql = string.Format("select * from AccountsInfo");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
                accountsinfomodel.UserID = (int)dr["UserID"];
                accountsinfomodel.GameID = (int)dr["GameID"];
                accountsinfomodel.ProtectID = (int)dr["ProtectID"];
                accountsinfomodel.Accounts = dr["Accounts"].ToString();
                accountsinfomodel.RegAccounts = dr["RegAccounts"].ToString();
                accountsinfomodel.UnderWrite = dr["UnderWrite"].ToString();
                accountsinfomodel.LogonPass = dr["LogonPass"].ToString();
                accountsinfomodel.InsurePass = dr["InsurePass"].ToString();
                accountsinfomodel.QQ = dr["QQ"].ToString();
                accountsinfomodel.Phone = dr["Phone"].ToString();
                accountsinfomodel.SpreaderID = dr["SpreaderID"].ToString();
                accountsinfomodel.FaceID = int.Parse(dr["FaceID"].ToString());
                accountsinfomodel.Experience = (int)dr["Experience"];
                accountsinfomodel.UserRight = (int)dr["UserRight"];
                accountsinfomodel.MasterRight = (int)dr["MasterRight"];
                accountsinfomodel.ServiceRight = (int)dr["ServiceRight"];
                accountsinfomodel.MasterOrder = int.Parse(dr["MasterOrder"].ToString());
                accountsinfomodel.MemberOrder = int.Parse(dr["MemberOrder"].ToString());
                accountsinfomodel.MemberOverDate = dr["MemberOverDate"].ToString();
                accountsinfomodel.Loveliness = (int)dr["Loveliness"];
                accountsinfomodel.Gender = int.Parse(dr["Gender"].ToString());
                accountsinfomodel.Nullity = (bool)dr["Nullity"];
                accountsinfomodel.StunDown = (bool)dr["StunDown"];
                accountsinfomodel.MoorMachine = int.Parse(dr["MoorMachine"].ToString());
                accountsinfomodel.MachineSerial = dr["MachineSerial"].ToString();
                accountsinfomodel.WebLogonTimes = (int)dr["WebLogonTimes"];
                accountsinfomodel.GameLogonTimes = (int)dr["GameLogonTimes"];
                accountsinfomodel.RegisterIP = dr["RegisterIP"].ToString();
                accountsinfomodel.LastLogonIP = dr["LastLogonIP"].ToString();
                accountsinfomodel.RegisterDate = dr["RegisterDate"].ToString();
                accountsinfomodel.LastLogonDate = dr["LastLogonDate"].ToString();
                accountsinfomodel.CustomFaceVer = int.Parse(dr["CustomFaceVer"].ToString());
                accountsinfomodel.C_IDNO = dr["C_IDNO"].ToString();
                accountsinfomodel.C_ADDRESS = dr["C_ADDRESS"].ToString();
                accountsinfomodel.C_EMAIL = dr["C_EMAIL"].ToString();
                accountsinfomodel.C_PROTECTQUES = dr["C_PROTECTQUES"].ToString();
                accountsinfomodel.C_PROTECTANSW = dr["C_PROTECTANSW"].ToString();
                accountsinfomodel.C_BOXPASSWORD = dr["C_BOXPASSWORD"].ToString();
                accountsinfomodel.OlePassWord = dr["OlePassWord"].ToString();
                accountsinfomodel.IsCheckPassWord = (bool)dr["IsCheckPassWord"];
                accountsinfomodel.IsBoxPassWord = (bool)dr["IsBoxPassWord"];
                accountsinfomodel.PassWordCode = dr["PassWordCode"].ToString();
                accountsinfomodel.LoginKick = dr["LoginKick"].ToString();
                accountsinfomodel.UserCode = dr["UserCode"].ToString();
                accountsinfomodel.yy = (int)dr["yy"];
                accountsinfomodel.LoginDateTime = dr["LoginDateTime"].ToString();
                accountsinfomodel.YYCar = (int)dr["YYCar"];
                list.Add(accountsinfomodel);
            }
            dr.Close();
            return list;
        }
        public AccountsInfoModel GetAccountsInfoByName(string Name)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from AccountsInfo where Accounts='");
            sb.Append(Name);
            sb.Append("'");
            try
            {
                SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
                AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
                while (dr.Read())
                {
                    accountsinfomodel.UserID = (int)dr["UserID"];
                    accountsinfomodel.GameID = (int)dr["GameID"];
                    accountsinfomodel.ProtectID = (int)dr["ProtectID"];
                    accountsinfomodel.Accounts = dr["Accounts"].ToString();
                    accountsinfomodel.RegAccounts = dr["RegAccounts"].ToString();
                    accountsinfomodel.UnderWrite = dr["UnderWrite"].ToString();
                    accountsinfomodel.LogonPass = dr["LogonPass"].ToString();
                    accountsinfomodel.InsurePass = dr["InsurePass"].ToString();
                    accountsinfomodel.QQ = dr["QQ"].ToString();
                    accountsinfomodel.Phone = dr["Phone"].ToString();
                    accountsinfomodel.SpreaderID = dr["SpreaderID"].ToString();
                    accountsinfomodel.FaceID = int.Parse(dr["FaceID"].ToString());
                    accountsinfomodel.Experience = (int)dr["Experience"];
                    accountsinfomodel.UserRight = (int)dr["UserRight"];
                    accountsinfomodel.MasterRight = (int)dr["MasterRight"];
                    accountsinfomodel.ServiceRight = (int)dr["ServiceRight"];
                    accountsinfomodel.MasterOrder = int.Parse(dr["MasterOrder"].ToString());
                    accountsinfomodel.MemberOrder = int.Parse(dr["MemberOrder"].ToString());
                    accountsinfomodel.MemberOverDate = dr["MemberOverDate"].ToString();
                    accountsinfomodel.Loveliness = (int)dr["Loveliness"];
                    accountsinfomodel.Gender = int.Parse(dr["Gender"].ToString());
                    accountsinfomodel.Nullity = (bool)dr["Nullity"];
                    accountsinfomodel.StunDown = (bool)dr["StunDown"];
                    accountsinfomodel.MoorMachine = int.Parse(dr["MoorMachine"].ToString());
                    accountsinfomodel.MachineSerial = dr["MachineSerial"].ToString();
                    accountsinfomodel.WebLogonTimes = (int)dr["WebLogonTimes"];
                    accountsinfomodel.GameLogonTimes = (int)dr["GameLogonTimes"];
                    accountsinfomodel.RegisterIP = dr["RegisterIP"].ToString();
                    accountsinfomodel.LastLogonIP = dr["LastLogonIP"].ToString();
                    accountsinfomodel.RegisterDate = dr["RegisterDate"].ToString();
                    accountsinfomodel.LastLogonDate = dr["LastLogonDate"].ToString();
                    accountsinfomodel.CustomFaceVer = int.Parse(dr["CustomFaceVer"].ToString());
                    accountsinfomodel.C_IDNO = dr["C_IDNO"].ToString();
                    accountsinfomodel.C_ADDRESS = dr["C_ADDRESS"].ToString();
                    accountsinfomodel.C_EMAIL = dr["C_EMAIL"].ToString();
                    accountsinfomodel.C_PROTECTQUES = dr["C_PROTECTQUES"].ToString();
                    accountsinfomodel.C_PROTECTANSW = dr["C_PROTECTANSW"].ToString();
                    accountsinfomodel.C_BOXPASSWORD = dr["C_BOXPASSWORD"].ToString();
                    accountsinfomodel.OlePassWord = dr["OlePassWord"].ToString();
                    accountsinfomodel.IsCheckPassWord = (bool)dr["IsCheckPassWord"];
                    accountsinfomodel.IsBoxPassWord = (bool)dr["IsBoxPassWord"];
                    accountsinfomodel.PassWordCode = dr["PassWordCode"].ToString();
                    accountsinfomodel.LoginKick = dr["LoginKick"].ToString();
                    accountsinfomodel.UserCode = dr["UserCode"].ToString();
                    accountsinfomodel.yy = (int)dr["yy"];
                    accountsinfomodel.LoginDateTime = dr["LoginDateTime"].ToString();
                    accountsinfomodel.YYCar = (int)dr["YYCar"];
                }
                dr.Close();
                return accountsinfomodel;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public AccountsInfoModel GetAccountsInfoById(int UserID)
        {
            string sql = string.Format("select * from AccountsInfo where UserID={0}", UserID);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
            if (dr.Read())
            {
                accountsinfomodel.UserID = (int)dr["UserID"];
                accountsinfomodel.GameID = (int)dr["GameID"];
                accountsinfomodel.ProtectID = (int)dr["ProtectID"];
                accountsinfomodel.Accounts = dr["Accounts"].ToString();
                accountsinfomodel.RegAccounts = dr["RegAccounts"].ToString();
                accountsinfomodel.UnderWrite = dr["UnderWrite"].ToString();
                accountsinfomodel.LogonPass = dr["LogonPass"].ToString();
                accountsinfomodel.InsurePass = dr["InsurePass"].ToString();
                accountsinfomodel.QQ = dr["QQ"].ToString();
                accountsinfomodel.Phone = dr["Phone"].ToString();
                accountsinfomodel.SpreaderID = dr["SpreaderID"].ToString();
                accountsinfomodel.FaceID = int.Parse(dr["FaceID"].ToString());
                accountsinfomodel.Experience = (int)dr["Experience"];
                accountsinfomodel.UserRight = (int)dr["UserRight"];
                accountsinfomodel.MasterRight = (int)dr["MasterRight"];
                accountsinfomodel.ServiceRight = (int)dr["ServiceRight"];
                accountsinfomodel.MasterOrder = int.Parse(dr["MasterOrder"].ToString());
                accountsinfomodel.MemberOrder = int.Parse(dr["MemberOrder"].ToString());
                accountsinfomodel.MemberOverDate = dr["MemberOverDate"].ToString();
                accountsinfomodel.Loveliness = (int)dr["Loveliness"];
                accountsinfomodel.Gender = int.Parse(dr["Gender"].ToString());
                accountsinfomodel.Nullity = (bool)dr["Nullity"];
                accountsinfomodel.StunDown = (bool)dr["StunDown"];
                accountsinfomodel.MoorMachine = int.Parse(dr["MoorMachine"].ToString());
                accountsinfomodel.MachineSerial = dr["MachineSerial"].ToString();
                accountsinfomodel.WebLogonTimes = (int)dr["WebLogonTimes"];
                accountsinfomodel.GameLogonTimes = (int)dr["GameLogonTimes"];
                accountsinfomodel.RegisterIP = dr["RegisterIP"].ToString();
                accountsinfomodel.LastLogonIP = dr["LastLogonIP"].ToString();
                accountsinfomodel.RegisterDate = dr["RegisterDate"].ToString();
                accountsinfomodel.LastLogonDate = dr["LastLogonDate"].ToString();
                accountsinfomodel.CustomFaceVer = int.Parse(dr["CustomFaceVer"].ToString());
                accountsinfomodel.C_IDNO = dr["C_IDNO"].ToString();
                accountsinfomodel.C_ADDRESS = dr["C_ADDRESS"].ToString();
                accountsinfomodel.C_EMAIL = dr["C_EMAIL"].ToString();
                accountsinfomodel.C_PROTECTQUES = dr["C_PROTECTQUES"].ToString();
                accountsinfomodel.C_PROTECTANSW = dr["C_PROTECTANSW"].ToString();
                accountsinfomodel.C_BOXPASSWORD = dr["C_BOXPASSWORD"].ToString();
                accountsinfomodel.OlePassWord = dr["OlePassWord"].ToString();
                accountsinfomodel.IsCheckPassWord = (bool)dr["IsCheckPassWord"];
                accountsinfomodel.IsBoxPassWord = (bool)dr["IsBoxPassWord"];
                accountsinfomodel.PassWordCode = dr["PassWordCode"].ToString();
                accountsinfomodel.LoginKick = dr["LoginKick"].ToString();
                accountsinfomodel.UserCode = dr["UserCode"].ToString();
                accountsinfomodel.yy = (int)dr["yy"];
                accountsinfomodel.LoginDateTime = dr["LoginDateTime"].ToString();
                accountsinfomodel.YYCar = (int)dr["YYCar"];
            }
            dr.Close();
            return accountsinfomodel;
        }
        public IList<AccountsInfoModel> GetAccountsByName(string Name)
        {
            IList<AccountsInfoModel> list = new List<AccountsInfoModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from AccountsInfo where Accounts='");
            sb.Append(Name);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            while (dr.Read())
            {
                AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
                accountsinfomodel.UserID = (int)dr["UserID"];
                accountsinfomodel.GameID = (int)dr["GameID"];
                accountsinfomodel.ProtectID = (int)dr["ProtectID"];
                accountsinfomodel.Accounts = dr["Accounts"].ToString();
                accountsinfomodel.RegAccounts = dr["RegAccounts"].ToString();
                accountsinfomodel.UnderWrite = dr["UnderWrite"].ToString();
                accountsinfomodel.LogonPass = dr["LogonPass"].ToString();
                accountsinfomodel.InsurePass = dr["InsurePass"].ToString();
                accountsinfomodel.QQ = dr["QQ"].ToString();
                accountsinfomodel.Phone = dr["Phone"].ToString();
                accountsinfomodel.SpreaderID = dr["SpreaderID"].ToString();

                accountsinfomodel.FaceID = int.Parse(dr["FaceID"].ToString());
                accountsinfomodel.Experience = (int)dr["Experience"];
                accountsinfomodel.UserRight = (int)dr["UserRight"];
                accountsinfomodel.MasterRight = (int)dr["MasterRight"];
                accountsinfomodel.ServiceRight = (int)dr["ServiceRight"];

                accountsinfomodel.MasterOrder = int.Parse(dr["MasterOrder"].ToString());

                accountsinfomodel.MemberOrder = int.Parse(dr["MemberOrder"].ToString());
                accountsinfomodel.MemberOverDate = dr["MemberOverDate"].ToString();
                accountsinfomodel.Loveliness = (int)dr["Loveliness"];

                accountsinfomodel.Gender = int.Parse(dr["Gender"].ToString());
                accountsinfomodel.Nullity = (bool)dr["Nullity"];
                accountsinfomodel.StunDown = (bool)dr["StunDown"];

                accountsinfomodel.MoorMachine = int.Parse(dr["MoorMachine"].ToString());
                accountsinfomodel.MachineSerial = dr["MachineSerial"].ToString();
                accountsinfomodel.WebLogonTimes = (int)dr["WebLogonTimes"];
                accountsinfomodel.GameLogonTimes = (int)dr["GameLogonTimes"];
                accountsinfomodel.RegisterIP = dr["RegisterIP"].ToString();
                accountsinfomodel.LastLogonIP = dr["LastLogonIP"].ToString();
                accountsinfomodel.RegisterDate = dr["RegisterDate"].ToString();
                accountsinfomodel.LastLogonDate = dr["LastLogonDate"].ToString();
                //accountsinfomodel.CustomFaceVer = (int)dr["CustomFaceVer"];
                accountsinfomodel.CustomFaceVer = int.Parse(dr["CustomFaceVer"].ToString());
                accountsinfomodel.C_IDNO = dr["C_IDNO"].ToString();
                accountsinfomodel.C_ADDRESS = dr["C_ADDRESS"].ToString();
                accountsinfomodel.C_EMAIL = dr["C_EMAIL"].ToString();
                accountsinfomodel.C_PROTECTQUES = dr["C_PROTECTQUES"].ToString();
                accountsinfomodel.C_PROTECTANSW = dr["C_PROTECTANSW"].ToString();
                accountsinfomodel.C_BOXPASSWORD = dr["C_BOXPASSWORD"].ToString();
                accountsinfomodel.OlePassWord = dr["OlePassWord"].ToString();
                accountsinfomodel.IsCheckPassWord = (bool)dr["IsCheckPassWord"];
                accountsinfomodel.IsBoxPassWord = (bool)dr["IsBoxPassWord"];
                accountsinfomodel.PassWordCode = dr["PassWordCode"].ToString();
                accountsinfomodel.LoginKick = dr["LoginKick"].ToString();
                accountsinfomodel.UserCode = dr["UserCode"].ToString();
                //accountsinfomodel.Del = (int)dr["Del"];
                //accountsinfomodel.Del = int.Parse(dr["Del"].ToString());
                accountsinfomodel.yy = (int)dr["yy"];
                accountsinfomodel.LoginDateTime = dr["LoginDateTime"].ToString();
                accountsinfomodel.YYCar = (int)dr["YYCar"];
                list.Add(accountsinfomodel);
            }
            dr.Close();
            return list;
        }
        public List<AccountsInfoModel> GetLoveliness()
        {
            List<AccountsInfoModel> list = new List<AccountsInfoModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select top 10 Accounts,Loveliness from AccountsInfo order by Loveliness desc");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            while (dr.Read())
            {
                AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
                accountsinfomodel.Accounts = dr[0].ToString();
                accountsinfomodel.Loveliness = int.Parse(dr[1].ToString());
                list.Add(accountsinfomodel);
            }
            dr.Close();
            return list;
        }
        /// <summary>
        /// ��ȡ����ID
        /// </summary>
        /// <returns></returns>
        public AccountsInfoModel GetMaxID()
        {
            AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
            string sql = "select top 1 * from AccountsInfo order by UserID desc";
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            if (dr.HasRows)
            {
                while (dr.Read())
                {

                    accountsinfomodel.UserID = (int)dr["UserID"];
                }
            }
            dr.Close();
            return accountsinfomodel;
        }
        /// <summary>
        /// �Ƿ����
        /// </summary>
        /// <param name="GameID"></param>
        /// <returns></returns>
        public bool IsGameID(int GameID)
        {
            bool isgmameid = false;
            string sql = string.Format("select * from AccountsInfo where GameID={0}", GameID);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                isgmameid = true;
            }
            dr.Close();
            return isgmameid;
        }
        public List<AccountsInfoModel> GetScoretop()
        {
            List<AccountsInfoModel> list = new List<AccountsInfoModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select Accounts from AccountsInfo where UserID in (select top 13 UserID from QPTreasureDB.dbo.GameScoreInfo order by (Score+InsureScore) desc)");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            while (dr.Read())
            {
                AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
                accountsinfomodel.Accounts = dr[0].ToString();
                list.Add(accountsinfomodel);
            }
            dr.Close();
            return list;
        }
        public List<AccountsInfoModel> GetScore(int UserID)
        {
            List<AccountsInfoModel> list = new List<AccountsInfoModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select Accounts from AccountsInfo where UserID='");
            sb.Append(UserID);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            while (dr.Read())
            {
                AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
                accountsinfomodel.Accounts = dr[0].ToString();
                list.Add(accountsinfomodel);
            }
            dr.Close();
            return list;
        }
        public bool AddAccountsInfo(AccountsInfoModel accountsinfomodel)
        {
            try
            {
                SqlCommand com = new SqlCommand("GSP_GP_UserReg", DBHelper.QPGameUserDBHelper.Connectionstrings);
                com.CommandType = CommandType.StoredProcedure;
                SqlParameter[] pa = {
                    new SqlParameter("@GameID",SqlDbType.Int),
                    new SqlParameter("@ProtectID",SqlDbType.Int),
                    new SqlParameter("@Accounts",SqlDbType.NVarChar,31),
                    new SqlParameter("@RegAccounts",SqlDbType.NVarChar,31),
                    new SqlParameter("@UnderWrite",SqlDbType.NVarChar,63),
                    new SqlParameter("@LogonPass",SqlDbType.NChar,32),
                    new SqlParameter("@InsurePass",SqlDbType.NChar,32),
                    new SqlParameter("@QQ",SqlDbType.NVarChar,12),
                    new SqlParameter("@Phone",SqlDbType.NVarChar,12),
                    new SqlParameter("@SpreaderID",SqlDbType.NVarChar,31),
                    new SqlParameter("@FaceID",SqlDbType.SmallInt),
                    new SqlParameter("@Experience",SqlDbType.Int),
                    new SqlParameter("@UserRight",SqlDbType.Int),
                    new SqlParameter("@MasterRight",SqlDbType.Int),
                    new SqlParameter("@ServiceRight",SqlDbType.Int),
                    new SqlParameter("@MasterOrder",SqlDbType.TinyInt),
                    new SqlParameter("@MemberOrder",SqlDbType.TinyInt),
                    new SqlParameter("@MemberOverDate",SqlDbType.DateTime),
                    new SqlParameter("@Loveliness",SqlDbType.Int),
                    new SqlParameter("@Gender",SqlDbType.TinyInt),
                    new SqlParameter("@Nullity",SqlDbType.Bit),
                    new SqlParameter("@StunDown",SqlDbType.Bit),
                    new SqlParameter("@MoorMachine",SqlDbType.TinyInt),
                    new SqlParameter("@MachineSerial",SqlDbType.NChar,32),
                    new SqlParameter("@WebLogonTimes",SqlDbType.Int),
                    new SqlParameter("@GameLogonTimes",SqlDbType.Int),
                    new SqlParameter("@RegisterIP",SqlDbType.NVarChar,15),
                    new SqlParameter("@LastLogonIP",SqlDbType.NVarChar,15),
                    new SqlParameter("@RegisterDate",SqlDbType.DateTime),
                    new SqlParameter("@LastLogonDate",SqlDbType.DateTime),
                    new SqlParameter("@CustomFaceVer",SqlDbType.TinyInt),
                    new SqlParameter("@C_IDNO",SqlDbType.NVarChar,50),
                    new SqlParameter("@C_ADDRESS",SqlDbType.NVarChar,50),
                    new SqlParameter("@C_EMAIL",SqlDbType.NVarChar,50),
                    new SqlParameter("@C_PROTECTQUES",SqlDbType.NVarChar,50),
                    new SqlParameter("@C_PROTECTANSW",SqlDbType.NVarChar,50),
                    new SqlParameter("@C_BOXPASSWORD",SqlDbType.NVarChar,50),
                    new SqlParameter("@OlePassWord",SqlDbType.NVarChar,50),
                    new SqlParameter("@IsCheckPassWord",SqlDbType.Bit),
                    new SqlParameter("@IsBoxPassWord",SqlDbType.Bit),
                    new SqlParameter("@PassWordCode",SqlDbType.NVarChar,50),
                    new SqlParameter("@LoginKick",SqlDbType.NVarChar,50),
                    new SqlParameter("@UserCode",SqlDbType.NVarChar,50),
                    new SqlParameter("@Del",SqlDbType.Int),
                    new SqlParameter("@yy",SqlDbType.Int),
                    new SqlParameter("@LoginDateTime",SqlDbType.DateTime),
                    new SqlParameter("@YYCar",SqlDbType.Int),
                    //new SqlParameter("@c_pic",SqlDbType.NVarChar,50),
                };

                //pa[45].Value = accountsinfomodel.C_pic;
                foreach (SqlParameter p in pa)
                {
                    com.Parameters.Add(p);
                }
                return com.ExecuteNonQuery() > 0;
            }
            catch
            {
                return false;
            }
            finally
            {
                DBHelper.QPGameUserDBHelper.Connectionstrings.Close();
            }
        }
        public void GetUserInfo(int GameID, int newID)
        {
            AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
            string sql = string.Format("select * from AccountsInfo where GameID={0}", GameID);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                accountsinfomodel.UserID = (int)dr["UserID"];
                accountsinfomodel.GameID = (int)dr["GameID"];
                accountsinfomodel.ProtectID = (int)dr["ProtectID"];
                accountsinfomodel.Accounts = dr["Accounts"].ToString();
                accountsinfomodel.RegAccounts = dr["RegAccounts"].ToString();
                accountsinfomodel.UnderWrite = dr["UnderWrite"].ToString();
                accountsinfomodel.LogonPass = dr["LogonPass"].ToString();
                accountsinfomodel.InsurePass = dr["InsurePass"].ToString();
                accountsinfomodel.QQ = dr["QQ"].ToString();
                accountsinfomodel.Phone = dr["Phone"].ToString();
                accountsinfomodel.SpreaderID = dr["SpreaderID"].ToString();
                accountsinfomodel.FaceID = int.Parse(dr["FaceID"].ToString());
                accountsinfomodel.Experience = (int)dr["Experience"];
                accountsinfomodel.UserRight = (int)dr["UserRight"];
                accountsinfomodel.MasterRight = (int)dr["MasterRight"];
                accountsinfomodel.ServiceRight = (int)dr["ServiceRight"];
                accountsinfomodel.MasterOrder = int.Parse(dr["MasterOrder"].ToString());
                accountsinfomodel.MemberOrder = int.Parse(dr["MemberOrder"].ToString());
                accountsinfomodel.MemberOverDate = dr["MemberOverDate"].ToString();
                accountsinfomodel.Loveliness = (int)dr["Loveliness"];
                accountsinfomodel.Gender = int.Parse(dr["Gender"].ToString());
                accountsinfomodel.Nullity = (bool)dr["Nullity"];
                accountsinfomodel.StunDown = (bool)dr["StunDown"];
                accountsinfomodel.MoorMachine = int.Parse(dr["MoorMachine"].ToString());
                accountsinfomodel.MachineSerial = dr["MachineSerial"].ToString();
                accountsinfomodel.WebLogonTimes = (int)dr["WebLogonTimes"];
                accountsinfomodel.GameLogonTimes = (int)dr["GameLogonTimes"];
                accountsinfomodel.RegisterIP = dr["RegisterIP"].ToString();
                accountsinfomodel.LastLogonIP = dr["LastLogonIP"].ToString();
                accountsinfomodel.RegisterDate = dr["RegisterDate"].ToString();
                accountsinfomodel.LastLogonDate = dr["LastLogonDate"].ToString();
                accountsinfomodel.CustomFaceVer = int.Parse(dr["CustomFaceVer"].ToString());
                accountsinfomodel.C_IDNO = dr["C_IDNO"].ToString();
                accountsinfomodel.C_ADDRESS = dr["C_ADDRESS"].ToString();
                accountsinfomodel.C_EMAIL = dr["C_EMAIL"].ToString();
                accountsinfomodel.C_PROTECTQUES = dr["C_PROTECTQUES"].ToString();
                accountsinfomodel.C_PROTECTANSW = dr["C_PROTECTANSW"].ToString();
                accountsinfomodel.C_BOXPASSWORD = dr["C_BOXPASSWORD"].ToString();
                accountsinfomodel.OlePassWord = dr["OlePassWord"].ToString();
                accountsinfomodel.IsCheckPassWord = (bool)dr["IsCheckPassWord"];
                accountsinfomodel.IsBoxPassWord = (bool)dr["IsBoxPassWord"];
                accountsinfomodel.PassWordCode = dr["PassWordCode"].ToString();
                accountsinfomodel.LoginKick = dr["LoginKick"].ToString();
                accountsinfomodel.UserCode = dr["UserCode"].ToString();
                accountsinfomodel.yy = (int)dr["yy"];
                accountsinfomodel.LoginDateTime = dr["LoginDateTime"].ToString();
                accountsinfomodel.YYCar = (int)dr["YYCar"];
            }
            dr.Close();
            accountsinfomodel.GameID = newID;
            UpdateAccountsInfo(accountsinfomodel);
        }

        public List<AccountsInfoModel> GetAccountsOrderByLove(int? top, bool desc)
        {
            string sql = string.Format("select {0} * from AccountsInfo order by Loveliness {1}",
                                       top.HasValue ? "top " + top : "", desc ? "desc" : "asc");
            SqlDataReader reader = QPGameUserDBHelper.GetDataReader(sql);
            List<AccountsInfoModel> list = new List<AccountsInfoModel>();
            while (reader.Read())
            {
                list.Add(SetAccountsInfo(reader));
            }
            reader.Close();
            return list;
        }

        public void UpdateLoginInfo(string userName, string ip)
        {
            string sql =
                    @"UPDATE [QPGameUserDB].[dbo].[AccountsInfo]
                           SET [WebLogonTimes] = [WebLogonTimes] + 1    
                              ,[LastLogonIP] = @LastLogonIP
                              ,[LastLogonDate] = getdate()    
                         WHERE accounts=@accounts";
            List<SqlParameter> list = new List<SqlParameter>();
            list.Add(QPGameUserDBHelper.CreateParameter("@LastLogonIP", SqlDbType.NVarChar, ip));
            list.Add(QPGameUserDBHelper.CreateParameter("@accounts", SqlDbType.NVarChar, userName));
            QPGameUserDBHelper.GetExcuteNonQuery(sql, list.ToArray());
        }

        public bool IsReg(string account)
        {
            const string sql = @"select count(*) from AccountsInfo where accounts=@accounts";
            SqlParameter param = QPGameUserDBHelper.CreateParameter("@accounts", SqlDbType.NVarChar, account);
            object obj = QPGameUserDBHelper.ExecuteScalar(sql, param);
            return int.Parse(obj.ToString()) > 0;
        }

        public bool HasRegAccount(string regAcc)
        {
            const string sql = @"select count(*) from AccountsInfo where RegAccounts=@accounts";
            SqlParameter param = QPGameUserDBHelper.CreateParameter("@accounts", SqlDbType.NVarChar, regAcc);
            object obj = QPGameUserDBHelper.ExecuteScalar(sql, param);
            return int.Parse(obj.ToString()) > 0;
        }

        private static AccountsInfoModel SetAccountsInfo(IDataRecord dr)
        {
            AccountsInfoModel accountsinfomodel = new AccountsInfoModel();
            accountsinfomodel.UserID = (int)dr["UserID"];
            accountsinfomodel.GameID = (int)dr["GameID"];
            accountsinfomodel.ProtectID = (int)dr["ProtectID"];
            accountsinfomodel.Accounts = dr["Accounts"].ToString();
            accountsinfomodel.RegAccounts = dr["RegAccounts"].ToString();
            accountsinfomodel.UnderWrite = dr["UnderWrite"].ToString();
            accountsinfomodel.LogonPass = dr["LogonPass"].ToString();
            accountsinfomodel.InsurePass = dr["InsurePass"].ToString();
            accountsinfomodel.QQ = dr["QQ"].ToString();
            accountsinfomodel.Phone = dr["Phone"].ToString();
            accountsinfomodel.SpreaderID = dr["SpreaderID"].ToString();
            //accountsinfomodel.FaceID = (int)dr["FaceID"];
            accountsinfomodel.FaceID = int.Parse(dr["FaceID"].ToString());
            accountsinfomodel.Experience = (int)dr["Experience"];
            accountsinfomodel.UserRight = (int)dr["UserRight"];
            accountsinfomodel.MasterRight = (int)dr["MasterRight"];
            accountsinfomodel.ServiceRight = (int)dr["ServiceRight"];
            //accountsinfomodel.MasterOrder = (int)dr["MasterOrder"];
            accountsinfomodel.MasterOrder = int.Parse(dr["MasterOrder"].ToString());
            //accountsinfomodel.MemberOrder = (int)dr["MemberOrder"];
            accountsinfomodel.MemberOrder = int.Parse(dr["MemberOrder"].ToString());
            accountsinfomodel.MemberOverDate = dr["MemberOverDate"].ToString();
            accountsinfomodel.Loveliness = (int)dr["Loveliness"];
            //accountsinfomodel.Gender = (int)dr["Gender"];
            accountsinfomodel.Gender = int.Parse(dr["Gender"].ToString());
            accountsinfomodel.Nullity = (bool)dr["Nullity"];
            accountsinfomodel.StunDown = (bool)dr["StunDown"];
            //accountsinfomodel.MoorMachine = (int)dr["MoorMachine"];
            accountsinfomodel.MoorMachine = int.Parse(dr["MoorMachine"].ToString());
            accountsinfomodel.MachineSerial = dr["MachineSerial"].ToString();
            accountsinfomodel.WebLogonTimes = (int)dr["WebLogonTimes"];
            accountsinfomodel.GameLogonTimes = (int)dr["GameLogonTimes"];
            accountsinfomodel.RegisterIP = dr["RegisterIP"].ToString();
            accountsinfomodel.LastLogonIP = dr["LastLogonIP"].ToString();
            accountsinfomodel.RegisterDate = dr["RegisterDate"].ToString();
            accountsinfomodel.LastLogonDate = dr["LastLogonDate"].ToString();
            //accountsinfomodel.CustomFaceVer = (int)dr["CustomFaceVer"];
            accountsinfomodel.CustomFaceVer = int.Parse(dr["CustomFaceVer"].ToString());
            accountsinfomodel.C_IDNO = dr["C_IDNO"].ToString();
            accountsinfomodel.C_ADDRESS = dr["C_ADDRESS"].ToString();
            accountsinfomodel.C_EMAIL = dr["C_EMAIL"].ToString();
            accountsinfomodel.C_PROTECTQUES = dr["C_PROTECTQUES"].ToString();
            accountsinfomodel.C_PROTECTANSW = dr["C_PROTECTANSW"].ToString();
            accountsinfomodel.C_BOXPASSWORD = dr["C_BOXPASSWORD"].ToString();
            accountsinfomodel.OlePassWord = dr["OlePassWord"].ToString();
            accountsinfomodel.IsCheckPassWord = (bool)dr["IsCheckPassWord"];
            accountsinfomodel.IsBoxPassWord = (bool)dr["IsBoxPassWord"];
            accountsinfomodel.PassWordCode = dr["PassWordCode"].ToString();
            accountsinfomodel.LoginKick = dr["LoginKick"].ToString();
            accountsinfomodel.UserCode = dr["UserCode"].ToString();
            //accountsinfomodel.Del = (int)dr["Del"];
            //accountsinfomodel.Del = int.Parse(dr["Del"].ToString());
            accountsinfomodel.yy = (int)dr["yy"];
            accountsinfomodel.LoginDateTime = dr["LoginDateTime"].ToString();
            accountsinfomodel.YYCar = (int)dr["YYCar"];
            return accountsinfomodel;
        }

        public bool GetAccountsBe(string username)
        {
            string sql=@"select count(*) from AccountsInfo where Accounts=@Accounts";
            SqlParameter parm = QPGameUserDBHelper.CreateParameter("@Accounts", SqlDbType.NVarChar, username);
            try
            {
                object obj= QPGameUserDBHelper.ExecuteScalar(sql, parm);

                return int.Parse(obj.ToString())>0;
            }
            catch (Exception)
            {

                return false;
            }
        }
    }
}
