using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;
using System.Data;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class VipidDAL
    {
        #region Utilities
        private VipidModel GetVipidFromReader(IDataReader dr)
        {
            VipidModel vipidmodel = new VipidModel();
            vipidmodel.ID = Convert.ToInt32(dr["ID"]);
            vipidmodel.IsStatus = Convert.ToInt32(dr["ID"]);
            vipidmodel.GameID = Convert.ToInt32(dr["GameID"]);
            vipidmodel.ID = Convert.ToInt32(dr["ID"]);
            vipidmodel.IsType = dr["IsType"].ToString();
            vipidmodel.Score = Convert.ToInt32(dr["Score"]);
            return vipidmodel;
        }
        #endregion

        #region ��������
        StringBuilder sb = new StringBuilder();
        /// <summary>
        /// ��������
        /// </summary>
        /// <param name="vipidmodel"></param>
        /// <returns></returns>
        public bool InsertVipid(VipidModel vipidmodel)
        {
            sb.Length = 0;
            sb.Append("insert into Vipid (GameID,IsStatus,Score,IsType,UserID) values (");
            if (vipidmodel.GameID != 0)
            {
                sb.Append(vipidmodel.GameID);
                sb.Append(",");
            }
            if (vipidmodel.IsStatus != -1)
            {
                sb.Append(vipidmodel.IsStatus);
                sb.Append(",");
            }
            if (vipidmodel.Score != 0)
            {
                sb.Append(vipidmodel.Score);
                sb.Append(",");
            }
            if (vipidmodel.IsType != null)
            {
                sb.Append("'" + vipidmodel.IsType + "'");
                sb.Append(",");
            }
            if (vipidmodel.UserID != 0)
            {
                sb.Append(vipidmodel.UserID);
            }
            sb.Append(")");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception) { return false; }
        }
        #endregion

        #region ����
        /// <summary>
        /// ����
        /// </summary>
        /// <param name="gameid"></param>
        /// <returns></returns>
        public List<VipidModel> Search(string where)
        {

            List<VipidModel> list = new List<VipidModel>();
            StringBuilder sb = new StringBuilder();
            string sql = string.Format("select * from (select top 16 *  from Vipid where " + where + " IsStatus=0) a  ORDER by NEWID()");

            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                list.Add(GetVipidFromReader(dr));
            }
            dr.Close();
            return list;
        }
        #endregion

        #region �������
        public bool Update(VipidModel vipmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update Vipid set ");
            sb.Append(" UserID=" + vipmodel.UserID + ",");
            sb.Append(" IsStatus=" + vipmodel.IsStatus);
            sb.Append(" where ID=" + vipmodel.ID + "");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        #endregion

        #region Model
        public VipidModel GetVipidModel(int GameID)
        {
            VipidModel result = new VipidModel();
            StringBuilder sb = new StringBuilder();
            if (GameID > 0)
            {
                string sql = string.Format("select * from Vipid where IsStatus=0 and GameID={0}", GameID);
                SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
                while (dr.Read())
                {
                    result = GetVipidFromReader(dr);
                }
                dr.Close();
                return result;
            }
            else
                return result;
        }
        #endregion

        #region �ж��Ƿ����
        public bool IsGameID(int gameid)
        {
            List<VipidModel> list = new List<VipidModel>();
            string sql = string.Format("select * from Vipid where IsStatus=0 and GameID={0}", gameid);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                list.Add(GetVipidFromReader(dr));
            }
            dr.Close();
            if (list.Count > 0)
            {
                return true;
            }
            else
                return false;
        }
        #endregion

    }
}
