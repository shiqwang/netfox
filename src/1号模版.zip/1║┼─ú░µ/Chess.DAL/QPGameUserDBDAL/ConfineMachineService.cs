using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class ConfineMachineService
    {
        public bool InsertConfineMachine(ConfineMachineModel confinemachinemodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into ConfineMachine values(");
            sb.Append(confinemachinemodel.EnjoinLogon);
            sb.Append(",'");
            sb.Append(confinemachinemodel.EnjoinRegister);
            sb.Append(",'");
            sb.Append(confinemachinemodel.EnjoinOverDate);
            sb.Append(",'");
            sb.Append(confinemachinemodel.CollectDate);
            sb.Append(",'");
            sb.Append(confinemachinemodel.CollectNote);
            sb.Append("')");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateConfineMachine(ConfineMachineModel confinemachinemodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update ConfineMachine set ");
            sb.Append("EnjoinLogon=" + (confinemachinemodel.EnjoinLogon ? 1 : 0) + ",");
            sb.Append("EnjoinRegister=" + (confinemachinemodel.EnjoinRegister ? 1 : 0) + ",");
            sb.Append("EnjoinOverDate='" + confinemachinemodel.EnjoinOverDate + "',");
            sb.Append("CollectDate='" + confinemachinemodel.CollectDate + "',");
            sb.Append("CollectNote='" + confinemachinemodel.CollectNote + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where MachineSerial='" + confinemachinemodel.MachineSerial + "' ");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteConfineMachine(string MachineSerial)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from ConfineMachine ");
            sb.Append(" where MachineSerial='" + MachineSerial + "' ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<ConfineMachineModel> GetAllConfineMachine()
        {
            List<ConfineMachineModel> list = new List<ConfineMachineModel>();
            string sql = string.Format("select * from ConfineMachine");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                ConfineMachineModel confinemachinemodel = new ConfineMachineModel();
                confinemachinemodel.MachineSerial = dr["MachineSerial"].ToString();
                confinemachinemodel.EnjoinLogon = (bool)dr["EnjoinLogon"];
                confinemachinemodel.EnjoinRegister = (bool)dr["EnjoinRegister"];
                confinemachinemodel.EnjoinOverDate = (DateTime)dr["EnjoinOverDate"];
                confinemachinemodel.CollectDate = (DateTime)dr["CollectDate"];
                confinemachinemodel.CollectNote = dr["CollectNote"].ToString();
                list.Add(confinemachinemodel);
            }
            dr.Close();
            return list;
        }
        public ConfineMachineModel GetConfineMachineByMachineSerial(string MachineSerial)
        {
            string sql = string.Format("select * from ConfineMachine where MachineSerial={0}",MachineSerial);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            ConfineMachineModel confinemachinemodel = new ConfineMachineModel();
            if (dr.Read())
            {
                confinemachinemodel.MachineSerial = dr[0].ToString();
                confinemachinemodel.EnjoinLogon = (bool)dr[1];
                confinemachinemodel.EnjoinRegister = (bool)dr[2];
                confinemachinemodel.EnjoinOverDate = (DateTime)dr[3];
                confinemachinemodel.CollectDate = (DateTime)dr[4];
                confinemachinemodel.CollectNote = dr[5].ToString();
            }
            dr.Close();
            return confinemachinemodel;
        }
    }
}
