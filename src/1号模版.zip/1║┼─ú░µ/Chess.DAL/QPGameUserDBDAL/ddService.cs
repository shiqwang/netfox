using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class ddService
    {
        public List<ddModel> GetAlldd()
        {
            List<ddModel> list = new List<ddModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from dd");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    ddModel ddmodel = new ddModel();
                    ddmodel.id = int.Parse(dr["id"].ToString());
                    ddmodel.number = dr["number"].ToString();
                    ddmodel.rmb = dr["rmb"].ToString();
                    ddmodel.rq = dr["rq"].ToString();
                    ddmodel.username = dr["username"].ToString();
                    ddmodel.yxb = long.Parse(dr["yxb"].ToString());
                    list.Add(ddmodel);
                }
            }
            dr.Close();
            return list;
        }
        public List<ddModel> GetddByID(int ID)
        {
            List<ddModel> list = new List<ddModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from dd where id=");
            sb.Append(ID);
            sb.Append("");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    ddModel ddmodel = new ddModel();
                    ddmodel.id = int.Parse(dr["id"].ToString());
                    ddmodel.number = dr["number"].ToString();
                    ddmodel.rmb = dr["rmb"].ToString();
                    ddmodel.rq = dr["rq"].ToString();
                    ddmodel.username = dr["username"].ToString();
                    ddmodel.yxb = long.Parse(dr["yxb"].ToString());
                    list.Add(ddmodel);
                }
            }
            dr.Close();
            return list;
        }
        public List<ddModel> GetddByName(string Name)
        {
            List<ddModel> list = new List<ddModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from dd where username='");
            sb.Append(Name);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    ddModel ddmodel = new ddModel();
                    ddmodel.id = int.Parse(dr["id"].ToString());
                    ddmodel.number = dr["number"].ToString();
                    ddmodel.rmb = dr["rmb"].ToString();
                    ddmodel.rq = dr["rq"].ToString();
                    ddmodel.username = dr["username"].ToString();
                    ddmodel.yxb = long.Parse(dr["yxb"].ToString());
                    list.Add(ddmodel);
                }
            }
            dr.Close();
            return list;
        }
        public ddModel GetddInfoByID(int ID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from dd where id=");
            sb.Append(ID);
            sb.Append("");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            ddModel ddmodel = new ddModel();
            if (dr.Read())
            {
                ddmodel.id = int.Parse(dr["id"].ToString());
                ddmodel.number = dr["number"].ToString();
                ddmodel.rmb = dr["rmb"].ToString();
                ddmodel.rq = dr["rq"].ToString();
                ddmodel.username = dr["username"].ToString();
                ddmodel.yxb = long.Parse(dr["yxb"].ToString());
            }
            dr.Close();
            return ddmodel;
        }
        public ddModel GetSumByName(string Name)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select sum(yxb) as yxb from dd where username='");
            sb.Append(Name);
            sb.Append("' group by username");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            ddModel ddmodel = new ddModel();
            if (dr.Read())
            {
                ddmodel.yxb = long.Parse(dr["yxb"].ToString());
            }
            dr.Close();
            return ddmodel;
        }
        public ddModel GetddInfoByName(string Name)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from dd where username='");
            sb.Append(Name);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sb.ToString());
            ddModel ddmodel = new ddModel();
            if (dr.Read())
            {
                ddmodel.id = int.Parse(dr["id"].ToString());
                ddmodel.number = dr["number"].ToString();
                ddmodel.rmb = dr["rmb"].ToString();
                ddmodel.rq = dr["rq"].ToString();
                ddmodel.username = dr["username"].ToString();
                ddmodel.yxb = long.Parse(dr["yxb"].ToString());
            }
            dr.Close();
            return ddmodel;
        }
    }
}
