using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class GameIdentifierService
    {
        public bool InsertGameIdentifier(GameIdentifierModel gameidentifiermodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into GameIdentifier values (");
            sb.Append(gameidentifiermodel.GameID);
            sb.Append(",'");
            sb.Append(gameidentifiermodel.IDLevel);
            sb.Append("')");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateGameIdentifier(GameIdentifierModel gameidentifiermodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameIdentifier set ");
            sb.Append("GameID=" + gameidentifiermodel.GameID + ",");
            sb.Append("IDLevel=" + gameidentifiermodel.IDLevel + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where UserID=" + gameidentifiermodel.UserID + " ");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteGameIdentifier(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from GameIdentifier ");
            sb.Append(" where UserID=" + UserID + " ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<GameIdentifierModel> GetAllGameIdentifier()
        {
            List<GameIdentifierModel> list = new List<GameIdentifierModel>();
            string sql = string.Format("select * from GameIdentifier");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                GameIdentifierModel gameidentifiermodel = new GameIdentifierModel();
                gameidentifiermodel.UserID = (int)dr["UserID"];
                gameidentifiermodel.GameID = (int)dr["GameID"];
                gameidentifiermodel.IDLevel = (int)dr["IDLevel"];
                list.Add(gameidentifiermodel);
            }
            dr.Close();
            return list;
        }
        public GameIdentifierModel GetGameIdentifierById(int UserID)
        {
            string sql = string.Format("select * from GameIdentifier where UserID={0}",UserID);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            GameIdentifierModel gameidentifiermodel = new GameIdentifierModel();
            if (dr.Read())
            {
                gameidentifiermodel.UserID = (int)dr[0];
                gameidentifiermodel.GameID = (int)dr[1];
                gameidentifiermodel.IDLevel = (int)dr[2];
            }
            dr.Close();
            return gameidentifiermodel;
        }
    }
}
