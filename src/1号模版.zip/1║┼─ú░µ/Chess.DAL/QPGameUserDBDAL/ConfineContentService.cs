using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class ConfineContentService
    {
        public bool InsertConfineContent(ConfineContentModel confinecontentmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into ConfineContent values (");
            sb.Append(confinecontentmodel.CollectDate);
            sb.Append(")");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateConfineContent(ConfineContentModel confinecontentmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update ConfineContent set ");
            sb.Append("CollectDate='" + confinecontentmodel.CollectDate + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where String='" + confinecontentmodel.String + "' ");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteConfineContent(string String)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from ConfineContent ");
            sb.Append(" where String='" + String + "' ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<ConfineContentModel> GetAllConfineContent()
        {
            List<ConfineContentModel> list = new List<ConfineContentModel>();
            string sql = string.Format("select * from ConfineContent");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                ConfineContentModel confinecontentmodel = new ConfineContentModel();
                confinecontentmodel.String = dr["String"].ToString();
                confinecontentmodel.CollectDate = (DateTime)dr["CollectDate"];
                list.Add(confinecontentmodel);
            }
            dr.Close();
            return list;
        }
        public ConfineContentModel GetConfineContentByString(string String)
        {
            string sql = string.Format("select * from ConfineContent where String='{0}'",String);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            ConfineContentModel confinecontentmodel = new ConfineContentModel();
            if (dr.Read())
            {
                confinecontentmodel.String = dr[0].ToString();
                confinecontentmodel.CollectDate = (DateTime)dr[1];
            }
            dr.Close();
            return confinecontentmodel;
        }
    }
}
