using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameUserDBDAL
{
    public class CustomFaceInfoService
    {
        public bool InsertCustomFaceInfo(CustomFaceInfoModel customfaceinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into CustomFaceInfo values (");
            sb.Append(customfaceinfomodel.CustomFaceImage);
            sb.Append(")");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateCustomFaceInfo(CustomFaceInfoModel customfaceinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update CustomFaceInfo set ");
            sb.Append("CustomFaceImage=" + customfaceinfomodel.CustomFaceImage + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n,1);
            sb.Append(" where UserID=" + customfaceinfomodel.UserID + " ");
            try
            {
                return (DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteCustomFaceInfo(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from CustomFaceInfo ");
            sb.Append(" where UserID=" + UserID + " ");
            return DBHelper.QPGameUserDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<CustomFaceInfoModel> GetAllCustomFaceInfo()
        {
            List<CustomFaceInfoModel> list = new List<CustomFaceInfoModel>();
            string sql = string.Format("select * from CustomFaceInfo");
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                CustomFaceInfoModel customfaceinfomodel = new CustomFaceInfoModel();
                customfaceinfomodel.UserID = (int)dr["UserID"];
                customfaceinfomodel.CustomFaceImage = (byte[])dr["CustomFaceImage"];
                list.Add(customfaceinfomodel);
            }
            dr.Close();
            return list;
        }
        public CustomFaceInfoModel GetCustomFaceInfoById(int UserID)
        {
            string sql = string.Format("select * from CustomFaceInfo where UserID={0}",UserID);
            SqlDataReader dr = DBHelper.QPGameUserDBHelper.GetDataReader(sql);
            CustomFaceInfoModel customfaceinfomodel = new CustomFaceInfoModel();
            if (dr.Read())
            {
                customfaceinfomodel.UserID = (int)dr[0];
                customfaceinfomodel.CustomFaceImage = (byte[])dr[1];
            }
            dr.Close();
            return customfaceinfomodel;
        }
    }
}
