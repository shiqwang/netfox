using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPServerInfoDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPServerInfoDBDAL
{
    public class DataBaseInfoService
    {
        public bool InsertDataBaseInfo(DataBaseInfoModel databaseinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into DataBaseInfo values (");
            sb.Append(databaseinfomodel.DBPort);
            sb.Append(",'");
            sb.Append(databaseinfomodel.DBUser);
            sb.Append(",'");
            sb.Append(databaseinfomodel.DBPassword);
            sb.Append(",'");
            sb.Append(databaseinfomodel.Information);
            sb.Append("')");
            try
            {
                return (DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateDataBaseInfo(DataBaseInfoModel databaseinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update DataBaseInfo set ");
            sb.Append("DBPort=" + databaseinfomodel.DBPort + ",");
            sb.Append("DBUser='" + databaseinfomodel.DBUser + "',");
            sb.Append("DBPassword='" + databaseinfomodel.DBPassword + "',");
            sb.Append("Information='" + databaseinfomodel.Information + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where DBAddr='" + databaseinfomodel.DBAddr + "' ");
            try
            {
                return (DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteDataBaseInfo(string DBAddr)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from DataBaseInfo ");
            sb.Append(" where DBAddr='" + DBAddr + "' ");
            return DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<DataBaseInfoModel> GetAllDataBaseInfo()
        {
            List<DataBaseInfoModel> list = new List<DataBaseInfoModel>();
            string sql = string.Format("select * from DataBaseInfo");
            SqlDataReader dr = DBHelper.QPServerInfoDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                DataBaseInfoModel databaseinfomodel = new DataBaseInfoModel();
                databaseinfomodel.DBAddr = dr["DBAddr"].ToString();
                databaseinfomodel.DBPort = (int)dr["DBPort"];
                databaseinfomodel.DBUser = dr["DBUser"].ToString();
                databaseinfomodel.DBPassword = dr["DBPassword"].ToString();
                databaseinfomodel.Information = dr["Information"].ToString();
                list.Add(databaseinfomodel);
            }
            dr.Close();
            return list;
        }
        public DataBaseInfoModel GetDataBaseInfoByDBAddr(string DBAddr)
        {
            string sql = string.Format("select * from DataBaseInfo where DBAddr={0}",DBAddr);
            SqlDataReader dr = DBHelper.QPServerInfoDBHelper.GetDataReader(sql);
            DataBaseInfoModel databaseinfomodel = new DataBaseInfoModel();
            if (dr.Read())
            {
                databaseinfomodel.DBAddr = dr[0].ToString();
                databaseinfomodel.DBPort = (int)dr[1];
                databaseinfomodel.DBUser = dr[2].ToString();
                databaseinfomodel.DBPassword = dr[3].ToString();
                databaseinfomodel.Information = dr[4].ToString();
            }
            dr.Close();
            return databaseinfomodel;
        }
    }
}
