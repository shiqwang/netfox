using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPServerInfoDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPServerInfoDBDAL
{
    public class GameTypeItemService
    {
        public bool InsertGameTypeItem(GameTypeItemModel gametypeitemmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into GameTypeItem values (");
            sb.Append(gametypeitemmodel.JoinID);
            sb.Append(",'");
            sb.Append(gametypeitemmodel.SortID);
            sb.Append(",'");
            sb.Append(gametypeitemmodel.TypeName);
            sb.Append(",'");
            sb.Append(gametypeitemmodel.Nullity);
            sb.Append("')");
            try
            {
                return (DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateGameTypeItem(GameTypeItemModel gametypeitemmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameTypeItem set ");
            sb.Append("JoinID=" + gametypeitemmodel.JoinID + ",");
            sb.Append("SortID=" + gametypeitemmodel.SortID + ",");
            sb.Append("TypeName='" + gametypeitemmodel.TypeName + "',");
            sb.Append("Nullity=" + (gametypeitemmodel.Nullity ? 1 : 0) + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where TypeID=" + gametypeitemmodel.TypeID + " ");
            try
            {
                return (DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteGameTypeItem(int TypeID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from GameTypeItem ");
            sb.Append(" where TypeID=" + TypeID + " ");
            return DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<GameTypeItemModel> GetAllGameTypeItem()
        {
            List<GameTypeItemModel> list = new List<GameTypeItemModel>();
            string sql = string.Format("select * from GameTypeItem");
            SqlDataReader dr = DBHelper.QPServerInfoDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                GameTypeItemModel gametypeitemmodel = new GameTypeItemModel();
                gametypeitemmodel.TypeID = (int)dr["TypeID"];
                gametypeitemmodel.JoinID = (int)dr["JoinID"];
                gametypeitemmodel.SortID = (int)dr["SortID"];
                gametypeitemmodel.TypeName = dr["TypeName"].ToString();
                gametypeitemmodel.Nullity = (bool)dr["Nullity"];
                list.Add(gametypeitemmodel);
            }
            dr.Close();
            return list;
        }
        public GameTypeItemModel GetGameTypeItemById(int TypeID)
        {
            string sql = string.Format("select * from GameTypeItem where TypeID={0}",TypeID);
            SqlDataReader dr = DBHelper.QPServerInfoDBHelper.GetDataReader(sql);
            GameTypeItemModel gametypeitemmodel = new GameTypeItemModel();
            if (dr.Read())
            {
                gametypeitemmodel.TypeID = (int)dr[0];
                gametypeitemmodel.JoinID = (int)dr[1];
                gametypeitemmodel.SortID = (int)dr[2];
                gametypeitemmodel.TypeName = dr[3].ToString();
                gametypeitemmodel.Nullity = (bool)dr[4];
            }
            dr.Close();
            return gametypeitemmodel;
        }
    }
}
