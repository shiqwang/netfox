using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPServerInfoDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPServerInfoDBDAL
{
    public class GameKindItemService
    {
        public bool InsertGameKindItem(GameKindItemModel gamekinditemmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into GameKindItem values (");
            sb.Append(gamekinditemmodel.TypeID);
            sb.Append(",'");
            sb.Append(gamekinditemmodel.JoinID);
            sb.Append(",'");
            sb.Append(gamekinditemmodel.SortID);
            sb.Append(",'");
            sb.Append(gamekinditemmodel.KindName);
            sb.Append(",'");
            sb.Append(gamekinditemmodel.ProcessName);
            sb.Append(",'");
            sb.Append(gamekinditemmodel.MaxVersion);
            sb.Append(",'");
            sb.Append(gamekinditemmodel.DataBaseName);
            sb.Append(",'");
            sb.Append(gamekinditemmodel.Nullity);
            sb.Append(",'");
            sb.Append(gamekinditemmodel.GzUrl);
            sb.Append("')");
            try
            {
                return (DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateGameKindItem(GameKindItemModel gamekinditemmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameKindItem set ");
            sb.Append("TypeID=" + gamekinditemmodel.TypeID + ",");
            sb.Append("JoinID=" + gamekinditemmodel.JoinID + ",");
            sb.Append("SortID=" + gamekinditemmodel.SortID + ",");
            sb.Append("KindName='" + gamekinditemmodel.KindName + "',");
            sb.Append("ProcessName='" + gamekinditemmodel.ProcessName + "',");
            sb.Append("MaxVersion=" + gamekinditemmodel.MaxVersion + ",");
            sb.Append("DataBaseName='" + gamekinditemmodel.DataBaseName + "',");
            sb.Append("Nullity=" + (gamekinditemmodel.Nullity ? 1 : 0) + ",");
            sb.Append("GzUrl='" + gamekinditemmodel.GzUrl + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where KindID=" + gamekinditemmodel.KindID + " ");
            try
            {
                return (DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteGameKindItem(int KindID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from GameKindItem ");
            sb.Append(" where KindID=" + KindID + " ");
            return DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<GameKindItemModel> GetAllGameKindItem()
        {
            List<GameKindItemModel> list = new List<GameKindItemModel>();
            string sql = string.Format("select * from GameKindItem");
            SqlDataReader dr = DBHelper.QPServerInfoDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                GameKindItemModel gamekinditemmodel = new GameKindItemModel();
                gamekinditemmodel.KindID = (int)dr["KindID"];
                gamekinditemmodel.TypeID = (int)dr["TypeID"];
                gamekinditemmodel.JoinID = (int)dr["JoinID"];
                gamekinditemmodel.SortID = (int)dr["SortID"];
                gamekinditemmodel.KindName = dr["KindName"].ToString();
                gamekinditemmodel.ProcessName = dr["ProcessName"].ToString();
                gamekinditemmodel.MaxVersion = (int)dr["MaxVersion"];
                gamekinditemmodel.DataBaseName = dr["DataBaseName"].ToString();
                gamekinditemmodel.Nullity = (bool)dr["Nullity"];
                gamekinditemmodel.GzUrl = dr["GzUrl"].ToString();
                list.Add(gamekinditemmodel);
            }
            dr.Close();
            return list;
        }
        public GameKindItemModel GetGameKindItemById(int KindID)
        {
            string sql = string.Format("select * from GameKindItem KindID={0}",KindID);
            SqlDataReader dr = DBHelper.QPServerInfoDBHelper.GetDataReader(sql);
            GameKindItemModel gamekinditemmodel = new GameKindItemModel();
            if (dr.Read())
            {
                gamekinditemmodel.KindID = (int)dr[0];
                gamekinditemmodel.TypeID = (int)dr[1];
                gamekinditemmodel.JoinID = (int)dr[2];
                gamekinditemmodel.SortID = (int)dr[3];
                gamekinditemmodel.KindName = dr[4].ToString();
                gamekinditemmodel.ProcessName = dr[5].ToString();
                gamekinditemmodel.MaxVersion = (int)dr[6];
                gamekinditemmodel.DataBaseName = dr[7].ToString();
                gamekinditemmodel.Nullity = (bool)dr[8];
                gamekinditemmodel.GzUrl = dr[9].ToString();
            }
            dr.Close();
            return gamekinditemmodel;
        }
    }
}
