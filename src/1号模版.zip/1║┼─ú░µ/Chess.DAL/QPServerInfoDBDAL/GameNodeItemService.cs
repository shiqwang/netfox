using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPServerInfoDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPServerInfoDBDAL
{
    public class GameNodeItemService
    {
        public bool InsertGameNodeItem(GameNodeItemModel gamenodeitemmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into GameNodeItem values (");
            sb.Append(gamenodeitemmodel.KindID);
            sb.Append(",'");
            sb.Append(gamenodeitemmodel.JoinID);
            sb.Append(",'");
            sb.Append(gamenodeitemmodel.SortID);
            sb.Append(",'");
            sb.Append(gamenodeitemmodel.NodeName);
            sb.Append(",'");
            sb.Append(gamenodeitemmodel.Nullity);
            sb.Append("')");
            try
            {
                return (DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateGameNodeItem(GameNodeItemModel gamenodeitemmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameNodeItem set ");
            sb.Append("KindID=" + gamenodeitemmodel.KindID + ",");
            sb.Append("JoinID=" + gamenodeitemmodel.JoinID + ",");
            sb.Append("SortID=" + gamenodeitemmodel.SortID + ",");
            sb.Append("NodeName='" + gamenodeitemmodel.NodeName + "',");
            sb.Append("Nullity=" + (gamenodeitemmodel.Nullity ? 1 : 0) + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where NodeID=" + gamenodeitemmodel.NodeID + " ");
            try
            {
                return (DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteGameNodeItem(int NodeID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from GameNodeItem ");
            sb.Append(" where NodeID=" + NodeID + " ");
            return DBHelper.QPServerInfoDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<GameNodeItemModel> GetAllGameNodeItem()
        {
            List<GameNodeItemModel> list = new List<GameNodeItemModel>();
            string sql = string.Format("select * from GameNodeItem");
            SqlDataReader dr = DBHelper.QPServerInfoDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                GameNodeItemModel gamenodeitemmodel = new GameNodeItemModel();
                gamenodeitemmodel.NodeID = (int)dr["NodeID"];
                gamenodeitemmodel.KindID = (int)dr["KindID"];
                gamenodeitemmodel.JoinID = (int)dr["JoinID"];
                gamenodeitemmodel.SortID = (int)dr["SortID"];
                gamenodeitemmodel.NodeName = dr["NodeName"].ToString();
                gamenodeitemmodel.Nullity = (bool)dr["Nullity"];
                list.Add(gamenodeitemmodel);
            }
            dr.Close();
            return list;
        }
        public GameNodeItemModel GetGameNodeItemByID(int NodeID)
        {
            string sql = string.Format("select * from GameNodeItem where NodeID={0}",NodeID);
            SqlDataReader dr = DBHelper.QPServerInfoDBHelper.GetDataReader(sql);
            GameNodeItemModel gamenodeitemmodel = new GameNodeItemModel();
            if (dr.Read())
            {
                gamenodeitemmodel.NodeID = (int)dr[0];
                gamenodeitemmodel.KindID = (int)dr[1];
                gamenodeitemmodel.JoinID = (int)dr[2];
                gamenodeitemmodel.SortID = (int)dr[3];
                gamenodeitemmodel.NodeName = dr[4].ToString();
                gamenodeitemmodel.Nullity = (bool)dr[5];
            }
            dr.Close();
            return gamenodeitemmodel;
        }
    }
}
