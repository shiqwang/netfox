using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPGameMatchDB;
using System.Data.SqlClient;

namespace Chess.DAL.QPGameMatchDB
{
    public class GameScoreInfoService
    {
        public bool InsertGameScoreInfo(GameScoreInfoModel gamescoreinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into GameScoreInfo values (");
            sb.Append(gamescoreinfomodel.UserID);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.Score);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.WinCount);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.LostCount);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.DrawCount);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.FleeCount);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.UserRight);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.MasterRight);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.MasterOrder);
            sb.Append(",'");
            sb.Append(gamescoreinfomodel.RegisterIP);
            sb.Append("','");
            sb.Append(gamescoreinfomodel.LastLogonIP);
            sb.Append("','");
            sb.Append(gamescoreinfomodel.RegisterDate);
            sb.Append("','");
            sb.Append(gamescoreinfomodel.LastLogonDate);
            sb.Append("',");
            sb.Append(gamescoreinfomodel.AllLogonTimes);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.PlayTimeCount);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.OnLineTimeCount);
            sb.Append(")");
            return DBHelper.QPGameMatchDBHelper.GetExcuteNonQuery(sb.ToString())>0 ? true : false;
        }
        public bool UpdateGameScoreInfo(int UserID, int UserRight)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameScoreInfo set ");
            sb.Append("UserRight="+UserRight+"");
            sb.Append(" where UserID="+UserID+"");
            return DBHelper.QPGameMatchDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public GameScoreInfoModel GetCount()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select count(*) as MasterOrder from GameScoreInfo where UserRight=268435456");
            SqlDataReader dr = DBHelper.QPGameMatchDBHelper.GetDataReader(sb.ToString());
            GameScoreInfoModel gamescoreinfomodel = new GameScoreInfoModel();
            if (dr.Read())
            {
                gamescoreinfomodel.MasterOrder = int.Parse(dr[0].ToString());
            }
            dr.Close();
            return gamescoreinfomodel;
        }
    }
}
