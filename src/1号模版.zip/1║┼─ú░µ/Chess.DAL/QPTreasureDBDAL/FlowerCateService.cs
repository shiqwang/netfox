using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class FlowerCateService
    {
        public bool InsertFlowerCate(FlowerCateModel flowercatemodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into FlowerCate values (");
            sb.Append(flowercatemodel.ID);
            sb.Append(",'");
            sb.Append(flowercatemodel.Name);
            sb.Append(",'");
            sb.Append(flowercatemodel.Price);
            sb.Append(",'");
            sb.Append(flowercatemodel.SendUserCharm);
            sb.Append(",'");
            sb.Append(flowercatemodel.RcvUserCharm);
            sb.Append(",'");
            sb.Append(flowercatemodel.Discount);
            sb.Append(",'");
            sb.Append(flowercatemodel.Nullity);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateFlowerCate(FlowerCateModel flowercatemodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update FlowerCate set ");
            sb.Append("Name='" + flowercatemodel.Name + "',");
            sb.Append("Price=" + flowercatemodel.Price + ",");
            sb.Append("SendUserCharm=" + flowercatemodel.SendUserCharm + ",");
            sb.Append("RcvUserCharm=" + flowercatemodel.RcvUserCharm + ",");
            sb.Append("Discount=" + flowercatemodel.Discount + ",");
            sb.Append("Nullity=" + (flowercatemodel.Nullity ? 1 : 0) + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where ID=" + flowercatemodel.ID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteFlowerCate(int ID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from FlowerCate ");
            sb.Append(" where ID=" + ID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<FlowerCateModel> GetAllFlowerCate()
        {
            List<FlowerCateModel> list = new List<FlowerCateModel>();
            string sql = string.Format("select * from FlowerCate");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                FlowerCateModel flowercatemodel = new FlowerCateModel();
                flowercatemodel.ID =(int)dr["ID"];
                flowercatemodel.Name = dr["Name"].ToString();
                flowercatemodel.Price = (int)dr["Price"];
                flowercatemodel.SendUserCharm = (int)dr["SendUserCharm"];
                flowercatemodel.RcvUserCharm = (int)dr["RcvUserCharm"];
                flowercatemodel.Discount = (int)dr["Discount"];
                flowercatemodel.Nullity = (bool)dr["Nullity"];
                list.Add(flowercatemodel);
            }
            dr.Close();
            return list;
        }
        public FlowerCateModel GetFlowerCateByID(int ID)
        {
            string sql = string.Format("select * from FlowerCate where ID={0}",ID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            FlowerCateModel flowercatemodel = new FlowerCateModel();
            if (dr.Read())
            {
                flowercatemodel.ID = (int)dr[0];
                flowercatemodel.Name = dr[1].ToString();
                flowercatemodel.Price = (int)dr[2];
                flowercatemodel.SendUserCharm = (int)dr[3];
                flowercatemodel.RcvUserCharm = (int)dr[4];
                flowercatemodel.Discount = (int)dr[5];
                flowercatemodel.Nullity = (bool)dr[6];
            }
            dr.Close();
            return flowercatemodel;
        }
    }
}
