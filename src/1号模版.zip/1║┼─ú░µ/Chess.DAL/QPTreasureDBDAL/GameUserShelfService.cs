using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class GameUserShelfService
    {
        public bool InsertGameUserShelf(GameUserShelfModel gameusershelfmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into GameUserShelf values (");
            sb.Append(gameusershelfmodel.UserID);
            sb.Append(",");
            sb.Append(gameusershelfmodel.CateID);
            sb.Append(",");
            sb.Append(gameusershelfmodel.KindID);
            sb.Append(",");
            sb.Append(gameusershelfmodel.PropCount);
            sb.Append(",");
            sb.Append(gameusershelfmodel.UsedFlag);
            sb.Append(",'");
            sb.Append(gameusershelfmodel.WriteDate);
            sb.Append("','");
            sb.Append(gameusershelfmodel.ClientIP);
            sb.Append("')");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateGameUserShelfByCateID(int CateID,long PropCount,string WriteDate)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameUserShelf set ");
            sb.Append("PropCount="+PropCount+",");
            sb.Append("WriteDate='" + WriteDate + "'");
            sb.Append(" where CateID=" + CateID + "");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateGameUserShelf(GameUserShelfModel gameusershelfmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameUserShelf set ");
            sb.Append("UserID=" + gameusershelfmodel.UserID + ",");
            sb.Append("CateID=" + gameusershelfmodel.CateID + ",");
            sb.Append("KindID=" + gameusershelfmodel.KindID + ",");
            sb.Append("PropCount=" + gameusershelfmodel.PropCount + ",");
            sb.Append("UsedFlag=" + gameusershelfmodel.UsedFlag + ",");
            sb.Append("WriteDate='" + gameusershelfmodel.WriteDate + "',");
            sb.Append("ClientIP='" + gameusershelfmodel.ClientIP + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where UserID="+gameusershelfmodel.UserID+"");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteGameUserShelf(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from GameUserShelf ");
            sb.Append("where UserID="+UserID+"");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<GameUserShelfModel> GetAllGameUserShelf()
        {
            List<GameUserShelfModel> list = new List<GameUserShelfModel>();
            string sql = string.Format("select * from GameUserShelf");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                GameUserShelfModel gameusershelfmodel = new GameUserShelfModel();
                gameusershelfmodel.UserID = (int)dr["UserID"];
                gameusershelfmodel.CateID = (int)dr["CateID"];
                gameusershelfmodel.KindID = (int)dr["KindID"];
                gameusershelfmodel.PropCount = (long)dr["PropCount"];
                gameusershelfmodel.UsedFlag = (int)dr["UsedFlag"];
                gameusershelfmodel.WriteDate = dr["WriteDate"].ToString();
                gameusershelfmodel.ClientIP = dr["ClientIP"].ToString();
                list.Add(gameusershelfmodel);
            }
            dr.Close();
            return list;
        }
        public GameUserShelfModel GetGameUserShelfById(int UserID,int CateID)
        {
            GameUserShelfModel gameusershelfmodel = new GameUserShelfModel();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from GameUserShelf where UserID=");
            sb.Append(UserID);
            sb.Append(" and CateID =");
            sb.Append(CateID);
            sb.Append("");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            if (dr.Read())
            {
                gameusershelfmodel.UserID = (int)dr[0];
                gameusershelfmodel.CateID = (int)dr[1];
                gameusershelfmodel.KindID = (int)dr[2];
                gameusershelfmodel.PropCount = (long)dr[3];
                gameusershelfmodel.UsedFlag = int.Parse(dr[4].ToString());
                gameusershelfmodel.WriteDate = dr[5].ToString();
                gameusershelfmodel.ClientIP = dr[6].ToString();
            }
            dr.Close();
            return gameusershelfmodel;
        }
    }
}
