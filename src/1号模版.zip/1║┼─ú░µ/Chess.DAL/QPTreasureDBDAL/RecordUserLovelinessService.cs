using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class RecordUserLovelinessService
    {
        public bool InsertRecordUserLoveliness(RecordUserLovelinessModel recorduserlovelinessmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into RecordUserLoveliness values (");
            sb.Append(recorduserlovelinessmodel.UserID);
            sb.Append(",'");
            sb.Append(recorduserlovelinessmodel.KindID);
            sb.Append(",'");
            sb.Append(recorduserlovelinessmodel.ServerID);
            sb.Append(",'");
            sb.Append(recorduserlovelinessmodel.Loveliness);
            sb.Append(",'");
            sb.Append(recorduserlovelinessmodel.WriteDate);
            sb.Append(",'");
            sb.Append(recorduserlovelinessmodel.ClientIP);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateRecordUserLoveliness(RecordUserLovelinessModel recorduserlovelinessmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update RecordUserLoveliness set ");
            sb.Append("UserID=" + recorduserlovelinessmodel.UserID + ",");
            sb.Append("KindID=" + recorduserlovelinessmodel.KindID + ",");
            sb.Append("ServerID=" + recorduserlovelinessmodel.ServerID + ",");
            sb.Append("Loveliness=" + recorduserlovelinessmodel.Loveliness + ",");
            sb.Append("WriteDate='" + recorduserlovelinessmodel.WriteDate + "',");
            sb.Append("ClientIP='" + recorduserlovelinessmodel.ClientIP + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where RecordID=" + recorduserlovelinessmodel.RecordID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteRecordUserLoveliness(int RecordID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from RecordUserLoveliness ");
            sb.Append(" where RecordID=" + RecordID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<RecordUserLovelinessModel> GetAllRecordUserLoveliness()
        {
            List<RecordUserLovelinessModel> list = new List<RecordUserLovelinessModel>();
            string sql = string.Format("select * from RecordUserLoveliness");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                RecordUserLovelinessModel recorduserlovelinessmodel = new RecordUserLovelinessModel();
                recorduserlovelinessmodel.RecordID = (int)dr["RecordID"];
                recorduserlovelinessmodel.UserID = (int)dr["UserID"];
                recorduserlovelinessmodel.KindID = (int)dr["KindID"];
                recorduserlovelinessmodel.ServerID = (int)dr["ServerID"];
                recorduserlovelinessmodel.Loveliness = (int)dr["Loveliness"];
                recorduserlovelinessmodel.WriteDate = (DateTime)dr["WriteDate"];
                recorduserlovelinessmodel.ClientIP = dr["ClientIP"].ToString();
                list.Add(recorduserlovelinessmodel);
            }
            dr.Close();
            return list;
        }
        public RecordUserLovelinessModel GetRecordUserLovelinessById(int RecordID)
        {
            string sql = string.Format("select * from RecordUserLoveliness where RecordID={0}",RecordID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            RecordUserLovelinessModel recorduserlovelinessmodel = new RecordUserLovelinessModel();
            if (dr.Read())
            {
                recorduserlovelinessmodel.RecordID = (int)dr[0];
                recorduserlovelinessmodel.UserID = (int)dr[1];
                recorduserlovelinessmodel.KindID = (int)dr[2];
                recorduserlovelinessmodel.ServerID = (int)dr[3];
                recorduserlovelinessmodel.Loveliness = (int)dr[4];
                recorduserlovelinessmodel.WriteDate = (DateTime)dr[5];
                recorduserlovelinessmodel.ClientIP = dr[6].ToString();
            }
            dr.Close();
            return recorduserlovelinessmodel;
        }
    }
}
