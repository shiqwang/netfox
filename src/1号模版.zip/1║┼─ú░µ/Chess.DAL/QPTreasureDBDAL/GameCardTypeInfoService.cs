using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class GameCardTypeInfoService
    {
        public GameCardTypeInfoModel GetGameCardTypeInfoByID(int cardid)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from GameCardTypeInfo where CardID=");
            sb.Append(cardid);
            sb.Append("");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            GameCardTypeInfoModel gamecardtypeinfomodel = new GameCardTypeInfoModel();
            while (dr.Read())
            {
                gamecardtypeinfomodel.CardID = int.Parse(dr["CardID"].ToString());
                gamecardtypeinfomodel.CardTitle = dr["CardTitle"].ToString();
                gamecardtypeinfomodel.Score = int.Parse(dr["Score"].ToString());
                gamecardtypeinfomodel.Memo = dr["Memo"].ToString();
                gamecardtypeinfomodel.OverDate = int.Parse(dr["OverDate"].ToString());
                gamecardtypeinfomodel.IsPresent = bool.Parse(dr["IsPresent"].ToString());
                gamecardtypeinfomodel.Memberorder = int.Parse(dr["Memberorder"].ToString());
            }
            dr.Close();
            return gamecardtypeinfomodel;
        }
    }
}
