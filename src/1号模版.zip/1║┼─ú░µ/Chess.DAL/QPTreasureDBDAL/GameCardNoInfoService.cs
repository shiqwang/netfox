using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;
using Chess.DAL.DBHelper;
using System.Data;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class GameCardNoInfoService
    {
        public GameCardNoInfoModel GetGameCardNoInfoByCardNo(string cardno)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from GameCardNoInfo where CardNo='");
            sb.Append(cardno);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            GameCardNoInfoModel gamecardnoinfomodel = new GameCardNoInfoModel();
            while (dr.Read())
            {
                gamecardnoinfomodel.ID = int.Parse(dr["ID"].ToString());
                gamecardnoinfomodel.CardNo = dr["CardNo"].ToString();
                gamecardnoinfomodel.CardPass = dr["CardPass"].ToString();
                gamecardnoinfomodel.CardTypeID = int.Parse(dr["CardTypeID"].ToString());
                gamecardnoinfomodel.BatchNo = int.Parse(dr["BatchNo"].ToString());
                gamecardnoinfomodel.Nullity = bool.Parse(dr["Nullity"].ToString());
                gamecardnoinfomodel.CreateDate = dr["CreateDate"].ToString();
                gamecardnoinfomodel.UseDate = dr["UseDate"].ToString();
                gamecardnoinfomodel.UserID = int.Parse(dr["UserID"].ToString());
                gamecardnoinfomodel.Accounts = dr["Accounts"].ToString();
            }
            dr.Close();
            return gamecardnoinfomodel;
        }
        public bool UpdateGameNoInfoByCardNo(string cardno, bool nullity, string usedate, int userid, string username)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameCardNoInfo set ");
            sb.Append("Nullity='" + nullity + "',");
            sb.Append("UseDate='" + usedate + "',");
            sb.Append("UserID=" + userid + ",");
            sb.Append("Accounts='" + username + "'");
            sb.Append(" where CardNo='" + cardno + "'");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }

        public bool GetCardNoBe(string cardno)
        {
            string sql = @"select count(*) from GameCardNoInfo where CardNo=@CardNo";
            SqlParameter pram = QPTreasureDBHelper.CreateParameter("@CardNo", SqlDbType.VarChar, cardno);
            try
            {
                object obj = QPTreasureDBHelper.ExecuteScalar(sql, pram);
                return int.Parse(obj.ToString()) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
