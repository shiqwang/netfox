using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class GameCardTmpInfoService
    {
        public GameCardTmpInfoModel GetCardPwdByCardNo(string cardno)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from GameCardTmpInfo where CardNo='");
            sb.Append(cardno);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            GameCardTmpInfoModel gamecardtmpinfomodel = new GameCardTmpInfoModel();
            while (dr.Read())
            {
                gamecardtmpinfomodel.CardNo = dr["CardNo"].ToString();
                gamecardtmpinfomodel.CardPassword = dr["CardPassword"].ToString();
                gamecardtmpinfomodel.CardTypeID = int.Parse(dr["CardTypeID"].ToString());
                gamecardtmpinfomodel.Memo = dr["Memo"].ToString();
            }
            dr.Close();
            return gamecardtmpinfomodel;
        }
    }
}
