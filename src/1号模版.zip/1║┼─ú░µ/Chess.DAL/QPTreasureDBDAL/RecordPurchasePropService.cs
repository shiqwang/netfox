using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class RecordPurchasePropService
    {
        public bool InsertRecordPurchaseProp(RecordPurchasePropModel recordpurchasepropmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into RecordPurchaseProp values (");
            sb.Append(recordpurchasepropmodel.SendUserID);
            sb.Append(",");
            sb.Append(recordpurchasepropmodel.RcvUserID);
            sb.Append(",");
            sb.Append(recordpurchasepropmodel.KindID);
            sb.Append(",");
            sb.Append(recordpurchasepropmodel.ServerID);
            sb.Append(",");
            sb.Append(recordpurchasepropmodel.CateID);
            sb.Append(",");
            sb.Append(recordpurchasepropmodel.CurCount);
            sb.Append(",");
            sb.Append(recordpurchasepropmodel.OnceCount);
            sb.Append(",");
            sb.Append(recordpurchasepropmodel.PachurseCount);
            sb.Append(",");
            sb.Append(recordpurchasepropmodel.SpendScore);
            sb.Append(",'");
            sb.Append(recordpurchasepropmodel.ClientIP);
            sb.Append("','");
            sb.Append(recordpurchasepropmodel.PurchaseDate);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateRecordPurchaseProp(RecordPurchasePropModel recordpurchasepropmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update RecordPurchaseProp set ");
            sb.Append("SendUserID=" + recordpurchasepropmodel.SendUserID + ",");
            sb.Append("RcvUserID=" + recordpurchasepropmodel.RcvUserID + ",");
            sb.Append("KindID=" + recordpurchasepropmodel.KindID + ",");
            sb.Append("ServerID=" + recordpurchasepropmodel.ServerID + ",");
            sb.Append("CateID=" + recordpurchasepropmodel.CateID + ",");
            sb.Append("CurCount=" + recordpurchasepropmodel.CurCount + ",");
            sb.Append("OnceCount=" + recordpurchasepropmodel.OnceCount + ",");
            sb.Append("PachurseCount=" + recordpurchasepropmodel.PachurseCount + ",");
            sb.Append("SpendScore=" + recordpurchasepropmodel.SpendScore + ",");
            sb.Append("ClientIP='" + recordpurchasepropmodel.ClientIP + "',");
            sb.Append("PurchaseDate='" + recordpurchasepropmodel.PurchaseDate + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where RecordID=" + recordpurchasepropmodel.RecordID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteRecordPurchaseProp(int RecordID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from RecordPurchaseProp ");
            sb.Append(" where RecordID=" + RecordID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public bool DeleteByUserID(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from RecordPurchaseProp ");
            sb.Append(" where RcvUserID=" + UserID + " and CateID=11");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<RecordPurchasePropModel> GetAllRecordPurchaseProp()
        {
            List<RecordPurchasePropModel> list = new List<RecordPurchasePropModel>();
            string sql = string.Format("select * from RecordPurchaseProp");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                RecordPurchasePropModel recordpurchasepropmodel = new RecordPurchasePropModel();
                recordpurchasepropmodel.RecordID = (int)dr["RecordID"];
                recordpurchasepropmodel.SendUserID = (int)dr["SendUserID"];
                recordpurchasepropmodel.RcvUserID = (int)dr["RcvUserID"];
                recordpurchasepropmodel.KindID = (int)dr["KindID"];
                recordpurchasepropmodel.ServerID = (int)dr["ServerID"];
                recordpurchasepropmodel.CateID = (int)dr["CateID"];
                recordpurchasepropmodel.CurCount = (int)dr["CurCount"];
                recordpurchasepropmodel.OnceCount = (int)dr["OnceCount"];
                recordpurchasepropmodel.PachurseCount = (int)dr["PachurseCount"];
                recordpurchasepropmodel.SpendScore = (int)dr["SpendScore"];
                recordpurchasepropmodel.ClientIP = dr["ClientIP"].ToString();
                recordpurchasepropmodel.PurchaseDate = dr["PurchaseDate"].ToString();
                list.Add(recordpurchasepropmodel);
            }
            dr.Close();
            return list;
        }
        public RecordPurchasePropModel GetRecordPurchasePropById(int RecordID)
        {
            string sql = string.Format("select * from RecordPurchaseProp where RecordID={0}",RecordID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            RecordPurchasePropModel recordpurchasepropmodel = new RecordPurchasePropModel();
            if (dr.Read())
            {
                recordpurchasepropmodel.RecordID = (int)dr[0];
                recordpurchasepropmodel.SendUserID = (int)dr[1];
                recordpurchasepropmodel.RcvUserID = (int)dr[2];
                recordpurchasepropmodel.KindID = (int)dr[3];
                recordpurchasepropmodel.ServerID = (int)dr[4];
                recordpurchasepropmodel.CateID = (int)dr[5];
                recordpurchasepropmodel.CurCount = (int)dr[6];
                recordpurchasepropmodel.OnceCount = (int)dr[7];
                recordpurchasepropmodel.PachurseCount = (int)dr[8];
                recordpurchasepropmodel.SpendScore = (int)dr[9];
                recordpurchasepropmodel.ClientIP = dr[10].ToString();
                recordpurchasepropmodel.PurchaseDate = dr[11].ToString();
            }
            dr.Close();
            return recordpurchasepropmodel;
        }
        public RecordPurchasePropModel GetRecordPurchasePropByUserID(int UserID)
        {
            string sql = string.Format("select * from RecordPurchaseProp where RcvUserID={0}", UserID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            RecordPurchasePropModel recordpurchasepropmodel = new RecordPurchasePropModel();
            if (dr.Read())
            {
                recordpurchasepropmodel.RecordID = (int)dr[0];
                recordpurchasepropmodel.SendUserID = (int)dr[1];
                recordpurchasepropmodel.RcvUserID = (int)dr[2];
                recordpurchasepropmodel.KindID = (int)dr[3];
                recordpurchasepropmodel.ServerID = (int)dr[4];
                recordpurchasepropmodel.CateID = (int)dr[5];
                recordpurchasepropmodel.CurCount = (int)dr[6];
                recordpurchasepropmodel.OnceCount = (int)dr[7];
                recordpurchasepropmodel.PachurseCount = (int)dr[8];
                recordpurchasepropmodel.SpendScore = (int)dr[9];
                recordpurchasepropmodel.ClientIP = dr[10].ToString();
                recordpurchasepropmodel.PurchaseDate = dr[11].ToString();
            }
            dr.Close();
            return recordpurchasepropmodel;
        }
    }
}
