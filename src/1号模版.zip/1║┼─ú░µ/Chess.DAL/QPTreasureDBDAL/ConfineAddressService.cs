using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class ConfineAddressService
    {
        public bool InsertConfineAddress(ConfineAddressModel confineaddressmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into ConfineAddress values (");
            sb.Append(confineaddressmodel.AddrString);
            sb.Append(",'");
            sb.Append(confineaddressmodel.EnjoinLogon);
            sb.Append(",'");
            sb.Append(confineaddressmodel.EnjoinOverDate);
            sb.Append(",'");
            sb.Append(confineaddressmodel.CollectDate);
            sb.Append(",'");
            sb.Append(confineaddressmodel.CollectNote);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateConfineAddress(ConfineAddressModel confineaddressmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update ConfineAddress set ");
            sb.Append("EnjoinLogon=" + (confineaddressmodel.EnjoinLogon ? 1 : 0) + ",");
            sb.Append("EnjoinOverDate='" + confineaddressmodel.EnjoinOverDate + "',");
            sb.Append("CollectDate='" + confineaddressmodel.CollectDate + "',");
            sb.Append("CollectNote='" + confineaddressmodel.CollectNote + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where AddrString='" + confineaddressmodel.AddrString + "' ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteConfineAddress(string AddrString)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from ConfineAddress ");
            sb.Append(" where AddrString='" + AddrString + "' ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<ConfineAddressModel> GetAllConfineAddress()
        {
            List<ConfineAddressModel> list = new List<ConfineAddressModel>();
            string sql = string.Format("select * from ConfineAddress");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                ConfineAddressModel confineaddressmodel = new ConfineAddressModel();
                confineaddressmodel.AddrString = dr["AddrString"].ToString();
                confineaddressmodel.EnjoinLogon = (bool)dr["EnjoinLogon"];
                confineaddressmodel.EnjoinOverDate = (DateTime)dr["EnjoinOverDate"];
                confineaddressmodel.CollectDate = (DateTime)dr["CollectDate"];
                confineaddressmodel.CollectNote = dr["CollectNote"].ToString();
                list.Add(confineaddressmodel);
            }
            dr.Close();
            return list;
        }
        public ConfineAddressModel GetConfineAddressByAddrString(string AddrString)
        {
            string sql = string.Format("select * from ConfineAddress where AddrString={0}",AddrString);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            ConfineAddressModel confineaddressmodel = new ConfineAddressModel();
            if (dr.Read())
            {
                confineaddressmodel.AddrString = dr[0].ToString();
                confineaddressmodel.EnjoinLogon = (bool)dr[1];
                confineaddressmodel.EnjoinOverDate = (DateTime)dr[2];
                confineaddressmodel.CollectDate = (DateTime)dr[3];
                confineaddressmodel.CollectNote = dr[4].ToString();
            }
            dr.Close();
            return confineaddressmodel;
        }
    }
}
