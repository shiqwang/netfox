using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class RecordUserLeaveService
    {
        public bool InsertRecordUserLeave(RecordUserLeaveModel recorduserleavemodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into RecordUserLeave values (");
            sb.Append(recorduserleavemodel.UserID);
            sb.Append(",'");
            sb.Append(recorduserleavemodel.Score);
            sb.Append(",'");
            sb.Append(recorduserleavemodel.Revenue);
            sb.Append(",'");
            sb.Append(recorduserleavemodel.KindID);
            sb.Append(",'");
            sb.Append(recorduserleavemodel.ServerID);
            sb.Append(",'");
            sb.Append(recorduserleavemodel.PlayTimeCount);
            sb.Append(",'");
            sb.Append(recorduserleavemodel.OnLineTimeCount);
            sb.Append(",'");
            sb.Append(recorduserleavemodel.LeaveTime);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateRecordUserLeave(RecordUserLeaveModel recorduserleavemodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update RecordUserLeave set ");
            sb.Append("UserID=" + recorduserleavemodel.UserID + ",");
            sb.Append("Score=" + recorduserleavemodel.Score + ",");
            sb.Append("Revenue=" + recorduserleavemodel.Revenue + ",");
            sb.Append("KindID=" + recorduserleavemodel.KindID + ",");
            sb.Append("ServerID=" + recorduserleavemodel.ServerID + ",");
            sb.Append("PlayTimeCount=" + recorduserleavemodel.PlayTimeCount + ",");
            sb.Append("OnLineTimeCount=" + recorduserleavemodel.OnLineTimeCount + ",");
            sb.Append("LeaveTime='" + recorduserleavemodel.LeaveTime + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where UserID="+recorduserleavemodel.UserID+" ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteRecordUserLeave(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from RecordUserLeave ");
            sb.Append(" where UserID="+UserID+" ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<RecordUserLeaveModel> GetAllRecordUserLeave()
        {
            List<RecordUserLeaveModel> list = new List<RecordUserLeaveModel>();
            string sql = string.Format("select * from RecordUserLeave");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                RecordUserLeaveModel recorduserleavemodel = new RecordUserLeaveModel();
                recorduserleavemodel.UserID =(int)dr["UserID"];
                recorduserleavemodel.Score = (long)dr["Score"];
                recorduserleavemodel.Revenue = (long)dr["Revenue"];
                recorduserleavemodel.KindID = (int)dr["KindID"];
                recorduserleavemodel.ServerID = (int)dr["ServerID"];
                recorduserleavemodel.PlayTimeCount = (int)dr["PlayTimeCount"];
                recorduserleavemodel.OnLineTimeCount = (int)dr["OnLineTimeCount"];
                recorduserleavemodel.LeaveTime = dr["LeaveTime"].ToString();
                list.Add(recorduserleavemodel);
            }
            dr.Close();
            return list;
        }
        public RecordUserLeaveModel GetRecordUserLeaveById(int UserID)
        {
            string sql = string.Format("select * from RecordUserLeave where UserID={0}",UserID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            RecordUserLeaveModel recorduserleavemodel = new RecordUserLeaveModel();
            if (dr.Read())
            {
                recorduserleavemodel.UserID = (int)dr[0];
                recorduserleavemodel.Score = (long)dr[1];
                recorduserleavemodel.Revenue = (long)dr[2];
                recorduserleavemodel.KindID = (int)dr[3];
                recorduserleavemodel.ServerID = (int)dr[4];
                recorduserleavemodel.PlayTimeCount = (int)dr[5];
                recorduserleavemodel.OnLineTimeCount = (int)dr[6];
                recorduserleavemodel.LeaveTime = dr[7].ToString();
            }
            dr.Close();
            return recorduserleavemodel;
        }
        public RecordUserLeaveModel GetRecordUserLeaveNewByID(int UserID, int ServerID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from RecordUserLeave where UserID=");
            sb.Append(UserID);
            sb.Append(" and LeaveTime in (select max(LeaveTime) from RecordUserLeave where Userid=");
            sb.Append(UserID);
            sb.Append(" and ServerID=");
            sb.Append(ServerID);
            sb.Append(")");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            RecordUserLeaveModel recorduserleavemodel = new RecordUserLeaveModel();
            if (dr.Read())
            {
                recorduserleavemodel.UserID = (int)dr["UserID"];
                recorduserleavemodel.Score = (long)dr["Score"];
                recorduserleavemodel.Revenue = (long)dr["Revenue"];
                recorduserleavemodel.KindID = (int)dr["KindID"];
                recorduserleavemodel.ServerID = (int)dr["ServerID"];
                recorduserleavemodel.PlayTimeCount = (int)dr["PlayTimeCount"];
                recorduserleavemodel.OnLineTimeCount = (int)dr["OnLineTimeCount"];
                recorduserleavemodel.LeaveTime = dr["LeaveTime"].ToString();
            }
            dr.Close();
            return recorduserleavemodel;
        }
    }
}
