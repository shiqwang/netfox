using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class SystemStreamInfoService
    {
        public bool InsertSystemStreamInfo(SystemStreamInfoModel systemstreaminfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into SystemStreamInfo values (");
            sb.Append(systemstreaminfomodel.DateID);
            sb.Append(",'");
            sb.Append(systemstreaminfomodel.KindID);
            sb.Append(",'");
            sb.Append(systemstreaminfomodel.ServerID);
            sb.Append(",'");
            sb.Append(systemstreaminfomodel.LogonCount);
            sb.Append(",'");
            sb.Append(systemstreaminfomodel.LogOutCount);
            sb.Append(",'");
            sb.Append(systemstreaminfomodel.CollectDate);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateSystemStreamInfo(SystemStreamInfoModel systemstreaminfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update SystemStreamInfo set ");
            sb.Append("LogonCount=" + systemstreaminfomodel.LogonCount + ",");
            sb.Append("LogOutCount=" + systemstreaminfomodel.LogOutCount + ",");
            sb.Append("CollectDate='" + systemstreaminfomodel.CollectDate + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where DateID=" + systemstreaminfomodel.DateID + " and KindID=" + systemstreaminfomodel.KindID + " and ServerID=" + systemstreaminfomodel.ServerID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteSystemStreamInfo(int DateID, int KindID, int ServerID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from SystemStreamInfo ");
            sb.Append(" where DateID=" + DateID + " and KindID=" + KindID + " and ServerID=" + ServerID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<SystemStreamInfoModel> GetAllSystemStreamInfo()
        {
            List<SystemStreamInfoModel> list = new List<SystemStreamInfoModel>();
            string sql = string.Format("select * from SystemStreamInfo");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                SystemStreamInfoModel systemstreaminfomodel = new SystemStreamInfoModel();
                systemstreaminfomodel.DateID = (int)dr["DateID"];
                systemstreaminfomodel.KindID = (int)dr["KindID"];
                systemstreaminfomodel.ServerID = (int)dr["ServerID"];
                systemstreaminfomodel.LogonCount = (int)dr["LogonCount"];
                systemstreaminfomodel.LogOutCount = (int)dr["LogOutCount"];
                systemstreaminfomodel.CollectDate = (DateTime)dr["CollectDate"];
                list.Add(systemstreaminfomodel);
            }
            dr.Close();
            return list;
        }
        private SystemStreamInfoModel GetSystemStreamInfoModel(SqlDataReader dr)
        {
            SystemStreamInfoModel systemstreaminfomodel = new SystemStreamInfoModel();
            systemstreaminfomodel.DateID = (int)dr[0];
            systemstreaminfomodel.KindID = (int)dr[1];
            systemstreaminfomodel.ServerID = (int)dr[2];
            systemstreaminfomodel.LogonCount = (int)dr[3];
            systemstreaminfomodel.LogOutCount = (int)dr[4];
            systemstreaminfomodel.CollectDate = (DateTime)dr[5];
            return systemstreaminfomodel;
        }
        public List<SystemStreamInfoModel> GetSystemStreamInfo(int DateID, int KindID, int ServerID)
        {
            List<SystemStreamInfoModel> list = new List<SystemStreamInfoModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from SystemStreamInfo ");
            sb.Append(" where DateID=" + DateID + " and KindID=" + KindID + " and ServerID=" + ServerID + " ");
            SystemStreamInfoModel systemstreaminfomodel = new SystemStreamInfoModel();
            try
            {
                SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
                while (dr.Read())
                {
                    list.Add(GetSystemStreamInfoModel(dr));
                }
                dr.Close();
                return list;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
