using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class RecordExchangeLovelinessService
    {
        public bool InsertRecordExchangeLoveliness(RecordExchangeLovelinessModel recordexchaneloveliness)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into RecordExchangeLoveliness values (");
            sb.Append(recordexchaneloveliness.RecordID);
            sb.Append(",'");
            sb.Append(recordexchaneloveliness.UserID);
            sb.Append(",'");
            sb.Append(recordexchaneloveliness.KindID);
            sb.Append(",'");
            sb.Append(recordexchaneloveliness.ServerID);
            sb.Append(",'");
            sb.Append(recordexchaneloveliness.Loveliness);
            sb.Append(",'");
            sb.Append(recordexchaneloveliness.InsureScore);
            sb.Append(",'");
            sb.Append(recordexchaneloveliness.ExchangeDate);
            sb.Append(",'");
            sb.Append(recordexchaneloveliness.ClientIP);            
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateRecordExchangeLoveliness(RecordExchangeLovelinessModel recordexchaneloveliness)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update RecordExchangeLoveliness set ");
            sb.Append("UserID=" + recordexchaneloveliness.UserID + ",");
            sb.Append("KindID=" + recordexchaneloveliness.KindID + ",");
            sb.Append("ServerID=" + recordexchaneloveliness.ServerID + ",");
            sb.Append("Loveliness=" + recordexchaneloveliness.Loveliness + ",");
            sb.Append("InsureScore=" + recordexchaneloveliness.InsureScore + ",");
            sb.Append("ExchangeDate='" + recordexchaneloveliness.ExchangeDate + "',");
            sb.Append("ClientIP='" + recordexchaneloveliness.ClientIP + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n,1);
            sb.Append(" where RecordID=" + recordexchaneloveliness.RecordID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteRecordExchangeLoveliness(int RecordID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from RecordExchangeLoveliness ");
            sb.Append(" where RecordID=" + RecordID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<RecordExchangeLovelinessModel> GetAllRecordExchangeLoveliness()
        {
            List<RecordExchangeLovelinessModel> list = new List<RecordExchangeLovelinessModel>();
            string sql = string.Format("select * from RecordExchangeLoveliness");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                RecordExchangeLovelinessModel recordexchangeloveliness = new RecordExchangeLovelinessModel();
                recordexchangeloveliness.RecordID = (int)dr["RecordID"];
                recordexchangeloveliness.UserID = (int)dr["UserID"];
                recordexchangeloveliness.KindID = (int)dr["KindID"];
                recordexchangeloveliness.ServerID = (int)dr["ServerID"];
                recordexchangeloveliness.Loveliness = (long)dr["Loveliness"];
                recordexchangeloveliness.InsureScore = (long)dr["InsureScore"];
                recordexchangeloveliness.ExchangeDate = (DateTime)dr["ExchangeDate"];
                recordexchangeloveliness.ClientIP = dr["ClientIP"].ToString();
                list.Add(recordexchangeloveliness);
            }
            dr.Close();
            return list;
        }
        public RecordExchangeLovelinessModel GetRecordExchangeLovelinessById(int RecordID)
        {
            string sql = string.Format("select * from RecordExchangeLoveliness where RecordID={0}",RecordID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            RecordExchangeLovelinessModel recordexchangeloveliness = new RecordExchangeLovelinessModel();
            if (dr.Read())
            {
                recordexchangeloveliness.RecordID = (int)dr[0];
                recordexchangeloveliness.UserID = (int)dr[1];
                recordexchangeloveliness.KindID = (int)dr[2];
                recordexchangeloveliness.ServerID = (int)dr[3];
                recordexchangeloveliness.Loveliness = (long)dr[4];
                recordexchangeloveliness.InsureScore = (long)dr[5];
                recordexchangeloveliness.ExchangeDate = (DateTime)dr[6];
                recordexchangeloveliness.ClientIP = dr[7].ToString();
            }
            dr.Close();
            return recordexchangeloveliness;
        }
    }
}
