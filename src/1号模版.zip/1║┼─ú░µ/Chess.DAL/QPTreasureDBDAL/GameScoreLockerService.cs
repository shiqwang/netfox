using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class GameScoreLockerService
    {
        public bool InsertGameScoreLocker(GameScoreLockerModel gamescorelockermodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into GameScoreLocker values (");
            sb.Append(gamescorelockermodel.UserID);
            sb.Append(",'");
            sb.Append(gamescorelockermodel.KindID);
            sb.Append(",'");
            sb.Append(gamescorelockermodel.ServerID);
            sb.Append(",'");
            sb.Append(gamescorelockermodel.CollectDate);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateGameScoreLocker(GameScoreLockerModel gamescorelockermodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameScoreLocker set ");
            sb.Append("CollectDate='" + gamescorelockermodel.CollectDate + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where UserID=" + gamescorelockermodel.UserID + " and KindID=" + gamescorelockermodel.KindID + " and ServerID=" + gamescorelockermodel.ServerID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteGameScoreLocker(int UserID, int KindID, int ServerID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from GameScoreLocker ");
            sb.Append(" where UserID=" + UserID + " and KindID=" + KindID + " and ServerID=" + ServerID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<GameScoreLockerModel> GetAllGameScoreLocker()
        {
            List<GameScoreLockerModel> list = new List<GameScoreLockerModel>();
            string sql = string.Format("select * from GameScoreLocker");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                GameScoreLockerModel gamescorelockermodel = new GameScoreLockerModel();
                gamescorelockermodel.UserID = (int)dr["UserID"];
                gamescorelockermodel.KindID = (int)dr["KindID"];
                gamescorelockermodel.ServerID = (int)dr["ServerID"];
                gamescorelockermodel.CollectDate = (DateTime)dr["CollectDate"];
                list.Add(gamescorelockermodel);
            }
            dr.Close();
            return list;
        }
        private GameScoreLockerModel GetGameScoreLockerModel(SqlDataReader dr)
        {
            GameScoreLockerModel gamescorelockermodel = new GameScoreLockerModel();
            gamescorelockermodel.UserID = (int)dr[0];
            gamescorelockermodel.KindID = (int)dr[1];
            gamescorelockermodel.ServerID = (int)dr[2];
            gamescorelockermodel.CollectDate = (DateTime)dr[3];
            return gamescorelockermodel;
        }
        public List<GameScoreLockerModel> GetGameScoreLocker(int UserID, int KindID, int ServerID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from GameScoreLocker ");
            sb.Append(" where UserID=" + UserID + " and KindID=" + KindID + " and ServerID=" + ServerID + " ");
            List<GameScoreLockerModel> list = new List<GameScoreLockerModel>();
            GameScoreLockerModel gamescorelockermodel = new GameScoreLockerModel();
            try
            {
                SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
                while(dr.Read())
                {
                   list.Add(GetGameScoreLockerModel(dr));
                }
                dr.Close();
                return list;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
