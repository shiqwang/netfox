using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class RecordUserPropService
    {
        public bool InsertRecordUserProp(RecordUserPropModel recorduserpropmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into RecordUserProp values (");
            sb.Append(recorduserpropmodel.UserID);
            sb.Append(",");
            sb.Append(recorduserpropmodel.KindID);
            sb.Append(",");
            sb.Append(recorduserpropmodel.CateID);
            sb.Append(",");
            sb.Append(recorduserpropmodel.PropCount);
            sb.Append(",'");
            sb.Append(recorduserpropmodel.WriteDate);
            sb.Append("','");
            sb.Append(recorduserpropmodel.ClientIP);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateRecordUserProp(RecordUserPropModel recorduserpropmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update RecordUserProp set ");
            sb.Append("UserID=" + recorduserpropmodel.UserID + ",");
            sb.Append("KindID=" + recorduserpropmodel.KindID + ",");
            sb.Append("CateID=" + recorduserpropmodel.CateID + ",");
            sb.Append("PropCount=" + recorduserpropmodel.PropCount + ",");
            sb.Append("WriteDate='" + recorduserpropmodel.WriteDate + "',");
            sb.Append("ClientIP='" + recorduserpropmodel.ClientIP + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where RecordID=" + recorduserpropmodel.RecordID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteRecordUserProp(int RecordID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from RecordUserProp ");
            sb.Append(" where RecordID=" + RecordID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<RecordUserPropModel> GetAllRecordUserProp()
        {
            List<RecordUserPropModel> list = new List<RecordUserPropModel>();
            string sql = string.Format("select * from RecordUserProp");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                RecordUserPropModel recorduserpropmodel = new RecordUserPropModel();
                recorduserpropmodel.RecordID = (int)dr["RecordID"];
                recorduserpropmodel.UserID = (int)dr["UserID"];
                recorduserpropmodel.KindID = (int)dr["KindID"];
                recorduserpropmodel.CateID = (int)dr["CateID"];
                recorduserpropmodel.PropCount = (long)dr["PropCount"];
                recorduserpropmodel.WriteDate = dr["WriteDate"].ToString();
                recorduserpropmodel.ClientIP = dr["ClientIP"].ToString();
                list.Add(recorduserpropmodel);
            }
            dr.Close();
            return list;
        }
        public RecordUserPropModel GetRecordUserPropById(int RecordID)
        {
            string sql = string.Format("select * from RecordUserProp where RecordID={0}",RecordID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            RecordUserPropModel recorduserpropmodel = new RecordUserPropModel();
            if (dr.Read())
            {
                recorduserpropmodel.RecordID = (int)dr[0];
                recorduserpropmodel.UserID = (int)dr[1];
                recorduserpropmodel.KindID = (int)dr[2];
                recorduserpropmodel.CateID = (int)dr[3];
                recorduserpropmodel.PropCount = (long)dr[4];
                recorduserpropmodel.WriteDate = dr[5].ToString();
                recorduserpropmodel.ClientIP = dr[6].ToString();
            }
            dr.Close();
            return recorduserpropmodel;
        }
    }
}
