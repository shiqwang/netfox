using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class AndroidUserInfoService
    {
        public bool InsertAndroidUserInfo(AndroidUserInfoModel androiduserinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into AndroidUserInfo values (");
            sb.Append(androiduserinfomodel.UserID);
            sb.Append(",'");
            sb.Append(androiduserinfomodel.Nullity);
            sb.Append(",'");
            sb.Append(androiduserinfomodel.KindID);
            sb.Append(",'");
            sb.Append(androiduserinfomodel.ServerID);
            sb.Append(",'");
            sb.Append(androiduserinfomodel.CreateDate);
            sb.Append(",'");
            sb.Append(androiduserinfomodel.AndroidNote);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateAndroidUserInfo(AndroidUserInfoModel androiduserinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update AndroidUserInfo set ");
            sb.Append("Nullity=" + (androiduserinfomodel.Nullity ? 1 : 0) + ",");
            sb.Append("CreateDate='" + androiduserinfomodel.CreateDate + "',");
            sb.Append("AndroidNote='" + androiduserinfomodel.AndroidNote + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where UserID=" + androiduserinfomodel.UserID + " and KindID=" + androiduserinfomodel.KindID + " and ServerID=" + androiduserinfomodel.ServerID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteAndroidUserInfo(int UserID, int KindID, int ServerID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from AndroidUserInfo ");
            sb.Append(" where UserID=" + UserID + " and KindID=" + KindID + " and ServerID=" + ServerID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<AndroidUserInfoModel> GetAllAndroidUserInfo()
        {
            List<AndroidUserInfoModel> list = new List<AndroidUserInfoModel>();
            string sql = string.Format("select * from AndroidUserInfo");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                AndroidUserInfoModel androiduserinfomodel = new AndroidUserInfoModel();
                androiduserinfomodel.UserID = (int)dr["UserID"];
                androiduserinfomodel.Nullity = (bool)dr["Nullity"];
                androiduserinfomodel.KindID = (int)dr["KindID"];
                androiduserinfomodel.ServerID = (int)dr["ServerID"];
                androiduserinfomodel.CreateDate = (DateTime)dr["CreateDate"];
                androiduserinfomodel.AndroidNote = dr["AndroidNote"].ToString();
                list.Add(androiduserinfomodel);
            }
            dr.Close();
            return list;
        }
        private AndroidUserInfoModel GetAndroidUserInfo(SqlDataReader dr)
        {
            AndroidUserInfoModel androiduserinfomodel = new AndroidUserInfoModel();
            androiduserinfomodel.UserID = (int)dr[0];
            androiduserinfomodel.Nullity = (bool)dr[1];
            androiduserinfomodel.KindID = (int)dr[2];
            androiduserinfomodel.ServerID = (int)dr[3];
            androiduserinfomodel.CreateDate = (DateTime)dr[4];
            androiduserinfomodel.AndroidNote = dr[5].ToString();
            return androiduserinfomodel;
        }
        public List<AndroidUserInfoModel> GetAndroidUserInfoModel(int UserID, int KindID, int ServerID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from AndroidUserInfo ");
            sb.Append(" where UserID="+UserID+" and KindID="+KindID+" and ServerID="+ServerID +" ");
            List<AndroidUserInfoModel> list = new List<AndroidUserInfoModel>();
            AndroidUserInfoModel androiduserinfomodel = new AndroidUserInfoModel();
            try
            {
                SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
                while (dr.Read())
                {
                    list.Add(GetAndroidUserInfo(dr));
                }
                dr.Close();
                return list;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
