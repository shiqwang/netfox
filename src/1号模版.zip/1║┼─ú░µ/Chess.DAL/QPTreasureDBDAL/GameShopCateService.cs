using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class GameShopCateService
    {
        public bool InsertGameShopCate(GameShopCateModel gameshopcatemodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into GameShopCate values (");
            sb.Append(gameshopcatemodel.CateID);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.CateName);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.PropCount1);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.PropCount2);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.PropCount3);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.PropCount4);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.PropCount5);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.PropCount6);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.PropCount7);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.PropCount8);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.PropCount9);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.PropCount10);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Price1);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Price2);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Price3);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Price4);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Price5);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Price6);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Price7);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Price8);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Price9);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Price10);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Discount);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.CateNote);
            sb.Append(",'");
            sb.Append(gameshopcatemodel.Nullity);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateGameShopCate(GameShopCateModel gameshopcatemodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameShopCate set ");
            sb.Append("CateName='" + gameshopcatemodel.CateName + "',");
            sb.Append("PropCount1=" + gameshopcatemodel.PropCount1 + ",");
            sb.Append("PropCount2=" + gameshopcatemodel.PropCount2 + ",");
            sb.Append("PropCount3=" + gameshopcatemodel.PropCount3 + ",");
            sb.Append("PropCount4=" + gameshopcatemodel.PropCount4 + ",");
            sb.Append("PropCount5=" + gameshopcatemodel.PropCount5 + ",");
            sb.Append("PropCount6=" + gameshopcatemodel.PropCount6 + ",");
            sb.Append("PropCount7=" + gameshopcatemodel.PropCount7 + ",");
            sb.Append("PropCount8=" + gameshopcatemodel.PropCount8 + ",");
            sb.Append("PropCount9=" + gameshopcatemodel.PropCount9 + ",");
            sb.Append("PropCount10=" + gameshopcatemodel.PropCount10 + ",");
            sb.Append("Price1=" + gameshopcatemodel.Price1 + ",");
            sb.Append("Price2=" + gameshopcatemodel.Price2 + ",");
            sb.Append("Price3=" + gameshopcatemodel.Price3 + ",");
            sb.Append("Price4=" + gameshopcatemodel.Price4 + ",");
            sb.Append("Price5=" + gameshopcatemodel.Price5 + ",");
            sb.Append("Price6=" + gameshopcatemodel.Price6 + ",");
            sb.Append("Price7=" + gameshopcatemodel.Price7 + ",");
            sb.Append("Price8=" + gameshopcatemodel.Price8 + ",");
            sb.Append("Price9=" + gameshopcatemodel.Price9 + ",");
            sb.Append("Price10=" + gameshopcatemodel.Price10 + ",");
            sb.Append("Discount=" + gameshopcatemodel.Discount + ",");
            sb.Append("CateNote='" + gameshopcatemodel.CateNote + "',");
            sb.Append("Nullity=" + (gameshopcatemodel.Nullity ? 1 : 0) + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where CateID=" + gameshopcatemodel.CateID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteGameShopCate(int CateID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from GameShopCate ");
            sb.Append(" where CateID=" + CateID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<GameShopCateModel> GetAllGameShopCate()
        {
            List<GameShopCateModel> list = new List<GameShopCateModel>();
            string sql = string.Format("select * from GameShopCate");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                GameShopCateModel gameshopcatemodel = new GameShopCateModel();
                gameshopcatemodel.CateID = (int)dr["CateID"];
                gameshopcatemodel.CateName = dr["CateName"].ToString();
                gameshopcatemodel.PropCount1 = (int)dr["PropCount1"];
                gameshopcatemodel.PropCount2 = (int)dr["PropCount2"];
                gameshopcatemodel.PropCount3 = (int)dr["PropCount3"];
                gameshopcatemodel.PropCount4 = (int)dr["PropCount4"];
                gameshopcatemodel.PropCount5 = (int)dr["PropCount5"];
                gameshopcatemodel.PropCount6 = (int)dr["PropCount6"];
                gameshopcatemodel.PropCount7 = (int)dr["PropCount7"];
                gameshopcatemodel.PropCount8 = (int)dr["PropCount8"];
                gameshopcatemodel.PropCount9 = (int)dr["PropCount9"];
                gameshopcatemodel.PropCount10 = (int)dr["PropCount10"];
                gameshopcatemodel.Price1 = (int)dr["Price1"];
                gameshopcatemodel.Price2 = (int)dr["Price2"];
                gameshopcatemodel.Price3 = (int)dr["Price3"];
                gameshopcatemodel.Price4 = (int)dr["Price4"];
                gameshopcatemodel.Price5 = (int)dr["Price5"];
                gameshopcatemodel.Price6 = (int)dr["Price6"];
                gameshopcatemodel.Price7 = (int)dr["Price7"];
                gameshopcatemodel.Price8 = (int)dr["Price8"];
                gameshopcatemodel.Price9 = (int)dr["Price9"];
                gameshopcatemodel.Price10 = (int)dr["Price10"];
                gameshopcatemodel.Discount = (int)dr["Discount"];
                gameshopcatemodel.CateNote = dr["CateNote"].ToString();
                gameshopcatemodel.Nullity = (bool)dr["Nullity"];
                list.Add(gameshopcatemodel);
            }
            dr.Close();
            return list;
        }
        public GameShopCateModel GetGameShopCateById(int CateID)
        {
            string sql = string.Format("select * from GameShopCate where CateID={0}",CateID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            GameShopCateModel gameshopcatemodel = new GameShopCateModel();
            if (dr.Read())
            {
                gameshopcatemodel.CateID = (int)dr[0];
                gameshopcatemodel.CateName = dr[1].ToString();
                gameshopcatemodel.PropCount1 = (int)dr[2];
                gameshopcatemodel.PropCount2 = (int)dr[3];
                gameshopcatemodel.PropCount3 = (int)dr[4];
                gameshopcatemodel.PropCount4 = (int)dr[5];
                gameshopcatemodel.PropCount5 = (int)dr[6];
                gameshopcatemodel.PropCount6 = (int)dr[7];
                gameshopcatemodel.PropCount7 = (int)dr[8];
                gameshopcatemodel.PropCount8 = (int)dr[9];
                gameshopcatemodel.PropCount9 = (int)dr[10];
                gameshopcatemodel.PropCount10 = (int)dr[11];
                gameshopcatemodel.Price1 = (int)dr[12];
                gameshopcatemodel.Price2 = (int)dr[13];
                gameshopcatemodel.Price3 = (int)dr[14];
                gameshopcatemodel.Price4 = (int)dr[15];
                gameshopcatemodel.Price5 = (int)dr[16];
                gameshopcatemodel.Price6 = (int)dr[17];
                gameshopcatemodel.Price7 = (int)dr[18];
                gameshopcatemodel.Price8 = (int)dr[19];
                gameshopcatemodel.Price9 = (int)dr[20];
                gameshopcatemodel.Price10 = (int)dr[21];
                gameshopcatemodel.Discount = (int)dr[22];
                gameshopcatemodel.CateNote = dr[23].ToString();
                gameshopcatemodel.Nullity = (bool)dr[24];
            }
            dr.Close();
            return gameshopcatemodel;
        }
    }
}
