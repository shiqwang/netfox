using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class RecordFlowerGrantService
    {
        public bool InsertRecordFlowerGrant(RecordFlowerGrantModel recordflowergrantmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into RecordFlowerGrant values (");
            sb.Append(recordflowergrantmodel.SendUserID);
            sb.Append(",'");
            sb.Append(recordflowergrantmodel.RcvUserID);
            sb.Append(",'");
            sb.Append(recordflowergrantmodel.KindID);
            sb.Append(",'");
            sb.Append(recordflowergrantmodel.ServerID);
            sb.Append(",'");
            sb.Append(recordflowergrantmodel.FlowerName);
            sb.Append(",'");
            sb.Append(recordflowergrantmodel.FlowerCount);
            sb.Append(",'");
            sb.Append(recordflowergrantmodel.FlowerPay);
            sb.Append(",'");
            sb.Append(recordflowergrantmodel.SendUserLoveliness);
            sb.Append(",'");
            sb.Append(recordflowergrantmodel.RcvUserLoveliness);
            sb.Append(",'");
            sb.Append(recordflowergrantmodel.GrantIP);
            sb.Append(",'");
            sb.Append(recordflowergrantmodel.GrantDate);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateRecordFlowerGrant(RecordFlowerGrantModel recordflowergrantmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update RecordFlowerGrant set ");
            sb.Append("SendUserID=" + recordflowergrantmodel.SendUserID + ",");
            sb.Append("RcvUserID=" + recordflowergrantmodel.RcvUserID + ",");
            sb.Append("KindID=" + recordflowergrantmodel.KindID + ",");
            sb.Append("ServerID=" + recordflowergrantmodel.ServerID + ",");
            sb.Append("FlowerName='" + recordflowergrantmodel.FlowerName + "',");
            sb.Append("FlowerCount=" + recordflowergrantmodel.FlowerCount + ",");
            sb.Append("FlowerPay=" + recordflowergrantmodel.FlowerPay + ",");
            sb.Append("SendUserLoveliness=" + recordflowergrantmodel.SendUserLoveliness + ",");
            sb.Append("RcvUserLoveliness=" + recordflowergrantmodel.RcvUserLoveliness + ",");
            sb.Append("GrantIP='" + recordflowergrantmodel.GrantIP + "',");
            sb.Append("GrantDate='" + recordflowergrantmodel.GrantDate + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n,1);
            sb.Append(" where RecordID=" + recordflowergrantmodel.RecordID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteRecordFlowerGrant(int RecordID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from RecordFlowerGrant ");
            sb.Append(" where RecordID=" + RecordID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<RecordFlowerGrantModel> GetAllRecordFlowerGrant()
        {
            List<RecordFlowerGrantModel> list = new List<RecordFlowerGrantModel>();
            string sql = string.Format("select * from RecordFlowerGrant");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                RecordFlowerGrantModel recordflowergrantmodel = new RecordFlowerGrantModel();
                recordflowergrantmodel.RecordID = (int)dr["RecordID"];
                recordflowergrantmodel.SendUserID = (int)dr["SendUserID"];
                recordflowergrantmodel.RcvUserID = (int)dr["RcvUserID"];
                recordflowergrantmodel.KindID = (int)dr["KindID"];
                recordflowergrantmodel.ServerID = (int)dr["ServerID"];
                recordflowergrantmodel.FlowerName = dr["FlowerName"].ToString();
                recordflowergrantmodel.FlowerCount = (int)dr["FlowerCount"];
                recordflowergrantmodel.FlowerPay = (long)dr["FlowerPay"];
                recordflowergrantmodel.SendUserLoveliness = (int)dr["SendUserLoveliness"];
                recordflowergrantmodel.RcvUserLoveliness = (int)dr["RcvUserLoveliness"];
                recordflowergrantmodel.GrantIP = dr["GrantIP"].ToString();
                recordflowergrantmodel.GrantDate = (DateTime)dr["GrantDate"];
                list.Add(recordflowergrantmodel);
            }
            dr.Close();
            return list;
        }
        public RecordFlowerGrantModel GetRecordFlowerGrantById(int RecordID)
        {
            string sql = string.Format("select * from RecordFlowerGrant where RecordID={0}",RecordID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            RecordFlowerGrantModel recordflowergrantmodel = new RecordFlowerGrantModel();
            if (dr.Read())
            {
                recordflowergrantmodel.RecordID = (int)dr[0];
                recordflowergrantmodel.SendUserID = (int)dr[1];
                recordflowergrantmodel.RcvUserID = (int)dr[2];
                recordflowergrantmodel.KindID = (int)dr[3];
                recordflowergrantmodel.ServerID = (int)dr[4];
                recordflowergrantmodel.FlowerName = dr[5].ToString();
                recordflowergrantmodel.FlowerCount = (int)dr[6];
                recordflowergrantmodel.FlowerPay = (long)dr[7];
                recordflowergrantmodel.SendUserLoveliness = (int)dr[8];
                recordflowergrantmodel.RcvUserLoveliness = (int)dr[9];
                recordflowergrantmodel.GrantIP = dr[10].ToString();
                recordflowergrantmodel.GrantDate = (DateTime)dr[11];
            }
            dr.Close();
            return recordflowergrantmodel;
        }
    }
}
