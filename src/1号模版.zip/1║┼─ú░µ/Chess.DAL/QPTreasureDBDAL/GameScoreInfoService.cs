using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class GameScoreInfoService
    {
        public bool InsertGameScoreInfo(GameScoreInfoModel gamescoreinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into GameScoreInfo values (");
            sb.Append(gamescoreinfomodel.UserID);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.Score);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.Revenue);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.InsureScore);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.WinCount);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.LostCount);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.DrawCount);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.FleeCount);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.UserRight);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.MasterRight);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.MasterOrder);
            sb.Append(",'");
            sb.Append(gamescoreinfomodel.RegisterIP);
            sb.Append("','");
            sb.Append(gamescoreinfomodel.LastLogonIP);
            sb.Append("','");
            sb.Append(gamescoreinfomodel.RegisterDate);
            sb.Append("','");
            sb.Append(gamescoreinfomodel.LastLogonDate);
            sb.Append("',");
            sb.Append(gamescoreinfomodel.AllLogonTimes);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.PlayTimeCount);
            sb.Append(",");
            sb.Append(gamescoreinfomodel.OnLineTimeCount);
            sb.Append(")");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateGameScoreInfo(GameScoreInfoModel gamescoreinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameScoreInfo set ");
            sb.Append("Score=" + gamescoreinfomodel.Score + ",");
            sb.Append("Revenue=" + gamescoreinfomodel.Revenue + ",");
            sb.Append("InsureScore=" + gamescoreinfomodel.InsureScore + ",");
            sb.Append("WinCount=" + gamescoreinfomodel.WinCount + ",");
            sb.Append("LostCount=" + gamescoreinfomodel.LostCount + ",");
            sb.Append("DrawCount=" + gamescoreinfomodel.DrawCount + ",");
            sb.Append("FleeCount=" + gamescoreinfomodel.FleeCount + ",");
            sb.Append("UserRight=" + gamescoreinfomodel.UserRight + ",");
            sb.Append("MasterRight=" + gamescoreinfomodel.MasterRight + ",");
            sb.Append("MasterOrder=" + gamescoreinfomodel.MasterOrder + ",");
            sb.Append("RegisterIP='" + gamescoreinfomodel.RegisterIP + "',");
            sb.Append("LastLogonIP='" + gamescoreinfomodel.LastLogonIP + "',");
            sb.Append("RegisterDate='" + gamescoreinfomodel.RegisterDate + "',");
            sb.Append("LastLogonDate='" + gamescoreinfomodel.LastLogonDate + "',");
            sb.Append("AllLogonTimes=" + gamescoreinfomodel.AllLogonTimes + ",");
            sb.Append("PlayTimeCount=" + gamescoreinfomodel.PlayTimeCount + ",");
            sb.Append("OnLineTimeCount=" + gamescoreinfomodel.OnLineTimeCount + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where UserID=" + gamescoreinfomodel.UserID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateScore(int userid, long score, long insurescore)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameScoreInfo set ");
            sb.Append("Score=" + score + ",");
            sb.Append("InsureScore=" + insurescore + "");
            sb.Append(" where UserID="+userid+"");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateScores(int userid, long score)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameScoreInfo set ");
            sb.Append("Score=" + score + "");
            sb.Append(" where UserID=" + userid + "");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateInsureScore(int userid, long inscurescore)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameScoreInfo set ");
            sb.Append("InsureScore=" + inscurescore + "");
            sb.Append(" where UserID=" + userid + "");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool DeleteGameScoreInfo(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from GameScoreInfo ");
            sb.Append(" where UserID=" + UserID + "");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<GameScoreInfoModel> GetAllGameScoreInfo()
        {
            List<GameScoreInfoModel> list = new List<GameScoreInfoModel>();
            string sql = string.Format("select * from GameScoreInfo");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                GameScoreInfoModel gamescoreinfomodel = new GameScoreInfoModel();
                gamescoreinfomodel.UserID = (int)dr["UserID"];
                gamescoreinfomodel.Score = (long)dr["Score"];
                gamescoreinfomodel.Revenue = (long)dr["Revenue"];
                gamescoreinfomodel.InsureScore = (long)dr["InsureScore"];
                gamescoreinfomodel.WinCount = (int)dr["WinCount"];
                gamescoreinfomodel.LostCount = (int)dr["LostCount"];
                gamescoreinfomodel.DrawCount = (int)dr["DrawCount"];
                gamescoreinfomodel.FleeCount = (int)dr["FleeCount"];
                gamescoreinfomodel.UserRight = (int)dr["UserRight"];
                gamescoreinfomodel.MasterRight = (int)dr["MasterRight"];
                gamescoreinfomodel.MasterOrder = (int)dr["MasterOrder"];
                gamescoreinfomodel.RegisterIP = dr["RegisterIP"].ToString();
                gamescoreinfomodel.LastLogonIP = dr["LastLogonIP"].ToString();
                gamescoreinfomodel.RegisterDate = dr["RegisterDate"].ToString();
                gamescoreinfomodel.LastLogonDate = dr["LastLogonDate"].ToString();
                gamescoreinfomodel.AllLogonTimes = (int)dr["AllLogonTimes"];
                gamescoreinfomodel.PlayTimeCount = (int)dr["PlayTimeCount"];
                gamescoreinfomodel.OnLineTimeCount = (int)dr["OnLineTimeCount"];
                list.Add(gamescoreinfomodel);
            }
            dr.Close();
            return list;
        }
        public GameScoreInfoModel GetGameScoreInfoById(int UserID)
        {
            string sql = string.Format("select * from GameScoreInfo where UserID={0}",UserID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            GameScoreInfoModel gamescoreinfomodel = new GameScoreInfoModel();
            if (dr.Read())
            {
                gamescoreinfomodel.UserID = (int)dr[0];
                gamescoreinfomodel.Score = (long)dr[1];
                gamescoreinfomodel.Revenue = (long)dr[2];
                gamescoreinfomodel.InsureScore = (long)dr[3];
                gamescoreinfomodel.WinCount = (int)dr[4];
                gamescoreinfomodel.LostCount = (int)dr[5];
                gamescoreinfomodel.DrawCount = (int)dr[6];
                gamescoreinfomodel.FleeCount = (int)dr[7];
                gamescoreinfomodel.UserRight = (int)dr[8];
                gamescoreinfomodel.MasterRight = (int)dr[9];
                //gamescoreinfomodel.MasterOrder = (int)dr[10];
                gamescoreinfomodel.MasterOrder = int.Parse(dr[10].ToString());
                gamescoreinfomodel.RegisterIP = dr[11].ToString();
                gamescoreinfomodel.LastLogonIP = dr[12].ToString();
                gamescoreinfomodel.RegisterDate = dr[13].ToString();
                gamescoreinfomodel.LastLogonDate = dr[14].ToString();
                gamescoreinfomodel.AllLogonTimes = (int)dr[15];
                gamescoreinfomodel.PlayTimeCount = (int)dr[16];
                gamescoreinfomodel.OnLineTimeCount = (int)dr[17];
            }
            dr.Close();
            return gamescoreinfomodel;
        }
        public List<GameScoreInfoModel> GetScoretop()
        {
            string sql = string.Format("select top 10 g.UserID,(g.Score + g.InsureScore)as Score,acc.Accounts from GameScoreInfo g left join QPGameUserDB.dbo.AccountsInfo acc on g.userid=acc.userid order by (g.Score+g.InsureScore) desc");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            List<GameScoreInfoModel> list = new List<GameScoreInfoModel>();
            
            while (dr.Read())
            {
                GameScoreInfoModel gamescoreinfomodel = new GameScoreInfoModel();
                gamescoreinfomodel.UserID = int.Parse(dr[0].ToString());
                gamescoreinfomodel.Score = long.Parse(dr[1].ToString());
                gamescoreinfomodel.Accounts = dr[2].ToString();
                list.Add(gamescoreinfomodel);
            }
            dr.Close();
            return list;
        }
        public List<GameScoreInfoModel> GetScore()
        {
            List<GameScoreInfoModel> list = new List<GameScoreInfoModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select top 13 UserID,(Score + InsureScore)as Score from GameScoreInfo order by (Score+InsureScore) desc");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            while (dr.Read())
            {
                GameScoreInfoModel gamescoreinfomodel = new GameScoreInfoModel();
                gamescoreinfomodel.UserID = int.Parse(dr[0].ToString());
                gamescoreinfomodel.Score = long.Parse(dr[1].ToString());
                list.Add(gamescoreinfomodel);
            }
            dr.Close();
            return list;
        }
    }
}
