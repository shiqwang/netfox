using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class RecordGiftGrantService
    {
        public bool InsertRecordGiftGrant(RecordGiftGrantModel recordgiftgrantmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into RecordGiftGrant values (");
            sb.Append(recordgiftgrantmodel.SendUserID);
            sb.Append(",'");
            sb.Append(recordgiftgrantmodel.RcvUserID);
            sb.Append(",'");
            sb.Append(recordgiftgrantmodel.KindID);
            sb.Append(",'");
            sb.Append(recordgiftgrantmodel.ServerID);
            sb.Append(",'");
            sb.Append(recordgiftgrantmodel.Gift);
            sb.Append(",'");
            sb.Append(recordgiftgrantmodel.GiftPay);
            sb.Append(",'");
            sb.Append(recordgiftgrantmodel.GrantIP);
            sb.Append(",'");
            sb.Append(recordgiftgrantmodel.GrantDate);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateRecordGiftGrant(RecordGiftGrantModel recordgiftgrantmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update RecordGiftGrant set ");
            sb.Append("SendUserID=" + recordgiftgrantmodel.SendUserID + ",");
            sb.Append("RcvUserID=" + recordgiftgrantmodel.RcvUserID + ",");
            sb.Append("KindID=" + recordgiftgrantmodel.KindID + ",");
            sb.Append("ServerID=" + recordgiftgrantmodel.ServerID + ",");
            sb.Append("Gift='" + recordgiftgrantmodel.Gift + "',");
            sb.Append("GiftPay=" + recordgiftgrantmodel.GiftPay + ",");
            sb.Append("GrantIP='" + recordgiftgrantmodel.GrantIP + "',");
            sb.Append("GrantDate='" + recordgiftgrantmodel.GrantDate + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where RecordID=" + recordgiftgrantmodel.RecordID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteRecordGiftGrant(int RecordID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from RecordGiftGrant ");
            sb.Append(" where RecordID=" + RecordID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<RecordGiftGrantModel> GetAllRecordGiftGrant()
        {
            List<RecordGiftGrantModel> list = new List<RecordGiftGrantModel>();
            string sql = string.Format("select * from RecordGiftGrant");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                RecordGiftGrantModel recordgiftgrantmodel = new RecordGiftGrantModel();
                recordgiftgrantmodel.RecordID = (int)dr["RecordID"];
                recordgiftgrantmodel.SendUserID = (int)dr["SendUserID"];
                recordgiftgrantmodel.RcvUserID = (int)dr["RcvUserID"];
                recordgiftgrantmodel.KindID = (int)dr["KindID"];
                recordgiftgrantmodel.ServerID = (int)dr["ServerID"];
                recordgiftgrantmodel.Gift = dr["Gift"].ToString();
                recordgiftgrantmodel.GiftPay = (long)dr["GiftPay"];
                recordgiftgrantmodel.GrantIP = dr["GrantIP"].ToString();
                recordgiftgrantmodel.GrantDate = (DateTime)dr["GrantDate"];
                list.Add(recordgiftgrantmodel);
            }
            dr.Close();
            return list;
        }
        public RecordGiftGrantModel GetRecordGiftGrantById(int RecordID)
        {
            string sql = string.Format("select * from RecordGiftGrant where RecordID={0}",RecordID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            RecordGiftGrantModel recordgiftgrantmodel = new RecordGiftGrantModel();
            if (dr.Read())
            {
                recordgiftgrantmodel.RecordID = (int)dr[0];
                recordgiftgrantmodel.SendUserID = (int)dr[1];
                recordgiftgrantmodel.RcvUserID = (int)dr[2];
                recordgiftgrantmodel.KindID = (int)dr[3];
                recordgiftgrantmodel.ServerID = (int)dr[4];
                recordgiftgrantmodel.Gift = dr[5].ToString();
                recordgiftgrantmodel.GiftPay = (long)dr[6];
                recordgiftgrantmodel.GrantIP = dr[7].ToString();
                recordgiftgrantmodel.GrantDate = (DateTime)dr[8];
            }
            dr.Close();
            return recordgiftgrantmodel;
        }
    }
}
