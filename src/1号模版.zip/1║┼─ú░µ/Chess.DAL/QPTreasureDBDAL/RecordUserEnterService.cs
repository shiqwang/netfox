using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class RecordUserEnterService
    {
        public bool InsertRecordUserEnter(RecordUserEnterModel recorduserentermodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into RecordUserEnter values (");
            sb.Append(recorduserentermodel.UserID);
            sb.Append(",'");
            sb.Append(recorduserentermodel.ServerID);
            sb.Append(",'");
            sb.Append(recorduserentermodel.KindID);
            sb.Append(",'");
            sb.Append(recorduserentermodel.ClientIP);
            sb.Append(",'");
            sb.Append(recorduserentermodel.ServerID);
            sb.Append(",'");
            sb.Append(recorduserentermodel.EnterTime);
            sb.Append("')");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateRecordUserEnter(RecordUserEnterModel recorduserentermodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update RecordUserEnter set ");
            sb.Append("UserID=" + recorduserentermodel.UserID + ",");
            sb.Append("Score=" + recorduserentermodel.Score + ",");
            sb.Append("KindID=" + recorduserentermodel.KindID + ",");
            sb.Append("ClientIP='" + recorduserentermodel.ClientIP + "',");
            sb.Append("ServerID=" + recorduserentermodel.ServerID + ",");
            sb.Append("EnterTime='" + recorduserentermodel.EnterTime + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where UserID="+recorduserentermodel.UserID+" ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteRecordUserEnter(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from RecordUserEnter ");
            sb.Append(" where UserID="+UserID+" ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<RecordUserEnterModel> GetAllRecordUserEnter()
        {
            List<RecordUserEnterModel> list = new List<RecordUserEnterModel>();
            string sql = string.Format("select * from RecordUserEnter");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                RecordUserEnterModel recorduserentermodel = new RecordUserEnterModel();
                recorduserentermodel.UserID = (int)dr["UserID"];
                recorduserentermodel.Score = (long)dr["Score"];
                recorduserentermodel.KindID = (int)dr["KindID"];
                recorduserentermodel.ClientIP = dr["ClientIP"].ToString();
                recorduserentermodel.ServerID = (int)dr["ServerID"];
                recorduserentermodel.EnterTime = dr["EnterTime"].ToString();
                list.Add(recorduserentermodel);
            }
            dr.Close();
            return list;
        }
        public RecordUserEnterModel GetRecordUserEnterById(int UserID)
        {
            string sql = string.Format("select * from RecordUserEnter where UserID={0}",UserID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            RecordUserEnterModel recorduserentermodel = new RecordUserEnterModel();
            if (dr.Read())
            {
                recorduserentermodel.UserID = (int)dr[0];
                recorduserentermodel.Score = (long)dr[1];
                recorduserentermodel.KindID = (int)dr[2];
                recorduserentermodel.ClientIP = dr[3].ToString();
                recorduserentermodel.ServerID = (int)dr[4];
                recorduserentermodel.EnterTime = dr[5].ToString();
            }
            dr.Close();
            return recorduserentermodel;
        }
        public RecordUserEnterModel GetRecordUserEnterNewByID(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from RecordUserEnter where UserID=");
            sb.Append(UserID);
            sb.Append(" and EnterTime in (select max(EnterTime) from RecordUserEnter where UserID =");
            sb.Append(UserID);
            sb.Append(")");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            RecordUserEnterModel recorduserentermodel = new RecordUserEnterModel();
            if (dr.Read())
            {
                recorduserentermodel.UserID = (int)dr["UserID"];
                recorduserentermodel.Score = (long)dr["Score"];
                recorduserentermodel.KindID = (int)dr["KindID"];
                recorduserentermodel.ClientIP = dr["ClientIP"].ToString();
                recorduserentermodel.ServerID = (int)dr["ServerID"];
                recorduserentermodel.EnterTime = dr["EnterTime"].ToString();
            }
            dr.Close();
            return recorduserentermodel;
        }
    }
}
