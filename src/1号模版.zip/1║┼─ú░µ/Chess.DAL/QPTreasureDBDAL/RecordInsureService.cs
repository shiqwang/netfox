using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPTreasureDBModels;
using System.Data.SqlClient;

namespace Chess.DAL.QPTreasureDBDAL
{
    public class RecordInsureService
    {
        public bool InsertRecordInsure(RecordInsureModel recordinsuremodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into RecordInsure values (");
            sb.Append(recordinsuremodel.KindID);
            sb.Append(",");
            sb.Append(recordinsuremodel.ServerID);
            sb.Append(",");
            sb.Append(recordinsuremodel.SourceUserID);
            sb.Append(",");
            sb.Append(recordinsuremodel.SourceGameID);
            sb.Append(",'");
            sb.Append(recordinsuremodel.SourceAccounts);
            sb.Append("',");
            sb.Append(recordinsuremodel.TargetUserID);
            sb.Append(",");
            sb.Append(recordinsuremodel.TargetGameID);
            sb.Append(",'");
            sb.Append(recordinsuremodel.TargetAccounts);
            sb.Append("',");
            sb.Append(recordinsuremodel.InsureScore);
            sb.Append(",");
            sb.Append(recordinsuremodel.SwapScore);
            sb.Append(",");
            sb.Append(recordinsuremodel.Revenue);
            sb.Append(",");
            //sb.Append(recordinsuremodel.CurrentScore);
            //sb.Append(",");
            //sb.Append(recordinsuremodel.CurrentInsureScore);
            //sb.Append(",");
            sb.Append(recordinsuremodel.TradeType);
            sb.Append(",'");
            sb.Append(recordinsuremodel.ClientIP);
            sb.Append("','");
            sb.Append(recordinsuremodel.CollectDate);
            sb.Append("','");
            sb.Append(recordinsuremodel.CollectNote);
            sb.Append("')");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        public bool UpdateRecordInsure(RecordInsureModel recordinsuremodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update RecordInsure set ");
            sb.Append("KindID=" + recordinsuremodel.KindID + ",");
            sb.Append("ServerID=" + recordinsuremodel.ServerID + ",");
            sb.Append("SourceUserID=" + recordinsuremodel.SourceUserID + ",");
            sb.Append("SourceGameID=" + recordinsuremodel.SourceGameID + ",");
            sb.Append("SourceAccounts='" + recordinsuremodel.SourceAccounts + "',");
            sb.Append("TargetUserID=" + recordinsuremodel.TargetUserID + ",");
            sb.Append("TargetGameID=" + recordinsuremodel.TargetGameID + ",");
            sb.Append("TargetAccounts='" + recordinsuremodel.TargetAccounts + "',");
            sb.Append("InsureScore=" + recordinsuremodel.InsureScore + ",");
            sb.Append("SwapScore=" + recordinsuremodel.SwapScore + ",");
            sb.Append("Revenue=" + recordinsuremodel.Revenue + ",");
            //sb.Append("CurrentScore=" + recordinsuremodel.CurrentScore + ",");
            //sb.Append("CurrentInsureScore=" + recordinsuremodel.CurrentInsureScore + ",");
            sb.Append("TradeType=" + recordinsuremodel.TradeType + ",");
            sb.Append("ClientIP='" + recordinsuremodel.ClientIP + "',");
            sb.Append("CollectDate='" + recordinsuremodel.CollectDate + "',");
            sb.Append("CollectNote='" + recordinsuremodel.CollectNote + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where InsureID=" + recordinsuremodel.InsureID + " ");
            try
            {
                return (DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteRecordInsure(int InsureID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from RecordInsure ");
            sb.Append(" where InsureID=" + InsureID + " ");
            return DBHelper.QPTreasureDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<RecordInsureModel> GetAllRecordInsure()
        {
            List<RecordInsureModel> list = new List<RecordInsureModel>();
            string sql = string.Format("select * from RecordInsure");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                RecordInsureModel recordinsuremodel = new RecordInsureModel();
                recordinsuremodel.InsureID = (int)dr["InsureID"];
                recordinsuremodel.KindID = (int)dr["KindID"];
                recordinsuremodel.ServerID = (int)dr["ServerID"];
                recordinsuremodel.SourceUserID = (int)dr["SourceUserID"];
                recordinsuremodel.SourceGameID = (int)dr["SourceGameID"];
                recordinsuremodel.SourceAccounts = dr["SourceAccounts"].ToString();
                recordinsuremodel.TargetUserID = (int)dr["TargetUserID"];
                recordinsuremodel.TargetGameID = (int)dr["TargetGameID"];
                recordinsuremodel.TargetAccounts = dr["TargetAccounts"].ToString();
                recordinsuremodel.InsureScore = (long)dr["InsureScore"];
                recordinsuremodel.SwapScore = (long)dr["SwapScore"];
                recordinsuremodel.Revenue = (long)dr["Revenue"];
                //recordinsuremodel.CurrentScore = (long)dr["CurrentScore"];
                //recordinsuremodel.CurrentInsureScore = (long)dr["CurrentInsureScore"];
                recordinsuremodel.TradeType = int.Parse(dr["TradeType"].ToString());
                recordinsuremodel.ClientIP = dr["ClientIP"].ToString();
                recordinsuremodel.CollectDate = dr["CollectDate"].ToString();
                recordinsuremodel.CollectNote = dr["CollectNote"].ToString();
                list.Add(recordinsuremodel);
            }
            dr.Close();
            return list;
        }
        public List<RecordInsureModel> GetRecordInsureListByUserName(string Name)
        {
            List<RecordInsureModel> list = new List<RecordInsureModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from RecordInsure where TargetAccounts='");
            sb.Append(Name);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    RecordInsureModel recordinsuremodel = new RecordInsureModel();
                    recordinsuremodel.InsureID = (int)dr["InsureID"];
                    recordinsuremodel.KindID = (int)dr["KindID"];
                    recordinsuremodel.ServerID = (int)dr["ServerID"];
                    recordinsuremodel.SourceUserID = (int)dr["SourceUserID"];
                    recordinsuremodel.SourceGameID = (int)dr["SourceGameID"];
                    recordinsuremodel.SourceAccounts = dr["SourceAccounts"].ToString();
                    recordinsuremodel.TargetUserID = (int)dr["TargetUserID"];
                    recordinsuremodel.TargetGameID = (int)dr["TargetGameID"];
                    recordinsuremodel.TargetAccounts = dr["TargetAccounts"].ToString();
                    recordinsuremodel.InsureScore = (long)dr["InsureScore"];
                    recordinsuremodel.SwapScore = (long)dr["SwapScore"];
                    recordinsuremodel.Revenue = (long)dr["Revenue"];
                    //recordinsuremodel.CurrentScore = (long)dr["CurrentScore"];
                    //recordinsuremodel.CurrentInsureScore = (long)dr["CurrentInsureScore"];
                    recordinsuremodel.TradeType = int.Parse(dr["TradeType"].ToString());
                    recordinsuremodel.ClientIP = dr["ClientIP"].ToString();
                    recordinsuremodel.CollectDate = dr["CollectDate"].ToString();
                    recordinsuremodel.CollectNote = dr["CollectNote"].ToString();
                    list.Add(recordinsuremodel);
                }
            }
            dr.Close();
            return list;
        }
        public List<RecordInsureModel> GetRecordInsureListByUserID(int UserID)
        {
            List<RecordInsureModel> list = new List<RecordInsureModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from RecordInsure where TargetUserID=");
            sb.Append(UserID);
            sb.Append("");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    RecordInsureModel recordinsuremodel = new RecordInsureModel();
                    recordinsuremodel.InsureID = (int)dr["InsureID"];
                    recordinsuremodel.KindID = (int)dr["KindID"];
                    recordinsuremodel.ServerID = (int)dr["ServerID"];
                    recordinsuremodel.SourceUserID = (int)dr["SourceUserID"];
                    recordinsuremodel.SourceGameID = (int)dr["SourceGameID"];
                    recordinsuremodel.SourceAccounts = dr["SourceAccounts"].ToString();
                    recordinsuremodel.TargetUserID = (int)dr["TargetUserID"];
                    recordinsuremodel.TargetGameID = (int)dr["TargetGameID"];
                    recordinsuremodel.TargetAccounts = dr["TargetAccounts"].ToString();
                    recordinsuremodel.InsureScore = (long)dr["InsureScore"];
                    recordinsuremodel.SwapScore = (long)dr["SwapScore"];
                    recordinsuremodel.Revenue = (long)dr["Revenue"];
                    //recordinsuremodel.CurrentScore = (long)dr["CurrentScore"];
                    //recordinsuremodel.CurrentInsureScore = (long)dr["CurrentInsureScore"];
                    recordinsuremodel.TradeType = int.Parse(dr["TradeType"].ToString());
                    recordinsuremodel.ClientIP = dr["ClientIP"].ToString();
                    recordinsuremodel.CollectDate = dr["CollectDate"].ToString();
                    recordinsuremodel.CollectNote = dr["CollectNote"].ToString();
                    list.Add(recordinsuremodel);
                }
            }
            dr.Close();
            return list;
        }
        public List<RecordInsureModel> GetRecordInsureListByName(string Name)
        {
            List<RecordInsureModel> list = new List<RecordInsureModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from RecordInsure where SourceAccounts='");
            sb.Append(Name);
            sb.Append("'");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    RecordInsureModel recordinsuremodel = new RecordInsureModel();
                    recordinsuremodel.InsureID = (int)dr["InsureID"];
                    recordinsuremodel.KindID = (int)dr["KindID"];
                    recordinsuremodel.ServerID = (int)dr["ServerID"];
                    recordinsuremodel.SourceUserID = (int)dr["SourceUserID"];
                    recordinsuremodel.SourceGameID = (int)dr["SourceGameID"];
                    recordinsuremodel.SourceAccounts = dr["SourceAccounts"].ToString();
                    recordinsuremodel.TargetUserID = (int)dr["TargetUserID"];
                    recordinsuremodel.TargetGameID = (int)dr["TargetGameID"];
                    recordinsuremodel.TargetAccounts = dr["TargetAccounts"].ToString();
                    recordinsuremodel.InsureScore = (long)dr["InsureScore"];
                    recordinsuremodel.SwapScore = (long)dr["SwapScore"];
                    recordinsuremodel.Revenue = (long)dr["Revenue"];
                    //recordinsuremodel.CurrentScore = (long)dr["CurrentScore"];
                    //recordinsuremodel.CurrentInsureScore = (long)dr["CurrentInsureScore"];
                    recordinsuremodel.TradeType = int.Parse(dr["TradeType"].ToString());
                    recordinsuremodel.ClientIP = dr["ClientIP"].ToString();
                    recordinsuremodel.CollectDate = dr["CollectDate"].ToString();
                    recordinsuremodel.CollectNote = dr["CollectNote"].ToString();
                    list.Add(recordinsuremodel);
                }
            }
            dr.Close();
            return list;
        }
        public List<RecordInsureModel> GetRecordInsureListByID(int UserID)
        {
            List<RecordInsureModel> list = new List<RecordInsureModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from RecordInsure where SourceUserID=");
            sb.Append(UserID);
            sb.Append("");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    RecordInsureModel recordinsuremodel = new RecordInsureModel();
                    recordinsuremodel.InsureID = (int)dr["InsureID"];
                    recordinsuremodel.KindID = (int)dr["KindID"];
                    recordinsuremodel.ServerID = (int)dr["ServerID"];
                    recordinsuremodel.SourceUserID = (int)dr["SourceUserID"];
                    recordinsuremodel.SourceGameID = (int)dr["SourceGameID"];
                    recordinsuremodel.SourceAccounts = dr["SourceAccounts"].ToString();
                    recordinsuremodel.TargetUserID = (int)dr["TargetUserID"];
                    recordinsuremodel.TargetGameID = (int)dr["TargetGameID"];
                    recordinsuremodel.TargetAccounts = dr["TargetAccounts"].ToString();
                    recordinsuremodel.InsureScore = (long)dr["InsureScore"];
                    recordinsuremodel.SwapScore = (long)dr["SwapScore"];
                    recordinsuremodel.Revenue = (long)dr["Revenue"];
                    //recordinsuremodel.CurrentScore = (long)dr["CurrentScore"];
                    //recordinsuremodel.CurrentInsureScore = (long)dr["CurrentInsureScore"];
                    recordinsuremodel.TradeType = int.Parse(dr["TradeType"].ToString());
                    recordinsuremodel.ClientIP = dr["ClientIP"].ToString();
                    recordinsuremodel.CollectDate = dr["CollectDate"].ToString();
                    recordinsuremodel.CollectNote = dr["CollectNote"].ToString();
                    list.Add(recordinsuremodel);
                }
            }
            dr.Close();
            return list;
        }
        public List<RecordInsureModel> GetRecordInsureByName(string name)
        {
            List<RecordInsureModel> list = new List<RecordInsureModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from RecordInsure where SourceAccounts = '");
            sb.Append(name);
            sb.Append("'");
            sb.Append("or TargetAccounts='");
            sb.Append(name);
            sb.Append("'");
            sb.Append("and TradeType = 3 order by CollectDate desc");
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sb.ToString());
            while (dr.Read())
            {
                RecordInsureModel recordinsuremodel = new RecordInsureModel();
                recordinsuremodel.InsureID = (int)dr["InsureID"];
                recordinsuremodel.KindID = (int)dr["KindID"];
                recordinsuremodel.ServerID = (int)dr["ServerID"];
                recordinsuremodel.SourceUserID = (int)dr["SourceUserID"];
                recordinsuremodel.SourceGameID = (int)dr["SourceGameID"];
                recordinsuremodel.SourceAccounts = dr["SourceAccounts"].ToString();
                recordinsuremodel.TargetUserID = (int)dr["TargetUserID"];
                recordinsuremodel.TargetGameID = (int)dr["TargetGameID"];
                recordinsuremodel.TargetAccounts = dr["TargetAccounts"].ToString();
                recordinsuremodel.InsureScore = (long)dr["InsureScore"];
                recordinsuremodel.SwapScore = (long)dr["SwapScore"];
                recordinsuremodel.Revenue = (long)dr["Revenue"];
                //recordinsuremodel.CurrentScore = (long)dr["CurrentScore"];
                //recordinsuremodel.CurrentInsureScore = (long)dr["CurrentInsureScore"];
                recordinsuremodel.TradeType = int.Parse(dr["TradeType"].ToString());
                recordinsuremodel.ClientIP = dr["ClientIP"].ToString();
                recordinsuremodel.CollectDate = dr["CollectDate"].ToString();
                recordinsuremodel.CollectNote = dr["CollectNote"].ToString();
                list.Add(recordinsuremodel);
            }
            dr.Close();
            return list;
        }
        public RecordInsureModel GetRecordInsureById(int InsureID)
        {
            string sql = string.Format("select * from RecordInsure where InsureID={0}",InsureID);
            SqlDataReader dr = DBHelper.QPTreasureDBHelper.GetDataReader(sql);
            RecordInsureModel recordinsuremodel = new RecordInsureModel();
            if (dr.Read())
            {
                recordinsuremodel.InsureID = (int)dr[0];
                recordinsuremodel.KindID = (int)dr[1];
                recordinsuremodel.ServerID = (int)dr[2];
                recordinsuremodel.SourceUserID = (int)dr[3];
                recordinsuremodel.SourceGameID = (int)dr[4];
                recordinsuremodel.SourceAccounts = dr[5].ToString();
                recordinsuremodel.TargetUserID = (int)dr[6];
                recordinsuremodel.TargetGameID = (int)dr[7];
                recordinsuremodel.TargetAccounts = dr[8].ToString();
                recordinsuremodel.InsureScore = (long)dr[9];
                recordinsuremodel.SwapScore = (long)dr[10];
                recordinsuremodel.Revenue = (long)dr[11];
                //recordinsuremodel.CurrentScore = (long)dr[12];
                //recordinsuremodel.CurrentInsureScore = (long)dr[13];
                recordinsuremodel.TradeType = (int)dr[12];
                recordinsuremodel.ClientIP = dr[13].ToString();
                recordinsuremodel.CollectDate = dr[14].ToString();
                recordinsuremodel.CollectNote = dr[15].ToString();
            }
            dr.Close();
            return recordinsuremodel;
        }
    }
}
