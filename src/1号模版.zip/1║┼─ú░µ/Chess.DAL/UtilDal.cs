﻿using System;
using System.Data.SqlClient;

namespace Chess.DAL
{
    public static class UtilDal
    {
        public static T? ConvertNullable<T>(SqlDataReader reader, string column) where T : struct
        {
            //.net2.0 SqlDataReader 针对可空值类型转换存在问题
            //针对上述问题添加扩展方法
            return reader[column] == DBNull.Value ? (T?)null : (T)reader[column];
        }

        public static T? ConvertNullable<T>(SqlDataReader reader, int index) where T : struct
        {
            //.net2.0 SqlDataReader 针对可空值类型转换存在问题
            //针对上述问题添加扩展方法
            return reader[index] == DBNull.Value ? (T?)null : (T)reader[index];
        }
    }
}
