using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class DuihuanService
    {
        /// <summary>
        /// ����һ������
        /// </summary>
        /// <param name="duihuanmodel"></param>
        /// <returns></returns>
        public bool InsertDuihuan(DuihuanModel duihuanmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into Duihuan values('");
            sb.Append(duihuanmodel.userid);
            sb.Append("','");
            sb.Append(duihuanmodel.c_id);
            sb.Append("','");
            sb.Append(duihuanmodel.Y_huan);
            sb.Append("','");
            sb.Append(duihuanmodel.username);
            sb.Append("','");
            sb.Append(duihuanmodel.C_idno);
            sb.Append("','");
            sb.Append(duihuanmodel.lianxi);
            sb.Append("','");
            sb.Append(duihuanmodel.email);
            sb.Append("','");
            sb.Append(duihuanmodel.other);
            sb.Append("','");
            sb.Append(duihuanmodel.thetime);
            sb.Append("','");
            sb.Append(duihuanmodel.D_content);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// ����һ������
        /// </summary>
        /// <param name="duihuanmodel"></param>
        /// <returns></returns>
        public bool UpdateDuihuan(DuihuanModel duihuanmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update Duihuan set ");
            sb.Append("userid=" + duihuanmodel.userid + ",");
            sb.Append("c_id=" + duihuanmodel.c_id + ",");
            sb.Append("Y_huan=" + duihuanmodel.Y_huan + ",");
            sb.Append("username='" + duihuanmodel.username + "',");
            sb.Append("C_idno='" + duihuanmodel.C_idno + "',");
            sb.Append("lianxi='" + duihuanmodel.lianxi + "',");
            sb.Append("email='" + duihuanmodel.email + "',");
            sb.Append("other='" + duihuanmodel.other + "',");
            sb.Append("thetime='" + duihuanmodel.thetime + "',");
            sb.Append("D_content='" + duihuanmodel.D_content + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where id=" + duihuanmodel.id + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// ɾ��һ������
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool DeleteDuihuan(int id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from Duihuan ");
            sb.Append(" where id=" + id + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        /// <summary>
        /// ��ѯ��������
        /// </summary>
        /// <returns></returns>
        public List<DuihuanModel> GetAllDuihuan()
        {
            List<DuihuanModel> list = new List<DuihuanModel>();
            string sql = string.Format("select * from Duihuan");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                DuihuanModel duihuanmodel = new DuihuanModel();
                duihuanmodel.id = (int)dr["id"];
                duihuanmodel.userid = (int)dr["userid"];
                duihuanmodel.c_id = (int)dr["c_id"];
                duihuanmodel.Y_huan = (int)dr["Y_huan"];
                duihuanmodel.username = dr["username"].ToString();
                duihuanmodel.C_idno = dr["C_idno"].ToString();
                duihuanmodel.lianxi = dr["lianxi"].ToString();
                duihuanmodel.email = dr["email"].ToString();
                duihuanmodel.other = dr["other"].ToString();
                duihuanmodel.thetime = (DateTime)dr["thetime"];
                duihuanmodel.D_content = dr["D_content"].ToString();
                list.Add(duihuanmodel);
            }
            dr.Close();
            return list;
        }
        /// <summary>
        /// �����ѯ
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public DuihuanModel GetDuihuanById(int id)
        {
            string sql = string.Format("select * from Duihuan where id={0}",id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            DuihuanModel duihuanmodel = new DuihuanModel();
            if (dr.Read())
            {
                duihuanmodel.id = (int)dr[0];
                duihuanmodel.userid = (int)dr[1];
                duihuanmodel.c_id = (int)dr[2];
                duihuanmodel.Y_huan = (int)dr[3];
                duihuanmodel.username = dr[4].ToString();
                duihuanmodel.C_idno = dr[5].ToString();
                duihuanmodel.lianxi = dr[6].ToString();
                duihuanmodel.email = dr[7].ToString();
                duihuanmodel.other = dr[8].ToString();
                duihuanmodel.thetime = (DateTime)dr[9];
                duihuanmodel.D_content = dr[10].ToString();
            }
            dr.Close();
            return duihuanmodel;
        }
    }
}
