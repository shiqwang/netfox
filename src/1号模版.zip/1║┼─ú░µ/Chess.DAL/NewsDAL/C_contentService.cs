using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class C_contentService
    {
        /// <summary>
        /// ����һ������
        /// </summary>
        /// <param name="contentmodel"></param>
        /// <returns></returns>
        public bool InsertC_content(C_contentModel contentmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into C_content values('");
            sb.Append(contentmodel.C_title);
            sb.Append("','");
            sb.Append(contentmodel.C_content);
            sb.Append("','");
            sb.Append(contentmodel.C_time);
            sb.Append("','");
            sb.Append(contentmodel.C_date);
            sb.Append("','");
            sb.Append(contentmodel.C_over);
            sb.Append("','");
            sb.Append(contentmodel.C_star);
            sb.Append("','");
            sb.Append(contentmodel.C_sai);
            sb.Append("','");
            sb.Append(contentmodel.paihang);
            sb.Append("','");
            sb.Append(contentmodel.j_content);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// ����һ������
        /// </summary>
        /// <param name="contentmodel"></param>
        /// <returns></returns>
        public bool UpdateC_content(C_contentModel contentmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update C_content set ");
            sb.Append("C_title='" + contentmodel.C_title + "',");
            sb.Append("C_content='" + contentmodel.C_content + "',");
            sb.Append("C_time='" + contentmodel.C_time + "',");
            sb.Append("C_date=" + contentmodel.C_date + ",");
            sb.Append("C_over=" + contentmodel.C_over + ",");
            sb.Append("C_star=" + contentmodel.C_star + ",");
            sb.Append("C_sai=" + contentmodel.C_sai + ",");
            sb.Append("paihang='" + contentmodel.paihang + "',");
            sb.Append("j_content='" + contentmodel.j_content + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where C_id=" + contentmodel.C_id + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// ɾ��һ������
        /// </summary>
        /// <param name="C_id"></param>
        /// <returns></returns>
        public bool DeleteC_content(int C_id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from C_content where C_id=");
            sb.Append(C_id);
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        /// <summary>
        /// ��ѯ��������
        /// </summary>
        /// <returns></returns>
        public List<C_contentModel> GetAllC_content()
        {
            List<C_contentModel> list = new List<C_contentModel>();
            string sql = string.Format("select * from C_content");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                C_contentModel contentmodel = new C_contentModel();
                contentmodel.C_id = (int)dr["C_id"];
                contentmodel.C_title = dr["C_title"].ToString();
                contentmodel.C_content = dr["C_content"].ToString();
                contentmodel.C_time = (DateTime)dr["C_title"];
                contentmodel.C_date = (int)dr["C_date"];
                contentmodel.C_over = (int)dr["C_over"];
                contentmodel.C_star = (int)dr["C_star"];
                contentmodel.C_sai = (int)dr["C_sai"];
                contentmodel.paihang = dr["paihang"].ToString();
                contentmodel.j_content = dr["j_content"].ToString();
                list.Add(contentmodel);
            }
            dr.Close();
            return list;
        }
        /// <summary>
        /// �����ѯ
        /// </summary>
        /// <param name="C_id"></param>
        /// <returns></returns>
        public C_contentModel GetC_contentByID(int C_id)
        {
            string sql = string.Format("select * from C_content where C_id={0}",C_id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            C_contentModel contentmodel = new C_contentModel();
            if (dr.Read())
            {
                contentmodel.C_id = (int)dr[0];
                contentmodel.C_title = dr[1].ToString();
                contentmodel.C_content = dr[2].ToString();
                contentmodel.C_time = (DateTime)dr[3];
                contentmodel.C_date = (int)dr[4];
                contentmodel.C_over = (int)dr[5];
                contentmodel.C_star = (int)dr[6];
                contentmodel.C_sai = (int)dr[7];
                contentmodel.paihang = dr[8].ToString();
                contentmodel.j_content = dr[9].ToString();
            }
            dr.Close();
            return contentmodel;
        }
    }
}
