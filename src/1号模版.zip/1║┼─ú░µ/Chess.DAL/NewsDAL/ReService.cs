using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class ReService
    {
        public bool InsertRe(ReModel remodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into Re values(");
            sb.Append(remodel.UserName);
            sb.Append(",'");
            sb.Append(remodel.ATxt);
            sb.Append(",'");
            sb.Append(remodel.BTxt);
            sb.Append(",'");
            sb.Append(remodel.Act);
            sb.Append(",'");
            sb.Append(remodel.PostDate);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateRe(ReModel remodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update Re set ");
            sb.Append("UserName='" + remodel.UserName + "',");
            sb.Append("ATxt='" + remodel.ATxt + "',");
            sb.Append("BTxt='" + remodel.BTxt + "',");
            sb.Append("Act=" + remodel.Act + ",");
            sb.Append("PostDate='" + remodel.PostDate + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where ID=" + remodel.ID + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteRe(int ID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from Re ");
            sb.Append(" where ID=" + ID + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<ReModel> GetAllRe()
        {
            List<ReModel> list = new List<ReModel>();
            string sql = string.Format("select * from Re");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                ReModel remodel = new ReModel();
                remodel.ID =(int)dr["ID"];
                remodel.UserName = dr["UserName"].ToString();
                remodel.ATxt = dr["ATxt"].ToString();
                remodel.BTxt = dr["BTxt"].ToString();
                remodel.Act =(int)dr["Act"];
                remodel.PostDate = (DateTime)dr["PostDate"];
                list.Add(remodel);
            }
            dr.Close();
            return list;
        }
        public ReModel GetReById(int ID)
        {
            string sql = string.Format("select * from Re where ID={0}",ID);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            ReModel remodel = new ReModel();
            if (dr.Read())
            {
                remodel.ID = (int)dr[0];
                remodel.UserName = dr[1].ToString();
                remodel.ATxt = dr[2].ToString();
                remodel.BTxt = dr[3].ToString();
                remodel.Act = (int)dr[4];
                remodel.PostDate = (DateTime)dr[5];
            }
            dr.Close();
            return remodel;
        }
    }
}
