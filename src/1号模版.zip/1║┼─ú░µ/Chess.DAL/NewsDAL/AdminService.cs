using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class AdminService
    {
        /// <summary>
        /// ���ӹ���Ա
        /// </summary>
        /// <param name="adminmodel"></param>
        /// <returns></returns>
        public bool InsertAdmin(AdminModel adminmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into news values(");
            sb.Append(adminmodel.admin);
            sb.Append("','");
            sb.Append(adminmodel.password);
            sb.Append("','");
            sb.Append(adminmodel.classcode);
            sb.Append("','");
            sb.Append(adminmodel.classname);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// �޸Ĺ���Ա��Ϣ
        /// </summary>
        /// <param name="adminmodel"></param>
        /// <returns></returns>
        public bool UpdateAdmin(AdminModel adminmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update admin set ");
            sb.Append("admin='" + adminmodel.admin + "',");
            sb.Append("password='" + adminmodel.password + "',");
            sb.Append("classcode='" + adminmodel.classcode + "',");
            sb.Append("classname='" + adminmodel.classname + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where id=" + adminmodel.id + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// ɾ������Ա
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool DeleteAdmin(int id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from admin");
            sb.Append(" where id=" + id + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        /// <summary>
        /// ��ѯ���й���Ա
        /// </summary>
        /// <returns></returns>
        public List<AdminModel> GetAllAdmin()
        {
            List<AdminModel> list = new List<AdminModel>();
            string sql = string.Format("select * from admin");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                AdminModel adminmodel = new AdminModel();
                adminmodel.id = (int)dr["id"];
                adminmodel.admin = dr["admin"].ToString();
                adminmodel.password = dr["password"].ToString();
                adminmodel.classcode = dr["classcode"].ToString();
                adminmodel.classname = dr["classname"].ToString();
                list.Add(adminmodel);
            }
            dr.Close();
            return list;
        }
        /// <summary>
        /// ���ݹ���ԱID��ѯ
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public AdminModel GetAllAdminByID(int id)
        {
            string sql = string.Format("select * from admin where id={0}",id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            AdminModel adminmodel = new AdminModel();
            if (dr.Read())
            {
                adminmodel.id = (int)dr[0];
                adminmodel.admin = dr[1].ToString();
                adminmodel.password = dr[2].ToString();
                adminmodel.classcode = dr[3].ToString();
                adminmodel.classname = dr[4].ToString();
            }
            dr.Close();
            return adminmodel;
        }
    }
}
