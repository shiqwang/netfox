using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class JiangpinService
    {
        public bool InsertJiangpin(JiangpinModel jiangpinmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into Jiangpin values(");
            sb.Append(jiangpinmodel.C_name);
            sb.Append(",'");
            sb.Append(jiangpinmodel.C_type);
            sb.Append(",'");
            sb.Append(jiangpinmodel.C_money);
            sb.Append(",'");
            sb.Append(jiangpinmodel.C_pic);
            sb.Append(",'");
            sb.Append(jiangpinmodel.C_other);
            sb.Append(",'");
            sb.Append(jiangpinmodel.C_time);
            sb.Append(",'");
            sb.Append(jiangpinmodel.C_vip);
            sb.Append(",'");
            sb.Append(jiangpinmodel.C_content);
            sb.Append(",'");
            sb.Append(jiangpinmodel.C_cun);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;                
            }
        }
        public bool UpdateJiangpin(JiangpinModel jiangpinmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update Jiangpin set ");
            sb.Append("C_name='" + jiangpinmodel.C_name + "',");
            sb.Append("C_type='" + jiangpinmodel.C_type + "',");
            sb.Append("C_money=" + jiangpinmodel.C_money + ",");
            sb.Append("C_pic='" + jiangpinmodel.C_pic + "',");
            sb.Append("C_other='" + jiangpinmodel.C_other + "',");
            sb.Append("C_time='" + jiangpinmodel.C_time + "',");
            sb.Append("C_vip=" + jiangpinmodel.C_vip + ",");
            sb.Append("C_content='" + jiangpinmodel.C_content + "',");
            sb.Append("C_cun=" + jiangpinmodel.C_cun + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where C_id=" + jiangpinmodel.C_id + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;                
            }
        }
        public bool DeleteJiangpin(int C_id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from Jiangpin ");
            sb.Append(" where C_id=" + C_id + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<JiangpinModel> GetAllJiangpin()
        {
            List<JiangpinModel> list = new List<JiangpinModel>();
            string sql = string.Format("select * from Jiangpin");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                JiangpinModel jiangpinmodel = new JiangpinModel();
                jiangpinmodel.C_id = (int)dr["C_id"];
                jiangpinmodel.C_name = dr["C_name"].ToString();
                jiangpinmodel.C_type = dr["C_type"].ToString();
                jiangpinmodel.C_money = (int)dr["C_money"];
                jiangpinmodel.C_pic = dr["C_pic"].ToString();
                jiangpinmodel.C_other = dr["C_other"].ToString();
                jiangpinmodel.C_time = (DateTime)dr["C_time"];
                jiangpinmodel.C_vip = (int)dr["C_vip"];
                jiangpinmodel.C_content = dr["C_content"].ToString();
                jiangpinmodel.C_cun = (int)dr["C_cun"];
                list.Add(jiangpinmodel);
            }
            dr.Close();
            return list;
        }
        public JiangpinModel GetJiangpinByID(int C_id)
        {
            string sql = string.Format("select * from Jiangpin where C_id ={0}",C_id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            JiangpinModel jiangpinmodel = new JiangpinModel();
            if (dr.Read())
            {
                jiangpinmodel.C_id = (int)dr[0];
                jiangpinmodel.C_name = dr[1].ToString();
                jiangpinmodel.C_type = dr[2].ToString();
                jiangpinmodel.C_money = (int)dr[3];
                jiangpinmodel.C_pic = dr[4].ToString();
                jiangpinmodel.C_other = dr[5].ToString();
                jiangpinmodel.C_time = (DateTime)dr[6];
                jiangpinmodel.C_vip = (int)dr[7];
                jiangpinmodel.C_content = dr[8].ToString();
                jiangpinmodel.C_cun = (int)dr[9];
            }
            dr.Close();
            return jiangpinmodel;
        }
    }
}
