using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class Wm_ggService
    {
        public bool InsertWm_gg(Wm_ggModel wm_ggmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into wm_gg values (");
            sb.Append(wm_ggmodel.tupian1);
            sb.Append(",'");
            sb.Append(wm_ggmodel.tupian2);
            sb.Append(",'");
            sb.Append(wm_ggmodel.tupian3);
            sb.Append(",'");
            sb.Append(wm_ggmodel.tupian4);
            sb.Append(",'");
            sb.Append(wm_ggmodel.tupian5);
            sb.Append(",'");
            sb.Append(wm_ggmodel.tupian6);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateWm_gg(Wm_ggModel wm_ggmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update wm_gg set ");
            sb.Append("tupian1='" + wm_ggmodel.tupian1 + "',");
            sb.Append("tupian2='" + wm_ggmodel.tupian2 + "',");
            sb.Append("tupian3='" + wm_ggmodel.tupian3 + "',");
            sb.Append("tupian4='" + wm_ggmodel.tupian4 + "',");
            sb.Append("tupian5='" + wm_ggmodel.tupian5 + "',");
            sb.Append("tupian6='" + wm_ggmodel.tupian6 + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where t_id=" + wm_ggmodel.t_id + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteWm_gg(int t_id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from wm_gg ");
            sb.Append(" where t_id=" + t_id + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<Wm_ggModel> GetAllWm_gg()
        {
            List<Wm_ggModel> list = new List<Wm_ggModel>();
            string sql = string.Format("select * from wm_gg");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                Wm_ggModel wm_ggmodel = new Wm_ggModel();
                wm_ggmodel.t_id = (int)dr["t_id"];
                wm_ggmodel.tupian1 = dr["tupian1"].ToString();
                wm_ggmodel.tupian2 = dr["tupian2"].ToString();
                wm_ggmodel.tupian3 = dr["tupian3"].ToString();
                wm_ggmodel.tupian4 = dr["tupian4"].ToString();
                wm_ggmodel.tupian5 = dr["tupian5"].ToString();
                wm_ggmodel.tupian6 = dr["tupian6"].ToString();
                list.Add(wm_ggmodel);
            }
            dr.Close();
            return list;
        }
        public Wm_ggModel GetWm_ggById(int t_id)
        {
            string sql = string.Format("select * from wm_gg where t_id={0}",t_id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            Wm_ggModel wm_ggmodel = new Wm_ggModel();
            if (dr.Read())
            {
                wm_ggmodel.t_id = (int)dr[0];
                wm_ggmodel.tupian1 = dr[1].ToString();
                wm_ggmodel.tupian2 = dr[2].ToString();
                wm_ggmodel.tupian3 = dr[3].ToString();
                wm_ggmodel.tupian4 = dr[4].ToString();
                wm_ggmodel.tupian5 = dr[5].ToString();
                wm_ggmodel.tupian6 = dr[6].ToString();
            }
            dr.Close();
            return wm_ggmodel;
        }
    }
}
