using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class C_typeService
    {
        /// <summary>
        /// ����һ������
        /// </summary>
        /// <param name="typemodel"></param>
        /// <returns></returns>
        public bool InsertC_type(C_typeModel typemodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into C_type values('");
            sb.Append(typemodel.t_name);
            sb.Append("','");
            sb.Append(typemodel.t_other);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// �޸�һ������
        /// </summary>
        /// <param name="typemodel"></param>
        /// <returns></returns>
        public bool UpdateC_type(C_typeModel typemodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update C_type set ");
            sb.Append("t_name='" + typemodel.t_name + "',");
            sb.Append("t_other='" + typemodel.t_other + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where ID=" + typemodel.ID + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;               
            }
        }
        /// <summary>
        /// ɾ��һ������
        /// </summary>
        /// <param name="typemodel"></param>
        /// <returns></returns>
        public bool DeleteC_type(int ID)
        {
            StringBuilder sb = new StringBuilder();            
            sb.Append("delete from C_type ");
            sb.Append(" where ID=" + ID + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        /// <summary>
        /// ��ѯ��������
        /// </summary>
        /// <returns></returns>
        public List<C_typeModel> GetAllC_type()
        {
            List<C_typeModel> list = new List<C_typeModel>();
            string sql = string.Format("select * from C_type");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                C_typeModel typemodel = new C_typeModel();
                typemodel.ID = (int)dr["ID"];
                typemodel.t_name = dr["t_name"].ToString();
                typemodel.t_other = dr["t_other"].ToString();
                list.Add(typemodel);
            }
            dr.Close();
            return list;
        }
        /// <summary>
        /// ���ݶ����ѯ
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public C_typeModel GetC_typeByID(int ID)
        {
            string sql = string.Format("select * from C_type where ID={0}", ID);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            C_typeModel typemodel = new C_typeModel();
            if (dr.Read())
            {
                typemodel.ID = (int)dr[0];
                typemodel.t_name = dr[1].ToString();
                typemodel.t_other = dr[2].ToString();
            }
            dr.Close();
            return typemodel;
        }
    }
}
