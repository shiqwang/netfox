using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Chess.DAL.DBHelper;
using Chess.Models.NewsModels;
using System.Collections;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class HdService
    {
        public List<HdModel> GetHdByTypeId(int typeid)
        {
            List<HdModel> list = new List<HdModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select h.id,substring(h.tit,0,20),h.zz,substring(h.sj,6,10),h.nr,h.dj,h.typeid,h.smallimg,h.px,t.lm ");
            sb.Append(" from hd h left join [type] t on h.typeid=t.id ");
            sb.Append(" where h.typeid=" + typeid + "");
            sb.Append(" order by h.px desc");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sb.ToString());
            while (dr.Read())
            {
                HdModel hdmodel = new HdModel();
                hdmodel.id = (int)dr[0];
                hdmodel.tit = dr[1].ToString();
                hdmodel.zz = dr[2].ToString();
                hdmodel.sj = dr[3].ToString();
                hdmodel.nr = dr[4].ToString();
                hdmodel.dj = UtilDal.ConvertNullable<int>(dr, 5);
                hdmodel.typeid = (int)dr[6];
                hdmodel.smallimg = dr[7].ToString();
                hdmodel.px = UtilDal.ConvertNullable<int>(dr, 8);
                hdmodel.typename = dr[9].ToString();
                list.Add(hdmodel);
            }
            dr.Close();
            return list;
        }
        public List<HdModel> GetHdListByTypeId(int typeid)
        {
            List<HdModel> list = new List<HdModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from hd ");
            sb.Append(" where typeid=" + typeid + "");
            sb.Append(" order by px desc");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sb.ToString());
            while (dr.Read())
            {
                HdModel hdmodel = new HdModel();
                hdmodel.id = (int)dr["id"];
                hdmodel.tit = dr["tit"].ToString();
                hdmodel.zz = dr["zz"].ToString();
                hdmodel.sj = dr["sj"].ToString();
                hdmodel.nr = dr["nr"].ToString();
                hdmodel.dj = UtilDal.ConvertNullable<int>(dr, "dj");
                hdmodel.typeid = (int)dr["typeid"];
                hdmodel.smallimg = dr["smallimg"].ToString();
                //hdmodel.rt = (int)dr["rt"];
                //hdmodel.rt = int.Parse(dr["rt"].ToString());
                hdmodel.px = UtilDal.ConvertNullable<int>(dr, "px");
                list.Add(hdmodel);
            }
            dr.Close();
            return list;
        }
        public List<HdModel> GetHdNewUserHelpByTypeId(int typeid)
        {
            List<HdModel> list = new List<HdModel>();
            StringBuilder sb = new StringBuilder();
            sb.Append("select  top 8 id,substring(tit,0,14),zz,substring(sj,6,10),nr,dj,typeid,smallimg,px");
            sb.Append(" from hd ");
            sb.Append(" where typeid=" + typeid + "");
            sb.Append(" order by px desc");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sb.ToString());
            while (dr.Read())
            {
                HdModel hdmodel = new HdModel();
                hdmodel.id = (int)dr[0];
                hdmodel.tit = dr[1].ToString();
                hdmodel.zz = dr[2].ToString();
                hdmodel.sj = dr[3].ToString();
                hdmodel.nr = dr[4].ToString();
                hdmodel.dj = UtilDal.ConvertNullable<int>(dr, 5);
                hdmodel.typeid = (int)dr[6];
                hdmodel.smallimg = dr[7].ToString();
                hdmodel.px = UtilDal.ConvertNullable<int>(dr, 8);
                list.Add(hdmodel);
            }
            dr.Close();
            return list;
        }
        public HdModel GetHdById(int id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from hd ");
            sb.Append(" where id=" + id + "");
            try
            {
                SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sb.ToString());
                HdModel hdmodel = new HdModel();
                while (dr.Read())
                {
                    hdmodel.id = (int)dr["id"];
                    hdmodel.tit = dr["tit"].ToString();
                    hdmodel.zz = dr["zz"].ToString();
                    hdmodel.sj = dr["sj"].ToString();
                    hdmodel.nr = dr["nr"].ToString();
                    hdmodel.dj = UtilDal.ConvertNullable<int>(dr, "dj");
                    hdmodel.typeid = (int)dr["typeid"];
                    hdmodel.smallimg = dr["smallimg"].ToString();
                    //hdmodel.rt = (int)dr["rt"];
                    //hdmodel.rt = int.Parse(dr["rt"].ToString());
                    hdmodel.px = UtilDal.ConvertNullable<int>(dr, "px");
                }
                dr.Close();
                return hdmodel;
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public List<HdModel> GetHdList(int typeID, int? top)
        {
            string sql = string.Format(@"select  {0} id,substring(tit,0,20) as tit,zz,substring(sj,6,10) as sj,nr,dj,typeid,smallimg,px from hd where typeid=@typeid order by id desc",
                                       top.HasValue ? "top " + top : "");
            SqlParameter param = NewsDBHelper.CreateParameter("@typeid", SqlDbType.Int, typeID);
            SqlDataReader reader = NewsDBHelper.GetDataReader(sql, param);
            List<HdModel> list = new List<HdModel>();
            while (reader.Read())
            {
                list.Add(SetHd(reader));
            }
            reader.Close();
            return list;
        }

        public List<HdModel> GetHdList(int? top)
        {
            string sql = string.Format(@"select  {0} h.id,substring(h.tit,0,20) as tit,h.zz,substring(h.sj,6,10) as sj,h.nr,h.dj,h.typeid,h.smallimg,h.px,t.lm as typename from hd h left join [type] t on h.typeid=t.id  order by h.id desc",
                                       top.HasValue ? "top " + top : "");
            SqlDataReader reader = NewsDBHelper.GetDataReader(sql);
            List<HdModel> list = new List<HdModel>();
            while (reader.Read())
            {
                HdModel hd = SetHd(reader);
                hd.typename = reader["typename"].ToString();

                DateTime dt = DateTime.Parse(hd.sj);
                hd.sj = dt.ToString("yyyy-MM-dd");
                list.Add(hd);
            }
            reader.Close();
            return list;
        }

        public List<HdModel> GetHdList()
        {
            string sql =
                    @"select h.id, h.tit,h.zz,h.sj,h.nr,h.dj,h.typeid,h.smallimg,h.px,t.lm as typename from hd h left join [type] t on h.typeid=t.id  order by h.id desc";

            SqlDataReader reader = NewsDBHelper.GetDataReader(sql);
            List<HdModel> list = new List<HdModel>();
            while (reader.Read())
            {
                HdModel hd = SetHd(reader);
                hd.typename = reader["typename"].ToString();
                //DateTime dt = DateTime.Parse(hd.sj);
                //hd.sj = dt.ToString("yyyy-MM-dd");
                list.Add(hd);
            }
            reader.Close();
            return list;
        }
        public List<HdModel> GetHdList(int typeid)
        {
            string sql =
                    @"select h.id, h.tit,h.zz,substring(h.sj,6,10) as sj,h.nr,h.dj,h.typeid,h.smallimg,h.px,t.lm as typename from hd h left join [type] t on h.typeid=t.id where h.typeid=@typeid  order by h.id desc";
            SqlParameter param = NewsDBHelper.CreateParameter("@typeid", SqlDbType.Int, typeid);
            SqlDataReader reader = NewsDBHelper.GetDataReader(sql, param);
            List<HdModel> list = new List<HdModel>();
            while (reader.Read())
            {
                HdModel hd = SetHd(reader);
                hd.typename = reader["typename"].ToString();
                DateTime dt = DateTime.Parse(hd.sj);
                hd.sj = dt.ToString("yyyy-MM-dd");
                list.Add(hd);
            }
            reader.Close();
            return list;
        }

        public HdModel SetHd(SqlDataReader dr)
        {
            HdModel hdmodel = new HdModel();
            hdmodel.id = (int)dr["id"];
            hdmodel.tit = dr["tit"].ToString();
            hdmodel.zz = dr["zz"].ToString();
            hdmodel.sj = dr["sj"].ToString();
            hdmodel.nr = dr["nr"].ToString();
            hdmodel.dj = UtilDal.ConvertNullable<int>(dr, "dj");
            hdmodel.typeid = (int)dr["typeid"];
            hdmodel.smallimg = dr["smallimg"].ToString();
            //hdmodel.rt = (int)dr["rt"];
            //hdmodel.rt = int.Parse(dr["rt"].ToString());
            hdmodel.px = UtilDal.ConvertNullable<int>(dr, "px");
            return hdmodel;
        }
        public List<HdModel> GetHdListtop5(int typeid)
        {
            string sql = string.Format(@"select top 5 h.id,substring(h.tit,0,20) as tit,h.zz,h.sj,h.nr,h.dj,h.typeid,h.smallimg,h.px,t.lm as typename from hd h left join [type] t on h.typeid=t.id where h.typeid=@typeid order by h.id desc");
            SqlParameter param = NewsDBHelper.CreateParameter("@typeid", SqlDbType.Int, typeid);
            SqlDataReader reader = NewsDBHelper.GetDataReader(sql, param);
            List<HdModel> list = new List<HdModel>();
            while (reader.Read())
            {
                HdModel hd = SetHd(reader);
                hd.typename = reader["typename"].ToString();
                DateTime dt = DateTime.Parse(hd.sj);
                hd.sj = dt.ToString("yyyy-MM-dd");
                list.Add(hd);
            }

            reader.Close();
            return list;
        }
        public List<HdModel> GetHdListRight(int typeID, int? top)
        {
            string sql = string.Format(@"select  {0} id,substring(tit,0,13) as tit,zz,substring(sj,6,5) as sj,nr,dj,typeid,smallimg,px from hd where typeid=@typeid order by id desc",
                                       top.HasValue ? "top " + top : "");
            SqlParameter param = NewsDBHelper.CreateParameter("@typeid", SqlDbType.Int, typeID);
            SqlDataReader reader = NewsDBHelper.GetDataReader(sql, param);
            List<HdModel> list = new List<HdModel>();
            while (reader.Read())
            {
                list.Add(SetHd(reader));
            }
            reader.Close();
            return list;
        }
        public List<HdModel> GetHdNewsById(int id)
        {
            string sql = string.Format(@"select h.id,h.tit,h.zz,h.sj,h.nr,h.dj,h.typeid,h.smallimg,h.px,t.lm as typename from hd h left join [type] t on t.id=h.typeid where h.id=@id");
            SqlParameter param = NewsDBHelper.CreateParameter("@id", SqlDbType.Int, id);
            SqlDataReader reader = NewsDBHelper.GetDataReader(sql, param);
            List<HdModel> list = new List<HdModel>();
            while (reader.Read())
            {
                HdModel hd = SetHd(reader);
                hd.typename = reader["typename"].ToString();
                DateTime dt = DateTime.Parse(hd.sj);
                hd.sj = dt.ToString("yyyy-MM-dd");
                list.Add(hd);
            }
            reader.Close();
            return list;
        }



    }
}
