using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class JinbiService
    {
        public bool InsertJinbi(JinbiModel jinbimodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into Jinbi values(");
            sb.Append(jinbimodel.jinbi);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateJinbi(JinbiModel jinbimodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update Jinbi set ");
            sb.Append("jinbi=" + jinbimodel.jinbi + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n,1);
            sb.Append(" where id=" + jinbimodel.id + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteJinbi(int id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from Jinbi ");
            sb.Append(" where id=" + id + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<JinbiModel> GetAllJinbi()
        {
            List<JinbiModel> list = new List<JinbiModel>();
            string sql = string.Format("select * from Jinbi");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                JinbiModel jinbimodel = new JinbiModel();
                jinbimodel.id =(int)dr["id"];
                jinbimodel.jinbi = (int)dr["jinbi"];
                list.Add(jinbimodel);
            }
            dr.Close();
            return list;
        }
        public JinbiModel GetJinbiById(int id)
        {
            string sql = string.Format("select * from Jinbi where id={0}", id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            JinbiModel jinbimodel = new JinbiModel();
            if (dr.Read())
            {
                jinbimodel.id = (int)dr[0];
                jinbimodel.jinbi = (int)dr[1];
            }
            dr.Close();
            return jinbimodel;
        }
    }
}
