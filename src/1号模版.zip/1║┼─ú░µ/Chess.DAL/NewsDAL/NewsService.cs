using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class NewsService
    {
        /// <summary>
        /// ����һ��������Ϣ
        /// </summary>
        /// <param name="newsmodel"></param>
        /// <returns></returns>
        public bool InsertNews(NewsModel newsmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into news values(");
            sb.Append(newsmodel.classcode);
            sb.Append(",'");
            sb.Append(newsmodel.newstitle);
            sb.Append(",'");
            sb.Append(newsmodel.newsdate);
            sb.Append(",'");
            sb.Append(newsmodel.newsinfo);
            sb.Append(",'");
            sb.Append(newsmodel.newscu);
            sb.Append(",'");
            sb.Append(newsmodel.newszz);
            sb.Append(",'");
            sb.Append(newsmodel.pl);
            sb.Append(",'");
            sb.Append(newsmodel.counts);
            sb.Append(",'");
            sb.Append(newsmodel.keyword);
            sb.Append(",'");
            sb.Append(newsmodel.gd);
            sb.Append(",'");
            sb.Append(newsmodel.ts);
            sb.Append(",'");
            sb.Append(newsmodel.down);
            sb.Append(",'");
            sb.Append(newsmodel.top2);
            sb.Append("')");
            //return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
            try
            {
                return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// �޸�һ��������Ϣ
        /// </summary>
        /// <param name="newsmodel"></param>
        /// <returns></returns>
        public bool UpdateNews(NewsModel newsmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update news set ");
            sb.Append("classcode='" + newsmodel.classcode + "',");
            sb.Append("newstitle='" + newsmodel.newstitle + "',");
            sb.Append("newsdate='" + newsmodel.newsdate + "',");
            sb.Append("newsinfo='" + newsmodel.newsinfo + "',");
            sb.Append("newscu='" + newsmodel.newscu + "',");
            sb.Append("newszz='" + newsmodel.newszz + "',");
            sb.Append("pl=" + (newsmodel.pl ? 1 : 0) + ",");
            sb.Append("counts=" + newsmodel.counts + ",");
            sb.Append("keyword='" + newsmodel.keyword + "',");
            sb.Append("gd=" + (newsmodel.gd ? 1 : 0) + ",");
            sb.Append("ts='" + newsmodel.ts + "',");
            sb.Append("down='" + newsmodel.down + "',");
            sb.Append("top2=" + (newsmodel.top2 ? 1 : 0) + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where id=" + newsmodel.id + " ");
            try
            {
                return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// ɾ��һ��������Ϣ
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool DeleteNews(int id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from news");
            sb.Append(" where id=" + id + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        /// <summary>
        /// ��ѯ����������Ϣ
        /// </summary>
        /// <returns></returns>
        public List<NewsModel> GetAllNews()
        {
            List<NewsModel> list = new List<NewsModel>();
            string sql = string.Format("select * from news");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                NewsModel newsmodel = new NewsModel();
                newsmodel.id = (int)dr["id"];
                newsmodel.classcode = dr["classcode"].ToString();
                newsmodel.newstitle = dr["newstitle"].ToString();
                newsmodel.newsdate = (DateTime)dr["newsdate"];
                newsmodel.newsinfo = dr["newsinfo"].ToString();
                newsmodel.newscu = dr["newscu"].ToString();
                newsmodel.newszz = dr["newszz"].ToString();
                newsmodel.pl = (bool)dr["pl"];
                newsmodel.counts = (int)dr["counts"];
                newsmodel.keyword = dr["keyword"].ToString();
                newsmodel.gd = (bool)dr["gd"];
                newsmodel.ts = (DateTime)dr["ts"];
                newsmodel.down = dr["down"].ToString();
                newsmodel.top2 = (bool)dr["top2"];
                list.Add(newsmodel);
            }
            dr.Close();
            return list;
        }
        /// <summary>
        /// ��������ID��ѯ
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public NewsModel GetNewsById(int id)
        {
            string sql = string.Format("select * from news where id={0}", id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            NewsModel newsmodel = new NewsModel();
            if (dr.Read())
            {
                newsmodel.id = (int)dr[0];
                newsmodel.classcode = dr[1].ToString();
                newsmodel.newstitle = dr[2].ToString();
                newsmodel.newsdate = (DateTime)dr[3];
                newsmodel.newsinfo = dr[4].ToString();
                newsmodel.newscu = dr[5].ToString();
                newsmodel.newszz = dr[6].ToString();
                newsmodel.pl = (bool)dr[7];
                newsmodel.counts = (int)dr[8];
                newsmodel.keyword = dr[9].ToString();
                newsmodel.gd = (bool)dr[10];
                newsmodel.ts = (DateTime)dr[11];
                newsmodel.down = dr[12].ToString();
                newsmodel.top2 = (bool)dr[13];
            }
            dr.Close();
            return newsmodel;
        }
        /// <summary>
        /// ������Ϣ����ѯ
        /// </summary>
        /// <param name="classcode"></param>
        /// <returns></returns>
        public List<NewsModel> GetNewsByClasscode(string classcode)
        {
            List<NewsModel> list = new List<NewsModel>();
            //string sql = string.Format("select * from news where classcode={0}", classcode);
            StringBuilder sb = new StringBuilder();
            sb.Append("select * from news where classcode='");
            sb.Append(classcode);
            sb.Append("'");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sb.ToString());
            while(dr.Read())
            {
                NewsModel newsmodel = new NewsModel();
                newsmodel.id = (int)dr["id"];
                newsmodel.classcode = dr["classcode"].ToString();
                newsmodel.newstitle = dr["newstitle"].ToString();
                newsmodel.newsdate = (DateTime)dr["newsdate"];
                newsmodel.newsinfo = dr["newsinfo"].ToString();
                newsmodel.newscu = dr["newscu"].ToString();
                newsmodel.newszz = dr["newszz"].ToString();
                newsmodel.pl = (bool)dr["pl"];
                newsmodel.counts = (int)dr["counts"];
                newsmodel.keyword = dr["keyword"].ToString();
                newsmodel.gd = (bool)dr["gd"];
                newsmodel.ts = (DateTime)dr["ts"];
                newsmodel.down = dr["down"].ToString();
                newsmodel.top2 = (bool)dr["top2"];
                list.Add(newsmodel);
            }
            dr.Close();
            return list;
        }
    }
}
