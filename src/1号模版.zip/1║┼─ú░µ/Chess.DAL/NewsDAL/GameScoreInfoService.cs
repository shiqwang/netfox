using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class GameScoreInfoService
    {
        /// <summary>
        /// ����һ������
        /// </summary>
        /// <param name="gamescoreinfo"></param>
        /// <returns></returns>
        public bool InsertGameScoreInfo(GameScoreInfoModel gamescoreinfo)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into GameScoreInfo values('");
            sb.Append(gamescoreinfo.UserID);
            sb.Append("','");
            sb.Append(gamescoreinfo.Score);
            sb.Append("','");
            sb.Append(gamescoreinfo.WinCount);
            sb.Append("','");
            sb.Append(gamescoreinfo.LostCount);
            sb.Append("','");
            sb.Append(gamescoreinfo.DrawCount);
            sb.Append("','");
            sb.Append(gamescoreinfo.FleeCount);
            sb.Append("','");
            sb.Append(gamescoreinfo.UserRight);
            sb.Append("','");
            sb.Append(gamescoreinfo.MasterRight);
            sb.Append("','");
            sb.Append(gamescoreinfo.MasterOrder);
            sb.Append("','");
            sb.Append(gamescoreinfo.RegisterIP);
            sb.Append("','");
            sb.Append(gamescoreinfo.LastLogonIP);
            sb.Append("','");
            sb.Append(gamescoreinfo.RegisterDate);
            sb.Append("','");
            sb.Append(gamescoreinfo.LastLogonDate);
            sb.Append("','");
            sb.Append(gamescoreinfo.AllLogonTimes);
            sb.Append("','");
            sb.Append(gamescoreinfo.PlayTimeCount);
            sb.Append("','");
            sb.Append(gamescoreinfo.OnLineTimeCount);
            sb.Append("','");
            sb.Append(gamescoreinfo.C_id);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;                
            }
        }
        /// <summary>
        /// ����һ������
        /// </summary>
        /// <param name="gamescoreinfo"></param>
        /// <returns></returns>
        public bool UpdateGameScoreInfo(GameScoreInfoModel gamescoreinfo)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update GameScoreInfo set ");
            sb.Append("UserID=" + gamescoreinfo.UserID + ",");
            sb.Append("Score=" + gamescoreinfo.Score + ",");
            sb.Append("WinCount=" + gamescoreinfo.WinCount + ",");
            sb.Append("LostCount=" + gamescoreinfo.LostCount + ",");
            sb.Append("DrawCount=" + gamescoreinfo.DrawCount + ",");
            sb.Append("FleeCount=" + gamescoreinfo.FleeCount + ",");
            sb.Append("UserRight=" + gamescoreinfo.UserRight + ",");
            sb.Append("MasterRight=" + gamescoreinfo.MasterRight + ",");
            sb.Append("MasterOrder=" + gamescoreinfo.MasterOrder + ",");
            sb.Append("RegisterIP='" + gamescoreinfo.RegisterIP + "',");
            sb.Append("LastLogonIP='" + gamescoreinfo.LastLogonIP + "',");
            sb.Append("RegisterDate='" + gamescoreinfo.RegisterDate + "',");
            sb.Append("LastLogonDate='" + gamescoreinfo.LastLogonDate + "',");
            sb.Append("AllLogonTimes=" + gamescoreinfo.AllLogonTimes + ",");
            sb.Append("PlayTimeCount=" + gamescoreinfo.PlayTimeCount + ",");
            sb.Append("OnLineTimeCount=" + gamescoreinfo.OnLineTimeCount + ",");
            sb.Append("C_id=" + gamescoreinfo.C_id + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n,1);
            sb.Append(" where G_id="+ gamescoreinfo.G_id+" ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// ɾ��һ������
        /// </summary>
        /// <param name="G_id"></param>
        /// <returns></returns>
        public bool DeleteGameScoreInfo(int G_id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from GameScoreInfo ");
            sb.Append(" where G_id=" + G_id + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        /// <summary>
        /// ��ѯ��������
        /// </summary>
        /// <returns></returns>
        public List<GameScoreInfoModel> GetAllGameScoreInfo()
        {
            List<GameScoreInfoModel> list = new List<GameScoreInfoModel>();
            string sql = string.Format("select * from GameScoreInfo");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                GameScoreInfoModel gamescoreinfo = new GameScoreInfoModel();
                gamescoreinfo.G_id = (int)dr["G_id"];
                gamescoreinfo.UserID = (int)dr["UserID"];
                gamescoreinfo.Score = (long)dr["Score"];
                gamescoreinfo.WinCount = (int)dr["WinCount"];
                gamescoreinfo.LostCount = (int)dr["LostCount"];
                gamescoreinfo.DrawCount = (int)dr["DrawCount"];
                gamescoreinfo.FleeCount = (int)dr["FleeCount"];
                gamescoreinfo.UserRight = (int)dr["UserRight"];
                gamescoreinfo.MasterRight = (int)dr["MasterRight"];
                gamescoreinfo.MasterOrder = (int)dr["MasterOrder"];
                gamescoreinfo.RegisterIP = dr["RegisterIP"].ToString();
                gamescoreinfo.LastLogonIP = dr["LastLogonIP"].ToString();
                gamescoreinfo.RegisterDate = (DateTime)dr["RegisterDate"];
                gamescoreinfo.LastLogonDate = (DateTime)dr["LastLogonDate"];
                gamescoreinfo.AllLogonTimes = (int)dr["AllLogonTimes"];
                gamescoreinfo.PlayTimeCount = (int)dr["PlayTimeCount"];
                gamescoreinfo.OnLineTimeCount = (int)dr["OnLineTimeCount"];
                gamescoreinfo.C_id = (int)dr["C_id"];
                list.Add(gamescoreinfo);
            }
            dr.Close();
            return list;
        }
        /// <summary>
        /// �����ѯ
        /// </summary>
        /// <param name="G_id"></param>
        /// <returns></returns>
        public GameScoreInfoModel GetGameScoreInfoById(int G_id)
        {
            string sql = string.Format("select * from GameScoreInfo where G_id={0}",G_id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            GameScoreInfoModel gamescoreinfo = new GameScoreInfoModel();
            if (dr.Read())
            {
                gamescoreinfo.G_id = (int)dr[0];
                gamescoreinfo.UserID = (int)dr[1];
                gamescoreinfo.Score = (long)dr[2];
                gamescoreinfo.WinCount = (int)dr[3];
                gamescoreinfo.LostCount = (int)dr[4];
                gamescoreinfo.DrawCount = (int)dr[5];
                gamescoreinfo.FleeCount = (int)dr[6];
                gamescoreinfo.UserRight = (int)dr[7];
                gamescoreinfo.MasterRight = (int)dr[8];
                gamescoreinfo.MasterOrder = (int)dr[9];
                gamescoreinfo.RegisterIP = dr[10].ToString();
                gamescoreinfo.LastLogonIP = dr[11].ToString();
                gamescoreinfo.RegisterDate = (DateTime)dr[12];
                gamescoreinfo.LastLogonDate = (DateTime)dr[13];
                gamescoreinfo.AllLogonTimes = (int)dr[14];
                gamescoreinfo.PlayTimeCount = (int)dr[15];
                gamescoreinfo.OnLineTimeCount = (int)dr[16];
                gamescoreinfo.C_id = (int)dr[17];
            }
            dr.Close();
            return gamescoreinfo;
        }
    }
}
