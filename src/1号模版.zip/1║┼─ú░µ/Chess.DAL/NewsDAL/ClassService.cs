using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class ClassService
    {
        /// <summary>
        /// ������Ϣ���
        /// </summary>
        /// <param name="classmodel"></param>
        /// <returns></returns>
        public bool InsertClass(ClassModel classmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into class values(");
            sb.Append(classmodel.classcode);
            sb.Append(",'");
            sb.Append(classmodel.classname);
            sb.Append(",'");
            sb.Append(classmodel.classpic);
            sb.Append("')");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0 ? true : false;
        }
        /// <summary>
        /// �޸���Ϣ���
        /// </summary>
        /// <param name="classmodel"></param>
        /// <returns></returns>
        public bool UpdateClass(ClassModel classmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update class set ");
            sb.Append("classcode='" + classmodel.classcode + "',");
            sb.Append("classname='" + classmodel.classname + "',");
            sb.Append("classpic='" + classmodel.classpic + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where id=" + classmodel.id + " ");
            try
            {
                return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// ɾ���������
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool DeleteClass(int id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from class ");
            sb.Append(" where id="+id+" ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        /// <summary>
        /// ��ѯ�����������
        /// </summary>
        /// <returns></returns>
        public List<ClassModel> GetAllClass()
        {
            List<ClassModel> list = new List<ClassModel>();
            string sql = string.Format("select * from class");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                ClassModel classmodel = new ClassModel();
                classmodel.id = (int)dr["id"];
                classmodel.classcode = dr["classcode"].ToString();
                classmodel.classname = dr["classname"].ToString();
                classmodel.classpic = dr["classpic"].ToString();
                list.Add(classmodel);
            }
            dr.Close();
            return list;
        }
        /// <summary>
        /// �����������ID��ѯ
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ClassModel GetClassById(int id)
        {
            string sql = string.Format("select * from class where id={0}",id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            ClassModel classmodel = new ClassModel();
            if (dr.Read())
            {
                classmodel.id = (int)dr[0];
                classmodel.classcode = dr[1].ToString();
                classmodel.classname = dr[2].ToString();
                classmodel.classpic = dr[3].ToString();
            }
            dr.Close();
            return classmodel;
        }
    }
}
