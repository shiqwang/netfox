﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class GuanggaoService
    {
        /// <summary>
        /// 添加一条数据
        /// </summary>
        /// <param name="guanggaomodel"></param>
        /// <returns></returns>
        public bool InsertGuanggao(GuanggaoModel guanggaomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into Guanggao values('");
            sb.Append(guanggaomodel.G_pic);
            sb.Append("','");
            sb.Append(guanggaomodel.G_http);
            sb.Append("','");
            sb.Append(guanggaomodel.G_time);
            sb.Append("','");
            sb.Append(guanggaomodel.G_other);
            sb.Append("','");
            sb.Append(guanggaomodel.G_type);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        /// <param name="guanggaomodel"></param>
        /// <returns></returns>
        public bool UpdateGuanggao(GuanggaoModel guanggaomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update Guanggao set ");
            sb.Append("G_pic='" + guanggaomodel.G_pic + "',");
            sb.Append("G_http='" + guanggaomodel.G_http + "',");
            sb.Append("G_time='" + guanggaomodel.G_time + "',");
            sb.Append("G_other='" + guanggaomodel.G_other + "',");
            sb.Append("G_type='" + guanggaomodel.G_type + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where G_id=" + guanggaomodel.G_id + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// 删除一条数据
        /// </summary>
        /// <param name="G_id"></param>
        /// <returns></returns>
        public bool DeleteGuanggao(int G_id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from Guanggao ");
            sb.Append(" where G_id=" + G_id + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<GuanggaoModel> GetAllGuanggao()
        {
            List<GuanggaoModel> list = new List<GuanggaoModel>();
            string sql = string.Format("select * from Guanggao");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                GuanggaoModel guanggaomodel = new GuanggaoModel();
                guanggaomodel.G_id = (int)dr["G_id"];
                guanggaomodel.G_pic = dr["G_pic"].ToString();
                guanggaomodel.G_http = dr["G_http"].ToString();
                guanggaomodel.G_time = (DateTime)dr["G_time"];
                guanggaomodel.G_other = dr["G_other"].ToString();
                guanggaomodel.G_type = dr["G_type"].ToString();
                list.Add(guanggaomodel);
            }
            dr.Close();
            return list;
        }
        public GuanggaoModel GetGuanggaoById(int G_id)
        {
            string sql = string.Format("select * from Guanggao where G_id={0}",G_id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            GuanggaoModel guanggaomodel = new GuanggaoModel();
            if (dr.Read())
            {
                guanggaomodel.G_id = (int)dr[0];
                guanggaomodel.G_pic = dr[1].ToString();
                guanggaomodel.G_http = dr[2].ToString();
                guanggaomodel.G_time = (DateTime)dr[3];
                guanggaomodel.G_other = dr[4].ToString();
                guanggaomodel.G_type = dr[5].ToString();
            }
            dr.Close();
            return guanggaomodel;
        }
    }
}
