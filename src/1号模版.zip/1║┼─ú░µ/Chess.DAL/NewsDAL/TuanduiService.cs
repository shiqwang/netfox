using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class TuanduiService
    {
        public bool InsertTuandui(TuanduiModel tuanduimodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into Tuandui values (");
            sb.Append(tuanduimodel.U_name);
            sb.Append(",'");
            sb.Append(tuanduimodel.T_name);
            sb.Append(",'");
            sb.Append(tuanduimodel.T_qq);
            sb.Append(",'");
            sb.Append(tuanduimodel.T_url);
            sb.Append(",'");
            sb.Append(tuanduimodel.QQ);
            sb.Append(",'");
            sb.Append(tuanduimodel.E_mail);
            sb.Append(",'");
            sb.Append(tuanduimodel.T_tel);
            sb.Append(",'");
            sb.Append(tuanduimodel.Address);
            sb.Append(",'");
            sb.Append(tuanduimodel.T_type);
            sb.Append(",'");
            sb.Append(tuanduimodel.T_date);
            sb.Append(",'");
            sb.Append(tuanduimodel.T_num);
            sb.Append(",'");
            sb.Append(tuanduimodel.T_luntan);
            sb.Append(",'");
            sb.Append(tuanduimodel.T_zongzhi);
            sb.Append(",'");
            sb.Append(tuanduimodel.T_content);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateTuandui(TuanduiModel tuanduimodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update Tuandui set ");
            sb.Append("U_name='" + tuanduimodel.U_name + "',");
            sb.Append("T_name='" + tuanduimodel.T_name + "',");
            sb.Append("T_qq=" + tuanduimodel.T_qq + ",");
            sb.Append("T_url='" + tuanduimodel.T_url + "',");
            sb.Append("QQ=" + tuanduimodel.QQ + ",");
            sb.Append("E_mail='" + tuanduimodel.E_mail + "',");
            sb.Append("T_tel='" + tuanduimodel.T_tel + "',");
            sb.Append("Address='" + tuanduimodel.Address + "',");
            sb.Append("T_type=" + tuanduimodel.T_type + ",");
            sb.Append("T_date='" + tuanduimodel.T_date + "',");
            sb.Append("T_num=" + tuanduimodel.T_num + ",");
            sb.Append("T_luntan='" + tuanduimodel.T_luntan + "',");
            sb.Append("T_zongzhi='" + tuanduimodel.T_zongzhi + "',");
            sb.Append("T_content='" + tuanduimodel.T_content + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where T_id=" + tuanduimodel.T_id + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteTuandui(int T_id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from Tuandui ");
            sb.Append(" where T_id=" + T_id + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<TuanduiModel> GetAllTuandui()
        {
            List<TuanduiModel> list = new List<TuanduiModel>();
            string sql = string.Format("select * from Tuandui");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                TuanduiModel tuanduimodel = new TuanduiModel();
                tuanduimodel.T_id = (int)dr["T_id"];
                tuanduimodel.U_name = dr["U_name"].ToString();
                tuanduimodel.T_name = dr["T_name"].ToString();
                tuanduimodel.T_qq = (int)dr["T_qq"];
                tuanduimodel.T_url = dr["T_url"].ToString();
                tuanduimodel.QQ = (int)dr["QQ"];
                tuanduimodel.E_mail = dr["E_mail"].ToString();
                tuanduimodel.T_tel = dr["T_tel"].ToString();
                tuanduimodel.Address = dr["Address"].ToString();
                tuanduimodel.T_type = (int)dr["T_type"];
                tuanduimodel.T_date = (DateTime)dr["T_date"];
                tuanduimodel.T_num = (int)dr["T_num"];
                tuanduimodel.T_luntan = dr["T_luntan"].ToString();
                tuanduimodel.T_zongzhi = dr["T_zongzhi"].ToString();
                tuanduimodel.T_content = dr["T_content"].ToString();
                list.Add(tuanduimodel);
            }
            dr.Close();
            return list;
        }
        public TuanduiModel GetTuanduiByID(int T_id)
        {
            string sql = string.Format("select * from Tuandui where T_id={0}",T_id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            TuanduiModel tuanduimodel = new TuanduiModel();
            if (dr.Read())
            {
                tuanduimodel.T_id = (int)dr[0];
                tuanduimodel.U_name = dr[1].ToString();
                tuanduimodel.T_name = dr[2].ToString();
                tuanduimodel.T_qq = (int)dr[3];
                tuanduimodel.T_url = dr[4].ToString();
                tuanduimodel.QQ = (int)dr[5];
                tuanduimodel.E_mail = dr[6].ToString();
                tuanduimodel.T_tel = dr[7].ToString();
                tuanduimodel.Address = dr[8].ToString();
                tuanduimodel.T_type = (int)dr[9];
                tuanduimodel.T_date = (DateTime)dr[10];
                tuanduimodel.T_num = (int)dr[11];
                tuanduimodel.T_luntan = dr[12].ToString();
                tuanduimodel.T_zongzhi = dr[13].ToString();
                tuanduimodel.T_content = dr[14].ToString();
            }
            dr.Close();
            return tuanduimodel;
        }
    }
}
