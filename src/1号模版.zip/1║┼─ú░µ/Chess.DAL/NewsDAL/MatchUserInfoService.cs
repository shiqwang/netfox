using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class MatchUserInfoService
    {
        public bool InsertMatchUserInfo(MatchUserInfoModel matchuserinfo)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into MatchUserInfo values(");
            sb.Append(matchuserinfo.KindID);
            sb.Append(",'");
            sb.Append(matchuserinfo.ServerID);
            sb.Append(",'");
            sb.Append(matchuserinfo.Username);
            sb.Append(",'");
            sb.Append(matchuserinfo.IDCard);
            sb.Append(",'");
            sb.Append(matchuserinfo.Age);
            sb.Append(",'");
            sb.Append(matchuserinfo.Profession);
            sb.Append(",'");
            sb.Append(matchuserinfo.PhoneNo);
            sb.Append(",'");
            sb.Append(matchuserinfo.Address);
            sb.Append(",'");
            sb.Append(matchuserinfo.CollectDate);
            sb.Append(",'");
            sb.Append(matchuserinfo.ClientIP);
            sb.Append(",'");
            sb.Append(matchuserinfo.C_id);
            sb.Append(",'");
            sb.Append(matchuserinfo.U_name);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateMatchUserInfo(MatchUserInfoModel matchuserinfomodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update MatchUserInfo set ");
            sb.Append("KindID=" + matchuserinfomodel.KindID + ",");
            sb.Append("ServerID=" + matchuserinfomodel.ServerID + ",");
            sb.Append("Username='" + matchuserinfomodel.Username + "',");
            sb.Append("IDCard='" + matchuserinfomodel.IDCard + "',");
            sb.Append("Age=" + matchuserinfomodel.Age + ",");
            sb.Append("Profession='" + matchuserinfomodel.Profession + "',");
            sb.Append("PhoneNo='" + matchuserinfomodel.PhoneNo + "',");
            sb.Append("Address='" + matchuserinfomodel.Address + "',");
            sb.Append("CollectDate='" + matchuserinfomodel.CollectDate + "',");
            sb.Append("ClientIP='" + matchuserinfomodel.ClientIP + "',");
            sb.Append("C_id=" + matchuserinfomodel.C_id + ",");
            sb.Append("U_name='" + matchuserinfomodel.U_name + "',");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where UserID=" + matchuserinfomodel.UserID + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteMatchUserInfo(int UserID)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from MatchUserInfo ");
            sb.Append(" where UserID=" + UserID + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<MatchUserInfoModel> GetAllMatchUserInfo()
        {
            List<MatchUserInfoModel> list = new List<MatchUserInfoModel>();
            string sql = string.Format("select * from MatchUserInfo");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                MatchUserInfoModel matchuserinfo = new MatchUserInfoModel();
                matchuserinfo.UserID = (int)dr["UserID"];
                matchuserinfo.KindID = (int)dr["KindID"];
                matchuserinfo.ServerID = (int)dr["ServerID"];
                matchuserinfo.Username = dr["Username"].ToString();
                matchuserinfo.IDCard = dr["IDCard"].ToString();
                matchuserinfo.Age = (int)dr["Age"];
                matchuserinfo.Profession = dr["Profession"].ToString();
                matchuserinfo.PhoneNo = dr["PhoneNo"].ToString();
                matchuserinfo.Address = dr["Address"].ToString();
                matchuserinfo.CollectDate = (DateTime)dr["CollectDate"];
                matchuserinfo.ClientIP = dr["ClientIP"].ToString();
                matchuserinfo.C_id = (int)dr["C_id"];
                matchuserinfo.U_name = dr["U_name"].ToString();
                list.Add(matchuserinfo);
            }
            dr.Close();
            return list;
        }
        public MatchUserInfoModel GetMatchUserInfoById(int UserID)
        {
            string sql = string.Format("select * from MatchUserInfo where UserID={0}",UserID);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            MatchUserInfoModel matchuserinfo = new MatchUserInfoModel();
            if (dr.Read())
            {
                matchuserinfo.UserID = (int)dr[0];
                matchuserinfo.KindID = (int)dr[1];
                matchuserinfo.ServerID = (int)dr[2];
                matchuserinfo.Username = dr[3].ToString();
                matchuserinfo.IDCard = dr[4].ToString();
                matchuserinfo.Age = (int)dr[5];
                matchuserinfo.Profession = dr[6].ToString();
                matchuserinfo.PhoneNo = dr[7].ToString();
                matchuserinfo.Address = dr[8].ToString();
                matchuserinfo.CollectDate = (DateTime)dr[9];
                matchuserinfo.ClientIP = dr[10].ToString();
                matchuserinfo.C_id = (int)dr[11];
                matchuserinfo.U_name = dr[12].ToString();
            }
            dr.Close();
            return matchuserinfo;
        }
    }
}
