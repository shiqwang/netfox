using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.NewsModels;
using System.Data.SqlClient;

namespace Chess.DAL.NewsDAL
{
    public class JiazService
    {
        public bool InsertJiaz(JiazModel jiazmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("insert into Jiaz values(");
            sb.Append(jiazmodel.T_id);
            sb.Append(",'");
            sb.Append(jiazmodel.U_id);
            sb.Append(",'");
            sb.Append(jiazmodel.T_type);
            sb.Append("')");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool UpdateJiaz(JiazModel jiazmodel)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("update Jiaz set ");
            sb.Append("T_id=" + jiazmodel.T_id+ ",");
            sb.Append("U_id=" + jiazmodel.U_id + ",");
            sb.Append("T_type=" + jiazmodel.T_type + ",");
            int n = sb.ToString().LastIndexOf(",");
            sb.Remove(n, 1);
            sb.Append(" where J_id=" + jiazmodel.J_id + " ");
            try
            {
                return (DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString())) > 0;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool DeleteJiaz(int J_id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("delete from Jiaz ");
            sb.Append(" where J_id=" + J_id + " ");
            return DBHelper.NewsDBHelper.GetExcuteNonQuery(sb.ToString()) > 0;
        }
        public List<JiazModel> GetAllJiaz()
        {
            List<JiazModel> list = new List<JiazModel>();
            string sql = string.Format("select * from Jiaz");
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            while (dr.Read())
            {
                JiazModel jiazmodel = new JiazModel();
                jiazmodel.J_id = (int)dr["J_id"];
                jiazmodel.T_id = (int)dr["T_id"];
                jiazmodel.U_id = (int)dr["U_id"];
                jiazmodel.T_type = (int)dr["T_type"];
                list.Add(jiazmodel);
            }
            dr.Close();
            return list;
        }
        public JiazModel GetJiazById(int J_id)
        {
            string sql = string.Format("select * from Jiaz where J_id={0}",J_id);
            SqlDataReader dr = DBHelper.NewsDBHelper.GetDataReader(sql);
            JiazModel jiazmodel = new JiazModel();
            if (dr.Read())
            {
                jiazmodel.J_id = (int)dr[0];
                jiazmodel.T_id = (int)dr[1];
                jiazmodel.U_id = (int)dr[2];
                jiazmodel.T_type = (int)dr[3];
            }
            dr.Close();
            return jiazmodel;
        }
    }
}
