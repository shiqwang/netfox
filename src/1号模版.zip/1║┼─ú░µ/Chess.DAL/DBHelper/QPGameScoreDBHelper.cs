using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.DAL.DBHelper
{
    class QPGameScoreDBHelper
    {
    }
}
