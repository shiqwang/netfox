﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPAdminModels;
using System.Data.SqlClient;
using Chess.DAL.DBHelper;
using System.Data;

namespace Chess.DAL.QPAdminDAL
{
    public class HdService
    {
        public List<HdModel> GetHdlistByTypeID(int typeID)
        {
            string sql = string.Format(@"select top 6 id,tit,zz,sj,nr,dj,typeid,smallimg,px,Arret_Color,Arret_Top from hd where typeid=@typeid and Arret_Top=1 order by id desc");
            SqlParameter param = QPAdminDBHelper.CreateParameter("@typeid", SqlDbType.Int, typeID);
            SqlDataReader reader = QPAdminDBHelper.GetDataReader(sql, param);
            List<HdModel> list = new List<HdModel>();
            while (reader.Read())
            {
                list.Add(SetHd(reader));
            }
            reader.Close();
            return list;
        }
        public HdModel SetHd(SqlDataReader dr)
        {
            HdModel hdmodel = new HdModel();
            hdmodel.id = (int)dr["id"];
            hdmodel.tit = dr["tit"].ToString();
            hdmodel.zz = dr["zz"].ToString();
            hdmodel.sj = dr["sj"].ToString();
            hdmodel.nr = dr["nr"].ToString();
            hdmodel.dj = UtilDal.ConvertNullable<int>(dr, "dj");
            hdmodel.typeid = (int)dr["typeid"];
            hdmodel.smallimg = dr["smallimg"].ToString();
            hdmodel.px = UtilDal.ConvertNullable<int>(dr, "px");
            hdmodel.Arret_Color = dr["Arret_Color"].ToString();
            hdmodel.Arret_Top = (int)dr["Arret_Top"];
            return hdmodel;
        }


        public List<HdModel> GetHdListByTypeIDLeft(int typeID)
        {
            string sql = string.Format(@"select top 8 id,substring(tit,0,14) as tit,zz,substring(sj,6,10) as sj,nr,dj,typeid,smallimg,px,Arret_Color,Arret_Top from hd where typeid=@typeid and Arret_Top=1 order by id desc ");
            SqlParameter param = QPAdminDBHelper.CreateParameter("@typeid", SqlDbType.Int, typeID);
            SqlDataReader reader = QPAdminDBHelper.GetDataReader(sql, param);
            List<HdModel> list = new List<HdModel>();
            while (reader.Read())
            {
                list.Add(SetHd(reader));
            }
            reader.Close();
            return list;
        }

        public List<HdModel> GetHdList()
        {
            string sql = string.Format(@"select * from hd order by id desc");
            SqlDataReader reader = QPAdminDBHelper.GetDataReader(sql);
            List<HdModel> list = new List<HdModel>();
            while (reader.Read())
            {
                list.Add(SetHd(reader));

            }
            reader.Close();
            return list;
        }

        public HdModel GetHdById(int id)
        {
            string sql = string.Format(@"select * from hd where id=@id");
            SqlParameter param = QPAdminDBHelper.CreateParameter("@id", SqlDbType.Int, id);
            SqlDataReader reader = QPAdminDBHelper.GetDataReader(sql, param);
            HdModel hdmodel = new HdModel();
            while (reader.Read())
            {
                hdmodel.id = (int)reader["id"];
                hdmodel.tit = reader["tit"].ToString();
                hdmodel.zz = reader["zz"].ToString();
                hdmodel.sj = reader["sj"].ToString();
                hdmodel.nr = reader["nr"].ToString();
                hdmodel.dj = UtilDal.ConvertNullable<int>(reader, "dj");
                hdmodel.typeid = (int)reader["typeid"];
                hdmodel.smallimg = reader["smallimg"].ToString();
                hdmodel.px = UtilDal.ConvertNullable<int>(reader, "px");
                hdmodel.Arret_Color = reader["Arret_Color"].ToString();
                hdmodel.Arret_Top = (int)reader["Arret_Top"];
            }
            reader.Close();
            return hdmodel;
        }
    }
}
