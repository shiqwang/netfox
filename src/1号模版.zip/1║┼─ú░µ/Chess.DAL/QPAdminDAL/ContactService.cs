﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPAdminModels;
using System.Data.SqlClient;
using Chess.DAL.DBHelper;

namespace Chess.DAL.QPAdminDAL
{
    public class ContactService
    {
        private ContactModel SetHd(SqlDataReader dr)
        {
            ContactModel ContModel = new ContactModel();
            ContModel.ID = (int)dr["ID"];
            ContModel.E_mail = dr["E_mail"].ToString();
            ContModel.Tel = dr["Tel"].ToString();
            ContModel.QQ = dr["QQ"].ToString();
            ContModel.QQ2 = dr["QQ2"].ToString();
            ContModel.Addr = dr["Addr"].ToString();
            ContModel.Co_Name = dr["Co_Name"].ToString();
            ContModel.icp = dr["icp"].ToString();
            ContModel.keyword = dr["keyword"].ToString();
            ContModel.Description = dr["Description"].ToString();
            ContModel.Co_Url = dr["Co_Url"].ToString();
            ContModel.Post_Code = dr["Post_Code"].ToString();
            return ContModel; 
        }
        public ContactModel GetContact()
        {
            string sql = string.Format(@"select * from Contact");
            SqlDataReader reader = QPAdminDBHelper.GetDataReader(sql);
            ContactModel ContModel = new ContactModel();
            while (reader.Read())
            {
                ContModel.ID = (int)reader["ID"];
                ContModel.E_mail = reader["E_mail"].ToString();
                ContModel.Tel = reader["Tel"].ToString();
                ContModel.QQ = reader["QQ"].ToString();
                ContModel.QQ2 = reader["QQ2"].ToString();
                ContModel.Addr = reader["Addr"].ToString();
                ContModel.Co_Name = reader["Co_Name"].ToString();
                ContModel.icp = reader["icp"].ToString();
                ContModel.keyword = reader["keyword"].ToString();
                ContModel.Description = reader["Description"].ToString();
                ContModel.Co_Url = reader["Co_Url"].ToString();
                ContModel.Post_Code = reader["Post_Code"].ToString();
                
            }
            reader.Close();
            return ContModel; 
        }
    }
}
