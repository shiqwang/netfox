﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPAdminModels;
using System.Data.SqlClient;
using Chess.DAL.DBHelper;

namespace Chess.DAL.QPAdminDAL
{
    public class HotPicService
    {
        public HotPicmodel SetHot(SqlDataReader dr)
        {
            HotPicmodel hotModel = new HotPicmodel();
            hotModel.id=(int)dr["id"];
            hotModel.title = dr["title"].ToString();
            hotModel.url = dr["url"].ToString();
            hotModel.createdate = dr["createdate"].ToString();
            hotModel.img = dr["img"].ToString();
            hotModel.sort = (int)dr["sort"];
            hotModel.status = (byte)dr["status"];
            return hotModel;
        }
        public List<HotPicmodel> GetHotPic()
        {
            string sql = string.Format(@"select * from hotpics where status=1 order by id desc");
            SqlDataReader reader = QPAdminDBHelper.GetDataReader(sql);
            List<HotPicmodel> list = new List<HotPicmodel>();
            while (reader.Read())
            {
                list.Add(SetHot(reader));
            }
            reader.Close();
            return list;
        }
    }
      
}
