﻿using System;
using System.Collections.Generic;
using System.Text;
using Chess.Models.QPAdminModels;
using System.Data.SqlClient;
using Chess.DAL.DBHelper;

namespace Chess.DAL.QPAdminDAL
{
    public class AdInfoService
    {
        public AdInfoModel GetAdInfo()
        {
            string sql = string.Format(@"select * from AdInfo");
            SqlDataReader reader = QpAdminSqlHelper.GetReader(sql);
            AdInfoModel admodel = new AdInfoModel();
            while (reader.Read())
            {
                admodel.Ad1Url = reader["Ad1Url"].ToString();
                admodel.Ad1Link = reader["Ad1Link"].ToString();
                admodel.Ad2Url = reader["Ad2Url"].ToString();
                admodel.Ad2Link = reader["Ad2Link"].ToString();
                admodel.Ad3Url = reader["Ad3Url"].ToString();
                admodel.Ad3Link = reader["Ad3Link"].ToString();
                admodel.Ad4Url = reader["Ad4Url"].ToString();
                admodel.Ad4Link = reader["Ad4Link"].ToString();
                admodel.Ad5Url = reader["Ad5Url"].ToString();
                admodel.Ad5Link = reader["Ad5Link"].ToString();
                admodel.AdRoll = reader["AdRoll"].ToString();
                admodel.AdRollColor = reader["AdRollColor"].ToString();
            }
            reader.Close();
            reader.Dispose();
            return admodel;
        }
    }
}
