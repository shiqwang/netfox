using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class UsertgsModel
    {
        private int _tgid;
        private int _userid;
        private int _gameid;
        private string _account;
        private int _tgscore;
        private int _tgcount;
        /// <summary>
        /// 
        /// </summary>
        public int TgID
        {
            set { _tgid = value; }
            get { return _tgid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int GameID
        {
            set { _gameid = value; }
            get { return _gameid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Account
        {
            set { _account = value; }
            get { return _account; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int TgScore
        {
            set { _tgscore = value; }
            get { return _tgscore; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int TgCount
        {
            set { _tgcount = value; }
            get { return _tgcount; }
        }
    }
}
