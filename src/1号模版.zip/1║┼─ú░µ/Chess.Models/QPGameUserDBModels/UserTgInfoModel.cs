using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class UserTgInfoModel
    {
        private int _tginfoid;
        private int _tgid;
        private int _gameid;
        private string _accounts;
        private int _tguserscore;
        private string _registerip;
        private string _lastlogonip;
        private string _registerdate;
        private string _lastlogondate;
        private int _alllogontimes;
        private int _playtimecount;
        private int _onlinetimecount;
        /// <summary>
        /// 
        /// </summary>
        public int TgInfoID
        {
            set { _tginfoid = value; }
            get { return _tginfoid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int TgID
        {
            set { _tgid = value; }
            get { return _tgid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int GameID
        {
            set { _gameid = value; }
            get { return _gameid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Accounts
        {
            set { _accounts = value; }
            get { return _accounts; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int TgUserScore
        {
            set { _tguserscore = value; }
            get { return _tguserscore; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string RegisterIP
        {
            set { _registerip = value; }
            get { return _registerip; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string LastLogonIP
        {
            set { _lastlogonip = value; }
            get { return _lastlogonip; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string RegisterDate
        {
            set { _registerdate = value; }
            get { return _registerdate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string LastLogonDate
        {
            set { _lastlogondate = value; }
            get { return _lastlogondate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int AllLogonTimes
        {
            set { _alllogontimes = value; }
            get { return _alllogontimes; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int PlayTimeCount
        {
            set { _playtimecount = value; }
            get { return _playtimecount; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int OnLineTimeCount
        {
            set { _onlinetimecount = value; }
            get { return _onlinetimecount; }
        }
    }
}
