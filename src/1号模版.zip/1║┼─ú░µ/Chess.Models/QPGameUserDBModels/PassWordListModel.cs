using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class PassWordListModel
    {
        private int _id;
        private string _userid;
        private string _email;
        private string _passw;
        private string _passd;
        private string _code;
        private string _adder;
        private string _telmail;
        private string _txt;
        private int? _iscut;
        private DateTime? _ssdate;
        private string _password;
        private string _password2;
        /// <summary>
        /// 
        /// </summary>
        public int ID
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Email
        {
            set { _email = value; }
            get { return _email; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Passw
        {
            set { _passw = value; }
            get { return _passw; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Passd
        {
            set { _passd = value; }
            get { return _passd; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Code
        {
            set { _code = value; }
            get { return _code; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Adder
        {
            set { _adder = value; }
            get { return _adder; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string TelMail
        {
            set { _telmail = value; }
            get { return _telmail; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Txt
        {
            set { _txt = value; }
            get { return _txt; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? IsCut
        {
            set { _iscut = value; }
            get { return _iscut; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? SSDate
        {
            set { _ssdate = value; }
            get { return _ssdate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string PassWord
        {
            set { _password = value; }
            get { return _password; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string PassWord2
        {
            set { _password2 = value; }
            get { return _password2; }
        }
    }
}
