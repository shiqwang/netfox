using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class VipidModel
    {
        private int _id;
        private int _gameid;
        private int _userid;
        private int _isstatus;
        private long _score;
        private string _istype;
        /// <summary>
        /// ��ʶ
        /// </summary>
        public int ID
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// ����
        /// </summary>
        public int GameID
        {
            set { _gameid = value; }
            get { return _gameid; }
        }
        /// <summary>
        /// �û�ID
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// ״̬�Ƿ����(0Ϊ������,1Ϊ����)
        /// </summary>
        public int IsStatus
        {
            set { _isstatus = value; }
            get { return _isstatus; }
        }
        /// <summary>
        /// �ú�ֵ��������
        /// </summary>
        public long Score
        {
            set { _score = value; }
            get { return _score; }
        }
        /// <summary>
        /// �����������͵ĺ�
        /// </summary>
        public string IsType
        {
            set { _istype = value; }
            get { return _istype; }
        }
    }
}
