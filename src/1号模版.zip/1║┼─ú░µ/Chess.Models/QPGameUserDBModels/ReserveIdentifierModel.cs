using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class ReserveIdentifierModel
    {
        private int _gameid;
        private int _idlevel;
        private bool _distribute;
        /// <summary>
        /// ��Ϸ��ʶ
        /// </summary>
        public int GameID
        {
            set { _gameid = value; }
            get { return _gameid; }
        }
        /// <summary>
        /// ��ʶ�ȼ�
        /// </summary>
        public int IDLevel
        {
            set { _idlevel = value; }
            get { return _idlevel; }
        }
        /// <summary>
        /// �����־
        /// </summary>
        public bool Distribute
        {
            set { _distribute = value; }
            get { return _distribute; }
        }
    }
}
