using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class Cls_LogModel
    {
        private int _id;
        private int? _userid;
        private string _game;
        private DateTime? _clsdate;
        private int? _score;
        /// <summary>
        /// 
        /// </summary>
        public int id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Game
        {
            set { _game = value; }
            get { return _game; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? ClsDate
        {
            set { _clsdate = value; }
            get { return _clsdate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? Score
        {
            set { _score = value; }
            get { return _score; }
        }
    }
}
