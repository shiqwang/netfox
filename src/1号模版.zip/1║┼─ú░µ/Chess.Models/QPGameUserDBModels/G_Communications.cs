﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class G_CommunicationsModel
    {
        private int _id;
        private string _g_qq;
        private string _g_mobile;
        private int _g_userid;

        public int ID
        {
            get { return this._id; }
            set { this._id = value; }
        }
        public string G_QQ
        {
            get { return this._g_qq; }
            set { this._g_qq = value; }
        }
        public string G_Mobile
        {
            get { return this._g_mobile; }
            set { this._g_mobile = value; }
        }
        public int G_UserID
        {
            get { return this._g_userid; }
            set { this._g_userid = value; }
        }
    }
}
