using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class CustomFaceInfoModel
    {
        private int _userid;
        private byte[] _customfaceimage;
        /// <summary>
        /// �û���ʶ
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// �Զ���ͷ��
        /// </summary>
        public byte[] CustomFaceImage
        {
            set { _customfaceimage = value; }
            get { return _customfaceimage; }
        }
    }
}
