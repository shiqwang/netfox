using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class MemberInfoModel
    {
        private int _userid;
        private int _memberorder;
        private string _memberoverdate;
        /// <summary>
        /// �û���ʶ
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// ��Ա��ʶ
        /// </summary>
        public int MemberOrder
        {
            set { _memberorder = value; }
            get { return _memberorder; }
        }
        /// <summary>
        /// ��Ա����
        /// </summary>
        public string MemberOverDate
        {
            set { _memberoverdate = value; }
            get { return _memberoverdate; }
        }
    }
}
