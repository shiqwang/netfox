using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class GameIdentifierModel
    {
        private int _userid;
        private int _gameid;
        private int _idlevel;
        /// <summary>
        /// �û���ʶ
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// ��Ϸ��ʶ
        /// </summary>
        public int GameID
        {
            set { _gameid = value; }
            get { return _gameid; }
        }
        /// <summary>
        /// ��ʶ�ȼ�
        /// </summary>
        public int IDLevel
        {
            set { _idlevel = value; }
            get { return _idlevel; }
        }
    }
}
