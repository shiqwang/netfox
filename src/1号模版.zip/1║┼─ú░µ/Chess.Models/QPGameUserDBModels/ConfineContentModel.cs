using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class ConfineContentModel
    {
        private string _string;
        private DateTime _collectdate;
        /// <summary>
        /// �����ַ�
        /// </summary>
        public string String
        {
            set { _string = value; }
            get { return _string; }
        }
        /// <summary>
        /// ¼������
        /// </summary>
        public DateTime CollectDate
        {
            set { _collectdate = value; }
            get { return _collectdate; }
        }
    }
}
