using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class TGOnlineTimesModel
    {
        private int _id;

        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }
        private int _userid;

        public int UserID
        {
            get { return _userid; }
            set { _userid = value; }
        }
        private int _gameid;

        public int GameID
        {
            get { return _gameid; }
            set { _gameid = value; }
        }
        private string _account;

        public string Account
        {
            get { return _account; }
            set { _account = value; }
        }
        private int _useonlinetime;

        public int UseOnlineTime
        {
            get { return _useonlinetime; }
            set { _useonlinetime = value; }
        }
        private int _count;

        public int Count
        {
            get { return _count; }
            set { _count = value; }
        }
        private long _score;

        public long Score
        {
            get { return _score; }
            set { _score = value; }
        }
    }
}
