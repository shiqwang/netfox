using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class UserDuihuanModel
    {
        private int _userid;

        public int UserID
        {
            get { return _userid; }
            set { _userid = value; }
        }
        private int _gameid;

        public int GameID
        {
            get { return _gameid; }
            set { _gameid = value; }
        }
        private string _account;

        public string Account
        {
            get { return _account; }
            set { _account = value; }
        }
        private string _regaccounts;

        public string RegAccounts
        {
            get { return _regaccounts; }
            set { _regaccounts = value; }
        }
        private int _lastusetime;

        public int LastUseTime
        {
            get { return _lastusetime; }
            set { _lastusetime = value; }
        }
        private long _lastscore;

        public long LastScore
        {
            get { return _lastscore; }
            set { _lastscore = value; }
        }
        private int _usetime;

        public int UseTime
        {
            get { return _usetime; }
            set { _usetime = value; }
        }
        private long _score;

        public long Score
        {
            get { return _score; }
            set { _score = value; }
        }
    }
}
