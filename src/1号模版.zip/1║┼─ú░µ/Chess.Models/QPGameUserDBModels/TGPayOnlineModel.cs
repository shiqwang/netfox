using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class TGPayOnlineModel
    {
        private int _id;

        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }
        private int _userid;

        public int UserID
        {
            get { return _userid; }
            set { _userid = value; }
        }
        private int _gameid;

        public int GameID
        {
            get { return _gameid; }
            set { _gameid = value; }
        }
        private string _account;

        public string Account
        {
            get { return _account; }
            set { _account = value; }
        }
        private long  _usepayscore;

        public long  UsePayScore
        {
            get { return _usepayscore; }
            set { _usepayscore = value; }
        }
        private long _score;

        public long Score
        {
            get { return _score; }
            set { _score = value; }
        }            
    }
}
