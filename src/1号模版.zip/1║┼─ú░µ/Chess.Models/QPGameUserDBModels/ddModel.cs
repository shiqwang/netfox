using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class ddModel
    {
        private int _id;

        public int id
        {
            get { return _id; }
            set { _id = value; }
        }
        private string _number;

        public string number
        {
            get { return _number; }
            set { _number = value; }
        }
        private string _rmb;

        public string rmb
        {
            get { return _rmb; }
            set { _rmb = value; }
        }
        private string _rq;

        public string rq
        {
            get { return _rq; }
            set { _rq = value; }
        }
        private string _username;

        public string username
        {
            get { return _username; }
            set { _username = value; }
        }
        private long _yxb;

        public long yxb
        {
            get { return _yxb; }
            set { _yxb = value; }
        }
    }
}
