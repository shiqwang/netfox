using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    [Serializable]
    public class AccountsInfoModel
    {
        private int _userid;
        private int _gameid;
        private int _protectid;
        private string _accounts;
        private string _regaccounts;
        private string _underwrite;
        private string _logonpass;
        private string _insurepass;
        private string _QQ;
        private string _Phone;
        private string _spreaderid;
        private int _faceid;
        private int _experience;
        private int _userright;
        private int _masterright;
        private int _serviceright;
        private int _masterorder;
        private int _memberorder;
        private string _memberoverdate;
        private int _loveliness;
        private int _gender;
        private bool _nullity;
        private bool _stundown;
        private int _moormachine;
        private string _machineserial;
        private int _weblogontimes;
        private int _gamelogontimes;
        private string _registerip;
        private string _lastlogonip;
        private string _registerdate;
        private string _lastlogondate;
        private int? _customfacever;
        private string _c_idno;
        private string _c_address;
        private string _c_email;
        private string _c_protectques;
        private string _c_protectansw;
        private string _c_boxpassword;
        private string _olepassword;
        private bool _ischeckpassword;
        private bool _isboxpassword;
        private string _passwordcode;
        private string _loginkick;
        private string _usercode;
        private int _del;
        private int _yy;
        private string _logindatetime;
        private int? _yycar;
        /// <summary>
        /// �û���ʶ
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// ��Ϸ��ʶ
        /// </summary>
        public int GameID
        {
            set { _gameid = value; }
            get { return _gameid; }
        }
        /// <summary>
        /// �ܱ���ʶ
        /// </summary>
        public int ProtectID
        {
            set { _protectid = value; }
            get { return _protectid; }
        }
        /// <summary>
        /// �û��ʺ�
        /// </summary>
        public string Accounts
        {
            set { _accounts = value; }
            get { return _accounts; }
        }
        /// <summary>
        /// ע���ʺ�
        /// </summary>
        public string RegAccounts
        {
            set { _regaccounts = value; }
            get { return _regaccounts; }
        }
        /// <summary>
        /// ����ǩ��
        /// </summary>
        public string UnderWrite
        {
            set { _underwrite = value; }
            get { return _underwrite; }
        }
        /// <summary>
        /// ��¼����
        /// </summary>
        public string LogonPass
        {
            set { _logonpass = value; }
            get { return _logonpass; }
        }
        /// <summary>
        /// ��ȫ����
        /// </summary>
        public string InsurePass
        {
            set { _insurepass = value; }
            get { return _insurepass; }
        }
        /// <summary>
        /// QQ
        /// </summary>
        public string QQ
        {
            set { _QQ = value; }
            get { return _QQ; }
        }
        /// <summary>
        /// �绰
        /// </summary>
        public string Phone
        {
            get { return _Phone; }
            set { _Phone = value; }
        }
        /// <summary>
        /// �Ƽ��˱�ʶ
        /// </summary>
        public string SpreaderID
        {
            set { _spreaderid = value; }
            get { return _spreaderid; }
        }
        /// <summary>
        /// ͷ���ʶ
        /// </summary>
        public int FaceID
        {
            set { _faceid = value; }
            get { return _faceid; }
        }
        /// <summary>
        /// ������ֵ
        /// </summary>
        public int Experience
        {
            set { _experience = value; }
            get { return _experience; }
        }
        /// <summary>
        /// �û�Ȩ��
        /// </summary>
        public int UserRight
        {
            set { _userright = value; }
            get { return _userright; }
        }
        /// <summary>
        /// ����Ȩ��
        /// </summary>
        public int MasterRight
        {
            set { _masterright = value; }
            get { return _masterright; }
        }
        /// <summary>
        /// ����Ȩ��
        /// </summary>
        public int ServiceRight
        {
            set { _serviceright = value; }
            get { return _serviceright; }
        }
        /// <summary>
        /// �����ȼ�
        /// </summary>
        public int MasterOrder
        {
            set { _masterorder = value; }
            get { return _masterorder; }
        }
        /// <summary>
        /// ��Ա�ȼ�
        /// </summary>
        public int MemberOrder
        {
            set { _memberorder = value; }
            get { return _memberorder; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string MemberOverDate
        {
            set { _memberoverdate = value; }
            get { return _memberoverdate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int Loveliness
        {
            set { _loveliness = value; }
            get { return _loveliness; }
        }
        /// <summary>
        /// �û��Ա�
        /// </summary>
        public int Gender
        {
            set { _gender = value; }
            get { return _gender; }
        }
        /// <summary>
        /// ��ֹ����
        /// </summary>
        public bool Nullity
        {
            set { _nullity = value; }
            get { return _nullity; }
        }
        /// <summary>
        /// �رձ�־
        /// </summary>
        public bool StunDown
        {
            set { _stundown = value; }
            get { return _stundown; }
        }
        /// <summary>
        /// �̶�����
        /// </summary>
        public int MoorMachine
        {
            set { _moormachine = value; }
            get { return _moormachine; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string MachineSerial
        {
            set { _machineserial = value; }
            get { return _machineserial; }
        }
        /// <summary>
        /// ��¼����
        /// </summary>
        public int WebLogonTimes
        {
            set { _weblogontimes = value; }
            get { return _weblogontimes; }
        }
        /// <summary>
        /// ��¼����
        /// </summary>
        public int GameLogonTimes
        {
            set { _gamelogontimes = value; }
            get { return _gamelogontimes; }
        }
        /// <summary>
        /// ע���ַ
        /// </summary>
        public string RegisterIP
        {
            set { _registerip = value; }
            get { return _registerip; }
        }
        /// <summary>
        /// ��¼��ַ
        /// </summary>
        public string LastLogonIP
        {
            set { _lastlogonip = value; }
            get { return _lastlogonip; }
        }
        /// <summary>
        /// ע��ʱ��
        /// </summary>
        public string RegisterDate
        {
            set { _registerdate = value; }
            get { return _registerdate; }
        }
        /// <summary>
        /// ��¼ʱ��
        /// </summary>
        public string LastLogonDate
        {
            set { _lastlogondate = value; }
            get { return _lastlogondate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? CustomFaceVer
        {
            set { _customfacever = value; }
            get { return _customfacever; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_IDNO
        {
            set { _c_idno = value; }
            get { return _c_idno; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_ADDRESS
        {
            set { _c_address = value; }
            get { return _c_address; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_EMAIL
        {
            set { _c_email = value; }
            get { return _c_email; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_PROTECTQUES
        {
            set { _c_protectques = value; }
            get { return _c_protectques; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_PROTECTANSW
        {
            set { _c_protectansw = value; }
            get { return _c_protectansw; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_BOXPASSWORD
        {
            set { _c_boxpassword = value; }
            get { return _c_boxpassword; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string OlePassWord
        {
            set { _olepassword = value; }
            get { return _olepassword; }
        }
        /// <summary>
        /// 
        /// </summary>
        public bool IsCheckPassWord
        {
            set { _ischeckpassword = value; }
            get { return _ischeckpassword; }
        }
        /// <summary>
        /// 
        /// </summary>
        public bool IsBoxPassWord
        {
            set { _isboxpassword = value; }
            get { return _isboxpassword; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string PassWordCode
        {
            set { _passwordcode = value; }
            get { return _passwordcode; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string LoginKick
        {
            set { _loginkick = value; }
            get { return _loginkick; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string UserCode
        {
            set { _usercode = value; }
            get { return _usercode; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int Del
        {
            set { _del = value; }
            get { return _del; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int yy
        {
            set { _yy = value; }
            get { return _yy; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string LoginDateTime
        {
            set { _logindatetime = value; }
            get { return _logindatetime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? YYCar
        {
            set { _yycar = value; }
            get { return _yycar; }
        }

    }
}
