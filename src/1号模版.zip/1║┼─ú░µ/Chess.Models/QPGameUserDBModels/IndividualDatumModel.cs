using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class IndividualDatumModel
    {
        private int _userid;
        private string _compellation;
        private string _qq;
        private string _email;
        private string _seatphone;
        private string _mobilephone;
        private string _dwellingplace;
        private string _postalcode;
        private DateTime _collectdate;
        private string _usernote;
        /// <summary>
        /// �û���ʶ
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// ��ʵ����
        /// </summary>
        public string Compellation
        {
            set { _compellation = value; }
            get { return _compellation; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string QQ
        {
            set { _qq = value; }
            get { return _qq; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string EMail
        {
            set { _email = value; }
            get { return _email; }
        }
        /// <summary>
        /// �̶��绰
        /// </summary>
        public string SeatPhone
        {
            set { _seatphone = value; }
            get { return _seatphone; }
        }
        /// <summary>
        /// �ֻ�����
        /// </summary>
        public string MobilePhone
        {
            set { _mobilephone = value; }
            get { return _mobilephone; }
        }
        /// <summary>
        /// ��ϸסַ
        /// </summary>
        public string DwellingPlace
        {
            set { _dwellingplace = value; }
            get { return _dwellingplace; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string PostalCode
        {
            set { _postalcode = value; }
            get { return _postalcode; }
        }
        /// <summary>
        /// �ռ�����
        /// </summary>
        public DateTime CollectDate
        {
            set { _collectdate = value; }
            get { return _collectdate; }
        }
        /// <summary>
        /// �û���ע
        /// </summary>
        public string UserNote
        {
            set { _usernote = value; }
            get { return _usernote; }
        }
    }
}
