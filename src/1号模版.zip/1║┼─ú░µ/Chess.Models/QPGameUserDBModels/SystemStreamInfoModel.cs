using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameUserDBModels
{
    public class SystemStreamInfoModel
    {
        private int _dateid;
        private int _weblogonsuccess;
        private int _webregistersuccess;
        private int _gamelogonsuccess;
        private int _gameregistersuccess;
        private DateTime _collectdate;
        /// <summary>
        /// ���ڱ�ʶ
        /// </summary>
        public int DateID
        {
            set { _dateid = value; }
            get { return _dateid; }
        }
        /// <summary>
        /// ��¼�ɹ�
        /// </summary>
        public int WebLogonSuccess
        {
            set { _weblogonsuccess = value; }
            get { return _weblogonsuccess; }
        }
        /// <summary>
        /// ע��ɹ�
        /// </summary>
        public int WebRegisterSuccess
        {
            set { _webregistersuccess = value; }
            get { return _webregistersuccess; }
        }
        /// <summary>
        /// ��¼�ɹ�
        /// </summary>
        public int GameLogonSuccess
        {
            set { _gamelogonsuccess = value; }
            get { return _gamelogonsuccess; }
        }
        /// <summary>
        /// ע��ɹ�
        /// </summary>
        public int GameRegisterSuccess
        {
            set { _gameregistersuccess = value; }
            get { return _gameregistersuccess; }
        }
        /// <summary>
        /// ¼��ʱ��
        /// </summary>
        public DateTime CollectDate
        {
            set { _collectdate = value; }
            get { return _collectdate; }
        }
    }
}
