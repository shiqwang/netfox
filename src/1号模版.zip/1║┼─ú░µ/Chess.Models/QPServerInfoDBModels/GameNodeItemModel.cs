using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPServerInfoDBModels
{
    public class GameNodeItemModel
    {
        private int _nodeid;
        private int _kindid;
        private int _joinid;
        private int _sortid;
        private string _nodename;
        private bool _nullity;
        /// <summary>
        /// �ڵ��ʶ
        /// </summary>
        public int NodeID
        {
            set { _nodeid = value; }
            get { return _nodeid; }
        }
        /// <summary>
        /// ���ͱ�ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// �ҽӱ�ʶ
        /// </summary>
        public int JoinID
        {
            set { _joinid = value; }
            get { return _joinid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int SortID
        {
            set { _sortid = value; }
            get { return _sortid; }
        }
        /// <summary>
        /// վ������
        /// </summary>
        public string NodeName
        {
            set { _nodename = value; }
            get { return _nodename; }
        }
        /// <summary>
        /// ��Ч��־
        /// </summary>
        public bool Nullity
        {
            set { _nullity = value; }
            get { return _nullity; }
        }
    }
}
