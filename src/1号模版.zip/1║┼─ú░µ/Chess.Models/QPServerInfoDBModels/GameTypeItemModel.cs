using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPServerInfoDBModels
{
    public class GameTypeItemModel
    {
        private int _typeid;
        private int _joinid;
        private int _sortid;
        private string _typename;
        private bool _nullity;
        /// <summary>
        /// ���ͱ�ʶ
        /// </summary>
        public int TypeID
        {
            set { _typeid = value; }
            get { return _typeid; }
        }
        /// <summary>
        /// �ҽӱ�ʶ
        /// </summary>
        public int JoinID
        {
            set { _joinid = value; }
            get { return _joinid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int SortID
        {
            set { _sortid = value; }
            get { return _sortid; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string TypeName
        {
            set { _typename = value; }
            get { return _typename; }
        }
        /// <summary>
        /// ��Ч��־
        /// </summary>
        public bool Nullity
        {
            set { _nullity = value; }
            get { return _nullity; }
        }
    }
}
