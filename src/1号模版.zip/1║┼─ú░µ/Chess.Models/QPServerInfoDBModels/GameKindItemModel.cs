using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPServerInfoDBModels
{
    public class GameKindItemModel
    {
        private int _kindid;
        private int _typeid;
        private int _joinid;
        private int _sortid;
        private string _kindname;
        private string _processname;
        private int _maxversion;
        private string _databasename;
        private bool _nullity;
        private string _gzurl;
        /// <summary>
        /// ���ͱ�ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int TypeID
        {
            set { _typeid = value; }
            get { return _typeid; }
        }
        /// <summary>
        /// �ҽӱ�ʶ
        /// </summary>
        public int JoinID
        {
            set { _joinid = value; }
            get { return _joinid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int SortID
        {
            set { _sortid = value; }
            get { return _sortid; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string KindName
        {
            set { _kindname = value; }
            get { return _kindname; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string ProcessName
        {
            set { _processname = value; }
            get { return _processname; }
        }
        /// <summary>
        /// �汾����
        /// </summary>
        public int MaxVersion
        {
            set { _maxversion = value; }
            get { return _maxversion; }
        }
        /// <summary>
        /// ���ݿ�����
        /// </summary>
        public string DataBaseName
        {
            set { _databasename = value; }
            get { return _databasename; }
        }
        /// <summary>
        /// ��Ч��־
        /// </summary>
        public bool Nullity
        {
            set { _nullity = value; }
            get { return _nullity; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string GzUrl
        {
            set { _gzurl = value; }
            get { return _gzurl; }
        }
    }
}
