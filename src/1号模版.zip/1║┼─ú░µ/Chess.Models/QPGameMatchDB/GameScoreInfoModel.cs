using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPGameMatchDB
{
    public class GameScoreInfoModel
    {
        private int userid;

        public int UserID
        {
            get { return userid; }
            set { userid = value; }
        }
        private int score;

        public int Score
        {
            get { return score; }
            set { score = value; }
        }
        private int wincount;

        public int WinCount
        {
            get { return wincount; }
            set { wincount = value; }
        }
        private int lostcount;

        public int LostCount
        {
            get { return lostcount; }
            set { lostcount = value; }
        }
        private int drawcount;

        public int DrawCount
        {
            get { return drawcount; }
            set { drawcount = value; }
        }
        private int fleecount;

        public int FleeCount
        {
            get { return fleecount; }
            set { fleecount = value; }
        }
        private int userright;

        public int UserRight
        {
            get { return userright; }
            set { userright = value; }
        }
        private int masterright;

        public int MasterRight
        {
            get { return masterright; }
            set { masterright = value; }
        }
        private int masterorder;

        public int MasterOrder
        {
            get { return masterorder; }
            set { masterorder = value; }
        }
        private string registerip;

        public string RegisterIP
        {
            get { return registerip; }
            set { registerip = value; }
        }
        private string lastlogonip;

        public string LastLogonIP
        {
            get { return lastlogonip; }
            set { lastlogonip = value; }
        }
        private string registerdate;

        public string RegisterDate
        {
            get { return registerdate; }
            set { registerdate = value; }
        }
        private string lastlogondate;

        public string LastLogonDate
        {
            get { return lastlogondate; }
            set { lastlogondate = value; }
        }
        private int alllogontimes;

        public int AllLogonTimes
        {
            get { return alllogontimes; }
            set { alllogontimes = value; }
        }
        private int playtimecount;

        public int PlayTimeCount
        {
            get { return playtimecount; }
            set { playtimecount = value; }
        }
        private int onlinetimecount;

        public int OnLineTimeCount
        {
            get { return onlinetimecount; }
            set { onlinetimecount = value; }
        }

    }
}
