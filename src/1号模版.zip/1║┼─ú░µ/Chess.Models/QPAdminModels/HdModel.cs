﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPAdminModels
{
    public class HdModel
    {
        public int id { get; set; }
        public string tit { get; set; }
        public string zz { get; set; }
        public string sj { get; set; }
        public string nr { get; set; }
        public int? dj { get; set; }
        public int? typeid { get; set; }
        public string smallimg { get; set; }
        public int? rt { get; set; }
        public int? px { get; set; }
        public string typename { get; set; }
        public string Arret_Color { get; set; }
        public int? Arret_Top { get; set; }
    }
}
