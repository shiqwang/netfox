﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPAdminModels
{
    public class AdInfoModel
    {
        public string Ad1Url { get; set; }
        public string Ad1Link { get; set; }
        public string Ad2Url { get; set; }
        public string Ad2Link { get; set; }
        public string Ad3Url { get; set; }
        public string Ad3Link { get; set; }
        public string Ad4Url { get; set; }
        public string Ad4Link { get; set; }
        public string Ad5Url { get; set; }
        public string Ad5Link { get; set; }
        public string AdRoll { get; set; }
        public string AdRollColor { get; set; }
    }
}
