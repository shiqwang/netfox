﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPAdminModels
{
    public class TypeModel
    {
        private int id { get; set; }
        private string lm { get; set; }
        private int? px { get; set; }
    }
}
