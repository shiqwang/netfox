﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPAdminModels
{
    public class HotPicmodel
    {
        public int id { get;set;}
        public string title { get; set; }
        public string url { get; set; }
        public string createdate { get; set; }
        public string img { get; set; }
        public int sort { get; set; }
        public byte status { get; set; }
    }
}
