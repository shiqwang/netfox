﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPAdminModels
{
   public class ContactModel
    {
       public int ID { get; set; }
       public string E_mail { get; set; }
       public string Tel { get; set; }
       public string QQ { get; set; }
       public string QQ2 { get; set; }
       public string Addr { get; set; }
       public string Co_Name { get; set; }
       public string icp { get; set; }
       public string keyword { get; set; }
       public string Description { get; set; }
       public string Co_Url { get; set; }
       public string Post_Code { get; set; }
    }
}
