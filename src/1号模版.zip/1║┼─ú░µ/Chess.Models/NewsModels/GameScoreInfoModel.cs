using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class GameScoreInfoModel
    {
        private int _g_id;
        private int? _userid;
        private long _score;
        private int? _wincount;
        private int? _lostcount;
        private int? _drawcount;
        private int? _fleecount;
        private int? _userright;
        private int? _masterright;
        private int? _masterorder;
        private string _registerip;
        private string _lastlogonip;
        private DateTime? _registerdate;
        private DateTime? _lastlogondate;
        private int? _alllogontimes;
        private int? _playtimecount;
        private int? _onlinetimecount;
        private int? _c_id;
        /// <summary>
        /// 
        /// </summary>
        public int G_id
        {
            set { _g_id = value; }
            get { return _g_id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public long Score
        {
            set { _score = value; }
            get { return _score; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? WinCount
        {
            set { _wincount = value; }
            get { return _wincount; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? LostCount
        {
            set { _lostcount = value; }
            get { return _lostcount; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? DrawCount
        {
            set { _drawcount = value; }
            get { return _drawcount; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? FleeCount
        {
            set { _fleecount = value; }
            get { return _fleecount; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? UserRight
        {
            set { _userright = value; }
            get { return _userright; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? MasterRight
        {
            set { _masterright = value; }
            get { return _masterright; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? MasterOrder
        {
            set { _masterorder = value; }
            get { return _masterorder; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string RegisterIP
        {
            set { _registerip = value; }
            get { return _registerip; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string LastLogonIP
        {
            set { _lastlogonip = value; }
            get { return _lastlogonip; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? RegisterDate
        {
            set { _registerdate = value; }
            get { return _registerdate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? LastLogonDate
        {
            set { _lastlogondate = value; }
            get { return _lastlogondate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? AllLogonTimes
        {
            set { _alllogontimes = value; }
            get { return _alllogontimes; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? PlayTimeCount
        {
            set { _playtimecount = value; }
            get { return _playtimecount; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? OnLineTimeCount
        {
            set { _onlinetimecount = value; }
            get { return _onlinetimecount; }
        }
        /// <summary>
        /// ���¹���ID
        /// </summary>
        public int? C_id
        {
            set { _c_id = value; }
            get { return _c_id; }
        }
    }
}
