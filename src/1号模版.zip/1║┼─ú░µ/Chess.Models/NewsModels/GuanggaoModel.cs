using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class GuanggaoModel
    {
        private int _g_id;
        private string _g_pic;
        private string _g_http;
        private DateTime? _g_time;
        private string _g_other;
        private string _g_type;
        /// <summary>
        /// 
        /// </summary>
        public int G_id
        {
            set { _g_id = value; }
            get { return _g_id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string G_pic
        {
            set { _g_pic = value; }
            get { return _g_pic; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string G_http
        {
            set { _g_http = value; }
            get { return _g_http; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? G_time
        {
            set { _g_time = value; }
            get { return _g_time; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string G_other
        {
            set { _g_other = value; }
            get { return _g_other; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string G_type
        {
            set { _g_type = value; }
            get { return _g_type; }
        }
    }
}
