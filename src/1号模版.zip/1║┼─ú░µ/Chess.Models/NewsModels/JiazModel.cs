using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class JiazModel
    {
        private int _j_id;
        private int? _t_id;
        private int? _u_id;
        private int? _t_type;
        /// <summary>
        /// 
        /// </summary>
        public int J_id
        {
            set { _j_id = value; }
            get { return _j_id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? T_id
        {
            set { _t_id = value; }
            get { return _t_id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? U_id
        {
            set { _u_id = value; }
            get { return _u_id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? T_type
        {
            set { _t_type = value; }
            get { return _t_type; }
        }
    }
}
