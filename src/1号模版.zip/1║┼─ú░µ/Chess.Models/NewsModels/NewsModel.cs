using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class NewsModel
    {
        private int _id;
        private string _classcode;
        private string _newstitle;
        private DateTime? _newsdate;
        private string _newsinfo;
        private string _newscu;
        private string _newszz;
        private bool _pl;
        private int? _counts;
        private string _keyword;
        private bool _gd;
        private DateTime? _ts;
        private string _down;
        private bool _top2;
        /// <summary>
        /// 
        /// </summary>
        public int id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string classcode
        {
            set { _classcode = value; }
            get { return _classcode; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string newstitle
        {
            set { _newstitle = value; }
            get { return _newstitle; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? newsdate
        {
            set { _newsdate = value; }
            get { return _newsdate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string newsinfo
        {
            set { _newsinfo = value; }
            get { return _newsinfo; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string newscu
        {
            set { _newscu = value; }
            get { return _newscu; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string newszz
        {
            set { _newszz = value; }
            get { return _newszz; }
        }
        /// <summary>
        /// 
        /// </summary>
        public bool pl
        {
            set { _pl = value; }
            get { return _pl; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? counts
        {
            set { _counts = value; }
            get { return _counts; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string keyword
        {
            set { _keyword = value; }
            get { return _keyword; }
        }
        /// <summary>
        /// 
        /// </summary>
        public bool gd
        {
            set { _gd = value; }
            get { return _gd; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? ts
        {
            set { _ts = value; }
            get { return _ts; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string down
        {
            set { _down = value; }
            get { return _down; }
        }
        /// <summary>
        /// 
        /// </summary>
        public bool top2
        {
            set { _top2 = value; }
            get { return _top2; }
        }
    }
}
