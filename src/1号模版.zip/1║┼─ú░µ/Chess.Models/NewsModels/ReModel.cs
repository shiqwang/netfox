using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class ReModel
    {
        private int _id;
        private string _username;
        private string _atxt;
        private string _btxt;
        private int? _act;
        private DateTime? _postdate;
        /// <summary>
        /// 
        /// </summary>
        public int ID
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string UserName
        {
            set { _username = value; }
            get { return _username; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ATxt
        {
            set { _atxt = value; }
            get { return _atxt; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string BTxt
        {
            set { _btxt = value; }
            get { return _btxt; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? Act
        {
            set { _act = value; }
            get { return _act; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? PostDate
        {
            set { _postdate = value; }
            get { return _postdate; }
        }
    }
}
