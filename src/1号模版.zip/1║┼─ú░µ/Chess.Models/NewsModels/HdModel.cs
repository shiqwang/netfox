using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class HdModel
    {
        private int _id;
        private string _tit;
        private string _zz;
        private string _sj;
        private string _nr;
        private int? _dj;
        private int? _typeid;
        private string _smallimg;
        private int _rt;
        private int? _px;
        private string _typename;
        

        /// <summary>
        /// 
        /// </summary>
        public int id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string tit
        {
            set { _tit = value; }
            get { return _tit; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string zz
        {
            set { _zz = value; }
            get { return _zz; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string sj
        {
            set { _sj = value; }
            get { return _sj; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string nr
        {
            set { _nr = value; }
            get { return _nr; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? dj
        {
            set { _dj = value; }
            get { return _dj; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? typeid
        {
            set { _typeid = value; }
            get { return _typeid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string smallimg
        {
            set { _smallimg = value; }
            get { return _smallimg; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int rt
        {
            set { _rt = value; }
            get { return _rt; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? px
        {
            set { _px = value; }
            get { return _px; }
        }

        public string typename
        {
            get { return _typename; }
            set { _typename = value; }
        }
       
    }
}
