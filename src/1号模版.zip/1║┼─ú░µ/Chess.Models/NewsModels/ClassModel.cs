using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class ClassModel
    {
        private int _id;
        private string _classcode;
        private string _classname;
        private string _classpic;
        /// <summary>
        /// 
        /// </summary>
        public int id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string classcode
        {
            set { _classcode = value; }
            get { return _classcode; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string classname
        {
            set { _classname = value; }
            get { return _classname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string classpic
        {
            set { _classpic = value; }
            get { return _classpic; }
        }
    }
}
