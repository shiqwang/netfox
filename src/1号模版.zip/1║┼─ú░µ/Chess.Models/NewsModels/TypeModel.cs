using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class TypeModel
    {
        private int _id;
        private string _lm;
        private int? _px;
        /// <summary>
        /// 
        /// </summary>
        public int id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string lm
        {
            set { _lm = value; }
            get { return _lm; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? px
        {
            set { _px = value; }
            get { return _px; }
        }
    }
}
