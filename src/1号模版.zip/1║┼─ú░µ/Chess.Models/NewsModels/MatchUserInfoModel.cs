using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class MatchUserInfoModel
    {
        private int _userid;
        private int? _kindid;
        private int? _serverid;
        private string _username;
        private string _idcard;
        private int? _age;
        private string _profession;
        private string _phoneno;
        private string _address;
        private DateTime? _collectdate;
        private string _clientip;
        private int? _c_id;
        private string _u_name;
        /// <summary>
        /// 
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// �û���ʵ����
        /// </summary>
        public string Username
        {
            set { _username = value; }
            get { return _username; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string IDCard
        {
            set { _idcard = value; }
            get { return _idcard; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? Age
        {
            set { _age = value; }
            get { return _age; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Profession
        {
            set { _profession = value; }
            get { return _profession; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string PhoneNo
        {
            set { _phoneno = value; }
            get { return _phoneno; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Address
        {
            set { _address = value; }
            get { return _address; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? CollectDate
        {
            set { _collectdate = value; }
            get { return _collectdate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ClientIP
        {
            set { _clientip = value; }
            get { return _clientip; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? C_id
        {
            set { _c_id = value; }
            get { return _c_id; }
        }
        /// <summary>
        /// ��Ϸ�û���
        /// </summary>
        public string U_name
        {
            set { _u_name = value; }
            get { return _u_name; }
        }
    }
}
