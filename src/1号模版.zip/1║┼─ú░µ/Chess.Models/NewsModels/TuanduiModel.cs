using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class TuanduiModel
    {
        private int _t_id;
        private string _u_name;
        private string _t_name;
        private int? _t_qq;
        private string _t_url;
        private int? _qq;
        private string _e_mail;
        private string _t_tel;
        private string _address;
        private int? _t_type;
        private DateTime? _t_date;
        private int? _t_num;
        private string _t_luntan;
        private string _t_zongzhi;
        private string _t_content;
        /// <summary>
        /// 
        /// </summary>
        public int T_id
        {
            set { _t_id = value; }
            get { return _t_id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string U_name
        {
            set { _u_name = value; }
            get { return _u_name; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string T_name
        {
            set { _t_name = value; }
            get { return _t_name; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? T_qq
        {
            set { _t_qq = value; }
            get { return _t_qq; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string T_url
        {
            set { _t_url = value; }
            get { return _t_url; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? QQ
        {
            set { _qq = value; }
            get { return _qq; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string E_mail
        {
            set { _e_mail = value; }
            get { return _e_mail; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string T_tel
        {
            set { _t_tel = value; }
            get { return _t_tel; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Address
        {
            set { _address = value; }
            get { return _address; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? T_type
        {
            set { _t_type = value; }
            get { return _t_type; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? T_date
        {
            set { _t_date = value; }
            get { return _t_date; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? T_num
        {
            set { _t_num = value; }
            get { return _t_num; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string T_luntan
        {
            set { _t_luntan = value; }
            get { return _t_luntan; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string T_zongzhi
        {
            set { _t_zongzhi = value; }
            get { return _t_zongzhi; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string T_content
        {
            set { _t_content = value; }
            get { return _t_content; }
        }
    }
}
