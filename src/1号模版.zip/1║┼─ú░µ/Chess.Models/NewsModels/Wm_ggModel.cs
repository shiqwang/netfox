using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class Wm_ggModel
    {
        private int _t_id;
        private string _tupian1;
        private string _tupian2;
        private string _tupian3;
        private string _tupian4;
        private string _tupian5;
        private string _tupian6;
        /// <summary>
        /// 
        /// </summary>
        public int t_id
        {
            set { _t_id = value; }
            get { return _t_id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string tupian1
        {
            set { _tupian1 = value; }
            get { return _tupian1; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string tupian2
        {
            set { _tupian2 = value; }
            get { return _tupian2; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string tupian3
        {
            set { _tupian3 = value; }
            get { return _tupian3; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string tupian4
        {
            set { _tupian4 = value; }
            get { return _tupian4; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string tupian5
        {
            set { _tupian5 = value; }
            get { return _tupian5; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string tupian6
        {
            set { _tupian6 = value; }
            get { return _tupian6; }
        }
    }
}
