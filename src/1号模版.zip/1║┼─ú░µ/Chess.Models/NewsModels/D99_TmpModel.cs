using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class D99_TmpModel
    {
        private string _subdirectory;
        private string _depth;
        private string _file;
        /// <summary>
        /// 
        /// </summary>
        public string subdirectory
        {
            set { _subdirectory = value; }
            get { return _subdirectory; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string depth
        {
            set { _depth = value; }
            get { return _depth; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string file
        {
            set { _file = value; }
            get { return _file; }
        }
    }
}
