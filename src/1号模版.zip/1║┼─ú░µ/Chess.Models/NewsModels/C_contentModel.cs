using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class C_contentModel
    {
        private int _c_id;
        private string _c_title;
        private string _c_content;
        private DateTime? _c_time;
        private int? _c_date;
        private int? _c_over;
        private int _c_star;
        private int _c_sai;
        private string _paihang;
        private string _j_content;
        /// <summary>
        /// 
        /// </summary>
        public int C_id
        {
            set { _c_id = value; }
            get { return _c_id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_title
        {
            set { _c_title = value; }
            get { return _c_title; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_content
        {
            set { _c_content = value; }
            get { return _c_content; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? C_time
        {
            set { _c_time = value; }
            get { return _c_time; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? C_date
        {
            set { _c_date = value; }
            get { return _c_date; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? C_over
        {
            set { _c_over = value; }
            get { return _c_over; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int C_star
        {
            set { _c_star = value; }
            get { return _c_star; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int C_sai
        {
            set { _c_sai = value; }
            get { return _c_sai; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string paihang
        {
            set { _paihang = value; }
            get { return _paihang; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string j_content
        {
            set { _j_content = value; }
            get { return _j_content; }
        }
    }
}
