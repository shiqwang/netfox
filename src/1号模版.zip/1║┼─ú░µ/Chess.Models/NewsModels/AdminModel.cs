using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class AdminModel
    {
        private int _id;
        private string _admin;
        private string _password;
        private string _classcode;
        private string _classname;
        /// <summary>
        /// 
        /// </summary>
        public int id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string admin
        {
            set { _admin = value; }
            get { return _admin; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string password
        {
            set { _password = value; }
            get { return _password; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string classcode
        {
            set { _classcode = value; }
            get { return _classcode; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string classname
        {
            set { _classname = value; }
            get { return _classname; }
        }
    }
}
