using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class DuihuanModel
    {
        private int _id;
        private int _userid;
        private int? _c_id;
        private int? _y_huan;
        private string _username;
        private string _c_idno;
        private string _lianxi;
        private string _email;
        private string _other;
        private DateTime? _thetime;
        private string _d_content;
        /// <summary>
        /// 
        /// </summary>
        public int id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int userid
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? c_id
        {
            set { _c_id = value; }
            get { return _c_id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? Y_huan
        {
            set { _y_huan = value; }
            get { return _y_huan; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string username
        {
            set { _username = value; }
            get { return _username; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_idno
        {
            set { _c_idno = value; }
            get { return _c_idno; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string lianxi
        {
            set { _lianxi = value; }
            get { return _lianxi; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string email
        {
            set { _email = value; }
            get { return _email; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string other
        {
            set { _other = value; }
            get { return _other; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? thetime
        {
            set { _thetime = value; }
            get { return _thetime; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string D_content
        {
            set { _d_content = value; }
            get { return _d_content; }
        }
    }
}
