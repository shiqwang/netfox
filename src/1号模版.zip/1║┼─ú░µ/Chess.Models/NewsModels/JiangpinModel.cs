using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class JiangpinModel
    {
        private int _c_id;
        private string _c_name;
        private string _c_type;
        private int? _c_money;
        private string _c_pic;
        private string _c_other;
        private DateTime? _c_time;
        private int? _c_vip;
        private string _c_content;
        private int? _c_cun;
        /// <summary>
        /// 
        /// </summary>
        public int C_id
        {
            set { _c_id = value; }
            get { return _c_id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_name
        {
            set { _c_name = value; }
            get { return _c_name; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_type
        {
            set { _c_type = value; }
            get { return _c_type; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? C_money
        {
            set { _c_money = value; }
            get { return _c_money; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_pic
        {
            set { _c_pic = value; }
            get { return _c_pic; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_other
        {
            set { _c_other = value; }
            get { return _c_other; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? C_time
        {
            set { _c_time = value; }
            get { return _c_time; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? C_vip
        {
            set { _c_vip = value; }
            get { return _c_vip; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string C_content
        {
            set { _c_content = value; }
            get { return _c_content; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? C_cun
        {
            set { _c_cun = value; }
            get { return _c_cun; }
        }
    }
}
