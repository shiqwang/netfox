using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class C_typeModel
    {
        private int _id;
        private string _t_name;
        private string _t_other;
        /// <summary>
        /// 
        /// </summary>
        public int ID
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string t_name
        {
            set { _t_name = value; }
            get { return _t_name; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string t_other
        {
            set { _t_other = value; }
            get { return _t_other; }
        }
    }
}
