using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.NewsModels
{
    public class JinbiModel
    {
        private int _id;
        private int? _jinbi;
        /// <summary>
        /// 
        /// </summary>
        public int id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int? jinbi
        {
            set { _jinbi = value; }
            get { return _jinbi; }
        }
    }
}
