using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class RecordInsureModel
    {
        private int _insureid;
        private int _kindid;
        private int _serverid;
        private int _sourceuserid;
        private int _sourcegameid;
        private string _sourceaccounts;
        private int _targetuserid;
        private int _targetgameid;
        private string _targetaccounts;
        private long _insurescore;
        private long _swapscore;
        private long _revenue;
        //private long _currentscore;
        //private long _currentinsurescore;
        private int _tradetype;
        private string _clientip;
        private string _collectdate;
        private string _collectnote;
        /// <summary>
        /// ��ˮ��ʶ
        /// </summary>
        public int InsureID
        {
            set { _insureid = value; }
            get { return _insureid; }
        }
        /// <summary>
        /// ��Ϸ����
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// Դ�û�ID
        /// </summary>
        public int SourceUserID
        {
            set { _sourceuserid = value; }
            get { return _sourceuserid; }
        }
        /// <summary>
        /// Դ�û���ϷID
        /// </summary>
        public int SourceGameID
        {
            set { _sourcegameid = value; }
            get { return _sourcegameid; }
        }
        /// <summary>
        /// Դ�û��ʺ�
        /// </summary>
        public string SourceAccounts
        {
            set { _sourceaccounts = value; }
            get { return _sourceaccounts; }
        }
        /// <summary>
        /// Ŀ���û�ID
        /// </summary>
        public int TargetUserID
        {
            set { _targetuserid = value; }
            get { return _targetuserid; }
        }
        /// <summary>
        /// Ŀ������ϷID
        /// </summary>
        public int TargetGameID
        {
            set { _targetgameid = value; }
            get { return _targetgameid; }
        }
        /// <summary>
        /// Ŀ�����ʻ�
        /// </summary>
        public string TargetAccounts
        {
            set { _targetaccounts = value; }
            get { return _targetaccounts; }
        }
        /// <summary>
        /// Դ�û�ӵ��������Ŀ
        /// </summary>
        public long InsureScore
        {
            set { _insurescore = value; }
            get { return _insurescore; }
        }
        /// <summary>
        /// ��ͨ������Ŀ
        /// </summary>
        public long SwapScore
        {
            set { _swapscore = value; }
            get { return _swapscore; }
        }
        /// <summary>
        /// ˰����Ŀ
        /// </summary>
        public long Revenue
        {
            set { _revenue = value; }
            get { return _revenue; }
        }
        /// <summary>
        /// �������,�� 1,ȡ 2,ת 3
        /// </summary>
        //public long CurrentScore
        //{
        //    set { _currentscore = value; }
        //    get { return _currentscore; }
        //}
        //public long CurrentInsureScore
        //{
        //    set { _currentinsurescore = value; }
        //    get { return _currentinsurescore; }
        //}
        public int TradeType
        {
            set { _tradetype = value; }
            get { return _tradetype; }
        }
        /// <summary>
        /// ���ӵ�ַ
        /// </summary>
        public string ClientIP
        {
            set { _clientip = value; }
            get { return _clientip; }
        }
        /// <summary>
        /// ¼��ʱ��
        /// </summary>
        public string CollectDate
        {
            set { _collectdate = value; }
            get { return _collectdate; }
        }
        /// <summary>
        /// ��ע
        /// </summary>
        public string CollectNote
        {
            set { _collectnote = value; }
            get { return _collectnote; }
        }
    }
}
