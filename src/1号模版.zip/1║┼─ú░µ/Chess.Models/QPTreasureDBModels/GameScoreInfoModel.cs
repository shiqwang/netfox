using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class GameScoreInfoModel
    {
        private int _userid;
        private long _score;
        private long _revenue;
        private long _insurescore;
        private int _wincount;
        private int _lostcount;
        private int _drawcount;
        private int _fleecount;
        private int _userright;
        private int _masterright;
        private int _masterorder;
        private string _registerip;
        private string _lastlogonip;
        private string _registerdate;
        private string _lastlogondate;
        private int _alllogontimes;
        private int _playtimecount;
        private int _onlinetimecount;
        private string _accounts;

        /// <summary>
        /// �û� ID
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// �û����֣����ң�
        /// </summary>
        public long Score
        {
            set { _score = value; }
            get { return _score; }
        }
        /// <summary>
        /// ��Ϸ˰��
        /// </summary>
        public long Revenue
        {
            set { _revenue = value; }
            get { return _revenue; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public long InsureScore
        {
            set { _insurescore = value; }
            get { return _insurescore; }
        }
        /// <summary>
        /// ʤ����Ŀ
        /// </summary>
        public int WinCount
        {
            set { _wincount = value; }
            get { return _wincount; }
        }
        /// <summary>
        /// �����Ŀ
        /// </summary>
        public int LostCount
        {
            set { _lostcount = value; }
            get { return _lostcount; }
        }
        /// <summary>
        /// �;���Ŀ
        /// </summary>
        public int DrawCount
        {
            set { _drawcount = value; }
            get { return _drawcount; }
        }
        /// <summary>
        /// �Ӿ���Ŀ
        /// </summary>
        public int FleeCount
        {
            set { _fleecount = value; }
            get { return _fleecount; }
        }
        /// <summary>
        /// �û�Ȩ��
        /// </summary>
        public int UserRight
        {
            set { _userright = value; }
            get { return _userright; }
        }
        /// <summary>
        /// ����Ȩ��
        /// </summary>
        public int MasterRight
        {
            set { _masterright = value; }
            get { return _masterright; }
        }
        /// <summary>
        /// �����ȼ�
        /// </summary>
        public int MasterOrder
        {
            set { _masterorder = value; }
            get { return _masterorder; }
        }
        /// <summary>
        /// ע�� IP
        /// </summary>
        public string RegisterIP
        {
            set { _registerip = value; }
            get { return _registerip; }
        }
        /// <summary>
        /// �ϴε�½ IP
        /// </summary>
        public string LastLogonIP
        {
            set { _lastlogonip = value; }
            get { return _lastlogonip; }
        }
        /// <summary>
        /// ע��ʱ��
        /// </summary>
        public string RegisterDate
        {
            set { _registerdate = value; }
            get { return _registerdate; }
        }
        /// <summary>
        /// �ϴε�½ʱ��
        /// </summary>
        public string LastLogonDate
        {
            set { _lastlogondate = value; }
            get { return _lastlogondate; }
        }
        /// <summary>
        /// �ܵ�½����
        /// </summary>
        public int AllLogonTimes
        {
            set { _alllogontimes = value; }
            get { return _alllogontimes; }
        }
        /// <summary>
        /// ��Ϸʱ��
        /// </summary>
        public int PlayTimeCount
        {
            set { _playtimecount = value; }
            get { return _playtimecount; }
        }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        public int OnLineTimeCount
        {
            set { _onlinetimecount = value; }
            get { return _onlinetimecount; }
        }

        public string Accounts
        {
            get { return _accounts; }
            set { _accounts = value; }
        }
    }
}
