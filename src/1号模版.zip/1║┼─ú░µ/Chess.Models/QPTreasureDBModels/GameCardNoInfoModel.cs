using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class GameCardNoInfoModel
    {
        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        private string cardno;

        public string CardNo
        {
            get { return cardno; }
            set { cardno = value; }
        }
        private string cardpass;

        public string CardPass
        {
            get { return cardpass; }
            set { cardpass = value; }
        }
        private int cardtypeid;

        public int CardTypeID
        {
            get { return cardtypeid; }
            set { cardtypeid = value; }
        }
        private int batchno;

        public int BatchNo
        {
            get { return batchno; }
            set { batchno = value; }
        }
        private bool nullity;

        public bool Nullity
        {
            get { return nullity; }
            set { nullity = value; }
        }
        private string createdate;

        public string CreateDate
        {
            get { return createdate; }
            set { createdate = value; }
        }
        private string usedate;

        public string UseDate
        {
            get { return usedate; }
            set { usedate = value; }
        }
        private int userid;

        public int UserID
        {
            get { return userid; }
            set { userid = value; }
        }
        private string accounts;

        public string Accounts
        {
            get { return accounts; }
            set { accounts = value; }
        }

    }
}
