using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class RecordExchangeLovelinessModel
    {
        private int _recordid;
        private int _userid;
        private int _kindid;
        private int _serverid;
        private long _loveliness;
        private long _insurescore;
        private DateTime _exchangedate;
        private string _clientip;
        /// <summary>
        /// ��¼��ʶ
        /// </summary>
        public int RecordID
        {
            set { _recordid = value; }
            get { return _recordid; }
        }
        /// <summary>
        /// �û���ʶ
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// ��Ϸ��ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// �û�����
        /// </summary>
        public long Loveliness
        {
            set { _loveliness = value; }
            get { return _loveliness; }
        }
        /// <summary>
        /// �һ�����
        /// </summary>
        public long InsureScore
        {
            set { _insurescore = value; }
            get { return _insurescore; }
        }
        /// <summary>
        /// �һ�����
        /// </summary>
        public DateTime ExchangeDate
        {
            set { _exchangedate = value; }
            get { return _exchangedate; }
        }
        /// <summary>
        /// �һ���ַ
        /// </summary>
        public string ClientIP
        {
            set { _clientip = value; }
            get { return _clientip; }
        }
    }
}
