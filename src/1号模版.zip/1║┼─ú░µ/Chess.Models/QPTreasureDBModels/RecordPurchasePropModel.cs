using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class RecordPurchasePropModel
    {
        private int _recordid;
        private int _senduserid;
        private int _rcvuserid;
        private int _kindid;
        private int _serverid;
        private int _cateid;
        private int _curcount;
        private int _oncecount;
        private int _pachursecount;
        private int _spendscore;
        private string _clientip;
        private string _purchasedate;
        /// <summary>
        /// ��¼��ʶ
        /// </summary>
        public int RecordID
        {
            set { _recordid = value; }
            get { return _recordid; }
        }
        /// <summary>
        /// ������ID
        /// </summary>
        public int SendUserID
        {
            set { _senduserid = value; }
            get { return _senduserid; }
        }
        /// <summary>
        /// ������ID
        /// </summary>
        public int RcvUserID
        {
            set { _rcvuserid = value; }
            get { return _rcvuserid; }
        }
        /// <summary>
        /// ��Ϸ��ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// �������
        /// </summary>
        public int CateID
        {
            set { _cateid = value; }
            get { return _cateid; }
        }
        /// <summary>
        /// ��ǰ��Ŀ
        /// </summary>
        public int CurCount
        {
            set { _curcount = value; }
            get { return _curcount; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int OnceCount
        {
            set { _oncecount = value; }
            get { return _oncecount; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int PachurseCount
        {
            set { _pachursecount = value; }
            get { return _pachursecount; }
        }
        /// <summary>
        /// ����۸�
        /// </summary>
        public int SpendScore
        {
            set { _spendscore = value; }
            get { return _spendscore; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string ClientIP
        {
            set { _clientip = value; }
            get { return _clientip; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string PurchaseDate
        {
            set { _purchasedate = value; }
            get { return _purchasedate; }
        }
    }
}
