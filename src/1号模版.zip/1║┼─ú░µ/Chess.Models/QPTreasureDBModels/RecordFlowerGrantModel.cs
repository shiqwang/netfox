using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class RecordFlowerGrantModel
    {
        private int _recordid;
        private int _senduserid;
        private int _rcvuserid;
        private int _kindid;
        private int _serverid;
        private string _flowername;
        private int _flowercount;
        private long _flowerpay;
        private int _senduserloveliness;
        private int _rcvuserloveliness;
        private string _grantip;
        private DateTime _grantdate;
        /// <summary>
        /// ��ˮ��ʶ
        /// </summary>
        public int RecordID
        {
            set { _recordid = value; }
            get { return _recordid; }
        }
        /// <summary>
        /// �����߱�ʶ
        /// </summary>
        public int SendUserID
        {
            set { _senduserid = value; }
            get { return _senduserid; }
        }
        /// <summary>
        /// �����߱�ʶ
        /// </summary>
        public int RcvUserID
        {
            set { _rcvuserid = value; }
            get { return _rcvuserid; }
        }
        /// <summary>
        /// ��Ϸ��ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string FlowerName
        {
            set { _flowername = value; }
            get { return _flowername; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int FlowerCount
        {
            set { _flowercount = value; }
            get { return _flowercount; }
        }
        /// <summary>
        /// ���͸���
        /// </summary>
        public long FlowerPay
        {
            set { _flowerpay = value; }
            get { return _flowerpay; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public int SendUserLoveliness
        {
            set { _senduserloveliness = value; }
            get { return _senduserloveliness; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public int RcvUserLoveliness
        {
            set { _rcvuserloveliness = value; }
            get { return _rcvuserloveliness; }
        }
        /// <summary>
        /// ���͵�ַ
        /// </summary>
        public string GrantIP
        {
            set { _grantip = value; }
            get { return _grantip; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public DateTime GrantDate
        {
            set { _grantdate = value; }
            get { return _grantdate; }
        }
    }
}
