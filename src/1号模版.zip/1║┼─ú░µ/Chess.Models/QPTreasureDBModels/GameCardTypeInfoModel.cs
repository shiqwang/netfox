using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class GameCardTypeInfoModel
    {
        private int cardid;

        public int CardID
        {
            get { return cardid; }
            set { cardid = value; }
        }
        private string cardtitle;

        public string CardTitle
        {
            get { return cardtitle; }
            set { cardtitle = value; }
        }
        private int score;

        public int Score
        {
            get { return score; }
            set { score = value; }
        }
        private string memo;

        public string Memo
        {
            get { return memo; }
            set { memo = value; }
        }
        private int overdate;

        public int OverDate
        {
            get { return overdate; }
            set { overdate = value; }
        }
        private bool ispresent;

        public bool IsPresent
        {
            get { return ispresent; }
            set { ispresent = value; }
        }
        private int memberorder;

        public int Memberorder
        {
            get { return memberorder; }
            set { memberorder = value; }
        }
    }
}
