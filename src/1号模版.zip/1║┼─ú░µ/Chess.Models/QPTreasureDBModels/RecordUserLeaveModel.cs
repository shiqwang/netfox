using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class RecordUserLeaveModel
    {
        private int _userid;
        private long _score;
        private long _revenue;
        private int _kindid;
        private int _serverid;
        private int _playtimecount;
        private int _onlinetimecount;
        private string _leavetime;
        /// <summary>
        /// �û���ʶ
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// �뿪����
        /// </summary>
        public long Score
        {
            set { _score = value; }
            get { return _score; }
        }
        /// <summary>
        /// ˰����Ŀ
        /// </summary>
        public long Revenue
        {
            set { _revenue = value; }
            get { return _revenue; }
        }
        /// <summary>
        /// ���ͱ�ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// ��Ϸʱ��
        /// </summary>
        public int PlayTimeCount
        {
            set { _playtimecount = value; }
            get { return _playtimecount; }
        }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        public int OnLineTimeCount
        {
            set { _onlinetimecount = value; }
            get { return _onlinetimecount; }
        }
        /// <summary>
        /// �뿪ʱ��
        /// </summary>
        public string LeaveTime
        {
            set { _leavetime = value; }
            get { return _leavetime; }
        }
    }
}
