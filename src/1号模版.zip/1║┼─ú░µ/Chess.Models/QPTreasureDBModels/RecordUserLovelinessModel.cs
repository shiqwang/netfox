using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class RecordUserLovelinessModel
    {
        private int _recordid;
        private int _userid;
        private int _kindid;
        private int _serverid;
        private int _loveliness;
        private DateTime _writedate;
        private string _clientip;
        /// <summary>
        /// ��¼��ʶ
        /// </summary>
        public int RecordID
        {
            set { _recordid = value; }
            get { return _recordid; }
        }
        /// <summary>
        /// �û���ʶ
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// ��Ϸ��ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// �û�����
        /// </summary>
        public int Loveliness
        {
            set { _loveliness = value; }
            get { return _loveliness; }
        }
        /// <summary>
        /// д��ʱ��
        /// </summary>
        public DateTime WriteDate
        {
            set { _writedate = value; }
            get { return _writedate; }
        }
        /// <summary>
        /// д���ַ
        /// </summary>
        public string ClientIP
        {
            set { _clientip = value; }
            get { return _clientip; }
        }
    }
}
