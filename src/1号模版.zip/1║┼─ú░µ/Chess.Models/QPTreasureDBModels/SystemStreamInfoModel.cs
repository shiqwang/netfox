using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class SystemStreamInfoModel
    {
        private int _dateid;
        private int _kindid;
        private int _serverid;
        private int _logoncount;
        private int _logoutcount;
        private DateTime _collectdate;
        /// <summary>
        /// ���ڱ�ʶ
        /// </summary>
        public int DateID
        {
            set { _dateid = value; }
            get { return _dateid; }
        }
        /// <summary>
        /// ���ͱ�ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int LogonCount
        {
            set { _logoncount = value; }
            get { return _logoncount; }
        }
        /// <summary>
        /// �뿪��Ŀ
        /// </summary>
        public int LogOutCount
        {
            set { _logoutcount = value; }
            get { return _logoutcount; }
        }
        /// <summary>
        /// ¼��ʱ��
        /// </summary>
        public DateTime CollectDate
        {
            set { _collectdate = value; }
            get { return _collectdate; }
        }
    }
}
