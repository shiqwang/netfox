using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class RecordUserEnterModel
    {
        private int _userid;
        private long _score;
        private int _kindid;
        private string _clientip;
        private int _serverid;
        private string _entertime;
        /// <summary>
        /// �û���ʶ
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public long Score
        {
            set { _score = value; }
            get { return _score; }
        }
        /// <summary>
        /// ���ͱ�ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// ��¼��ַ
        /// </summary>
        public string ClientIP
        {
            set { _clientip = value; }
            get { return _clientip; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        public string EnterTime
        {
            set { _entertime = value; }
            get { return _entertime; }
        }
    }
}
