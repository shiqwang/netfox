using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class RecordGiftGrantModel
    {
        private int _recordid;
        private int _senduserid;
        private int _rcvuserid;
        private int _kindid;
        private int _serverid;
        private string _gift;
        private long _giftpay;
        private string _grantip;
        private DateTime _grantdate;
        /// <summary>
        /// ��ˮ��ʶ
        /// </summary>
        public int RecordID
        {
            set { _recordid = value; }
            get { return _recordid; }
        }
        /// <summary>
        /// �����߱�ʶ
        /// </summary>
        public int SendUserID
        {
            set { _senduserid = value; }
            get { return _senduserid; }
        }
        /// <summary>
        /// �����߱�ʶ
        /// </summary>
        public int RcvUserID
        {
            set { _rcvuserid = value; }
            get { return _rcvuserid; }
        }
        /// <summary>
        /// ��Ϸ��ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string Gift
        {
            set { _gift = value; }
            get { return _gift; }
        }
        /// <summary>
        /// ���͸���
        /// </summary>
        public long GiftPay
        {
            set { _giftpay = value; }
            get { return _giftpay; }
        }
        /// <summary>
        /// ���͵�ַ
        /// </summary>
        public string GrantIP
        {
            set { _grantip = value; }
            get { return _grantip; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public DateTime GrantDate
        {
            set { _grantdate = value; }
            get { return _grantdate; }
        }
    }
}
