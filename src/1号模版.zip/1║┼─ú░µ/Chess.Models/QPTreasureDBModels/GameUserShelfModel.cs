using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class GameUserShelfModel
    {
        private int _userid;
        private int _cateid;
        private int _kindid;
        private long _propcount;
        private int _usedflag;
        private string _writedate;
        private string _clientip;
        /// <summary>
        /// �û���ʶ
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// ����ʶ
        /// </summary>
        public int CateID
        {
            set { _cateid = value; }
            get { return _cateid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public long PropCount
        {
            set { _propcount = value; }
            get { return _propcount; }
        }
        /// <summary>
        /// ʹ�ñ�ʶ
        /// </summary>
        public int UsedFlag
        {
            set { _usedflag = value; }
            get { return _usedflag; }
        }
        /// <summary>
        /// д��ʱ��
        /// </summary>
        public string WriteDate
        {
            set { _writedate = value; }
            get { return _writedate; }
        }
        /// <summary>
        /// д���ַ
        /// </summary>
        public string ClientIP
        {
            set { _clientip = value; }
            get { return _clientip; }
        }
    }
}
