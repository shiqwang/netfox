using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class ConfineAddressModel
    {
        private string _addrstring;
        private bool _enjoinlogon;
        private DateTime _enjoinoverdate;
        private DateTime _collectdate;
        private string _collectnote;
        /// <summary>
        /// ��ַ�ַ�
        /// </summary>
        public string AddrString
        {
            set { _addrstring = value; }
            get { return _addrstring; }
        }
        /// <summary>
        /// ���Ƶ�½
        /// </summary>
        public bool EnjoinLogon
        {
            set { _enjoinlogon = value; }
            get { return _enjoinlogon; }
        }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        public DateTime EnjoinOverDate
        {
            set { _enjoinoverdate = value; }
            get { return _enjoinoverdate; }
        }
        /// <summary>
        /// �ռ�����
        /// </summary>
        public DateTime CollectDate
        {
            set { _collectdate = value; }
            get { return _collectdate; }
        }
        /// <summary>
        /// ���뱸ע
        /// </summary>
        public string CollectNote
        {
            set { _collectnote = value; }
            get { return _collectnote; }
        }
    }
}
