using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class AndroidUserInfoModel
    {
        private int _userid;
        private bool _nullity;
        private int _kindid;
        private int _serverid;
        private DateTime _createdate;
        private string _androidnote;
        /// <summary>
        /// �û���ʶ
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// ��ֹ����
        /// </summary>
        public bool Nullity
        {
            set { _nullity = value; }
            get { return _nullity; }
        }
        /// <summary>
        /// ���ͱ�ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// �����ʶ
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public DateTime CreateDate
        {
            set { _createdate = value; }
            get { return _createdate; }
        }
        /// <summary>
        /// ��ע��Ϣ
        /// </summary>
        public string AndroidNote
        {
            set { _androidnote = value; }
            get { return _androidnote; }
        }
    }
}
