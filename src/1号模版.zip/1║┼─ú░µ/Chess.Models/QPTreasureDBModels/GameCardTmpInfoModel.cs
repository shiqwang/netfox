using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class GameCardTmpInfoModel
    {
        private string cardno;

        public string CardNo
        {
            get { return cardno; }
            set { cardno = value; }
        }
        private string cardpassword;

        public string CardPassword
        {
            get { return cardpassword; }
            set { cardpassword = value; }
        }
        private int cardtypeid;

        public int CardTypeID
        {
            get { return cardtypeid; }
            set { cardtypeid = value; }
        }
        private string memo;

        public string Memo
        {
            get { return memo; }
            set { memo = value; }
        }
    }
}
