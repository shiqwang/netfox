using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class GameShopCateModel
    {
        private int _cateid;
        private string _catename;
        private int _propcount1;
        private int _propcount2;
        private int _propcount3;
        private int _propcount4;
        private int _propcount5;
        private int _propcount6;
        private int _propcount7;
        private int _propcount8;
        private int _propcount9;
        private int _propcount10;
        private int _price1;
        private int _price2;
        private int _price3;
        private int _price4;
        private int _price5;
        private int _price6;
        private int _price7;
        private int _price8;
        private int _price9;
        private int _price10;
        private int _discount;
        private string _catenote;
        private bool _nullity;
        /// <summary>
        /// ����ID
        /// </summary>
        public int CateID
        {
            set { _cateid = value; }
            get { return _cateid; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public string CateName
        {
            set { _catename = value; }
            get { return _catename; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int PropCount1
        {
            set { _propcount1 = value; }
            get { return _propcount1; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int PropCount2
        {
            set { _propcount2 = value; }
            get { return _propcount2; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int PropCount3
        {
            set { _propcount3 = value; }
            get { return _propcount3; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int PropCount4
        {
            set { _propcount4 = value; }
            get { return _propcount4; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int PropCount5
        {
            set { _propcount5 = value; }
            get { return _propcount5; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int PropCount6
        {
            set { _propcount6 = value; }
            get { return _propcount6; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int PropCount7
        {
            set { _propcount7 = value; }
            get { return _propcount7; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int PropCount8
        {
            set { _propcount8 = value; }
            get { return _propcount8; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int PropCount9
        {
            set { _propcount9 = value; }
            get { return _propcount9; }
        }
        /// <summary>
        /// ������Ŀ
        /// </summary>
        public int PropCount10
        {
            set { _propcount10 = value; }
            get { return _propcount10; }
        }
        /// <summary>
        /// ���߼۸�
        /// </summary>
        public int Price1
        {
            set { _price1 = value; }
            get { return _price1; }
        }
        /// <summary>
        /// ���߼۸�
        /// </summary>
        public int Price2
        {
            set { _price2 = value; }
            get { return _price2; }
        }
        /// <summary>
        /// ���߼۸�
        /// </summary>
        public int Price3
        {
            set { _price3 = value; }
            get { return _price3; }
        }
        /// <summary>
        /// ���߼۸�
        /// </summary>
        public int Price4
        {
            set { _price4 = value; }
            get { return _price4; }
        }
        /// <summary>
        /// ���߼۸�
        /// </summary>
        public int Price5
        {
            set { _price5 = value; }
            get { return _price5; }
        }
        /// <summary>
        /// ���߼۸�
        /// </summary>
        public int Price6
        {
            set { _price6 = value; }
            get { return _price6; }
        }
        /// <summary>
        /// ���߼۸�
        /// </summary>
        public int Price7
        {
            set { _price7 = value; }
            get { return _price7; }
        }
        /// <summary>
        /// ���߼۸�
        /// </summary>
        public int Price8
        {
            set { _price8 = value; }
            get { return _price8; }
        }
        /// <summary>
        /// ���߼۸�
        /// </summary>
        public int Price9
        {
            set { _price9 = value; }
            get { return _price9; }
        }
        /// <summary>
        /// ���߼۸�
        /// </summary>
        public int Price10
        {
            set { _price10 = value; }
            get { return _price10; }
        }
        /// <summary>
        /// ��Ա�ۿ�
        /// </summary>
        public int Discount
        {
            set { _discount = value; }
            get { return _discount; }
        }
        /// <summary>
        /// ��ע��Ϣ
        /// </summary>
        public string CateNote
        {
            set { _catenote = value; }
            get { return _catenote; }
        }
        /// <summary>
        /// ��ֹ��ʶ
        /// </summary>
        public bool Nullity
        {
            set { _nullity = value; }
            get { return _nullity; }
        }
    }
}
