using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class ConfineMachineModel
    {
        private string _machineserial;
        private bool _enjoinlogon;
        private bool _enjoinregister;
        private DateTime _enjoinoverdate;
        private DateTime _collectdate;
        private string _collectnote;
        /// <summary>
        /// ��������
        /// </summary>
        public string MachineSerial
        {
            set { _machineserial = value; }
            get { return _machineserial; }
        }
        /// <summary>
        /// ���Ƶ�¼
        /// </summary>
        public bool EnjoinLogon
        {
            set { _enjoinlogon = value; }
            get { return _enjoinlogon; }
        }
        /// <summary>
        /// ����ע��
        /// </summary>
        public bool EnjoinRegister
        {
            set { _enjoinregister = value; }
            get { return _enjoinregister; }
        }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        public DateTime EnjoinOverDate
        {
            set { _enjoinoverdate = value; }
            get { return _enjoinoverdate; }
        }
        /// <summary>
        /// �ռ�����
        /// </summary>
        public DateTime CollectDate
        {
            set { _collectdate = value; }
            get { return _collectdate; }
        }
        /// <summary>
        /// ���뱸ע
        /// </summary>
        public string CollectNote
        {
            set { _collectnote = value; }
            get { return _collectnote; }
        }
    }
}
