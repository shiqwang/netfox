using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class GameScoreLockerModel
    {
        private int _userid;
        private int _kindid;
        private int _serverid;
        private DateTime _collectdate;
        /// <summary>
        /// �û�����
        /// </summary>
        public int UserID
        {
            set { _userid = value; }
            get { return _userid; }
        }
        /// <summary>
        /// ���ͱ�ʶ
        /// </summary>
        public int KindID
        {
            set { _kindid = value; }
            get { return _kindid; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public int ServerID
        {
            set { _serverid = value; }
            get { return _serverid; }
        }
        /// <summary>
        /// ¼������
        /// </summary>
        public DateTime CollectDate
        {
            set { _collectdate = value; }
            get { return _collectdate; }
        }
    }
}
