using System;
using System.Collections.Generic;
using System.Text;

namespace Chess.Models.QPTreasureDBModels
{
    public class FlowerCateModel
    {
        private int _id;
        private string _name;
        private int _price;
        private int _sendusercharm;
        private int _rcvusercharm;
        private int _discount;
        private bool _nullity;
        /// <summary>
        /// �ʻ�ID
        /// </summary>
        public int ID
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// �ʻ�����
        /// </summary>
        public string Name
        {
            set { _name = value; }
            get { return _name; }
        }
        /// <summary>
        /// �ʻ��۸�
        /// </summary>
        public int Price
        {
            set { _price = value; }
            get { return _price; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public int SendUserCharm
        {
            set { _sendusercharm = value; }
            get { return _sendusercharm; }
        }
        /// <summary>
        /// ��������
        /// </summary>
        public int RcvUserCharm
        {
            set { _rcvusercharm = value; }
            get { return _rcvusercharm; }
        }
        /// <summary>
        /// ��Ա�ۿ�
        /// </summary>
        public int Discount
        {
            set { _discount = value; }
            get { return _discount; }
        }
        /// <summary>
        /// ��ֹ��ʶ
        /// </summary>
        public bool Nullity
        {
            set { _nullity = value; }
            get { return _nullity; }
        }
    }
}
