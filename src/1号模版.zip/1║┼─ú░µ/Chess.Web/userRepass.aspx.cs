﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Chess.BLL.QPGameUserDBBLL;
using Chess.Models.QPGameUserDBModels;

public partial class userRepass : System.Web.UI.Page
{
    AccountsInfoManager am = new AccountsInfoManager();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserName"] == null)
            {
                Response.Redirect("Login.aspx");
                return;
            }
        }
    }
    public string UserMD5(string str, int code)
    {
        if (code == 16) //16位MD5加密（取32位加密的9~25字符） 
        {
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(str, "MD5").ToLower().Substring(8, 16);
        }
        else//32位加密 
        {
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(str, "MD5").ToLower();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string password = this.txtOldPass.Text.Trim();
        string pwd = UserMD5(this.txtNewPass_1.Text.Trim(), 32);
        string username = "" + Session["UserName"];
        AccountsInfoModel accountsinfomodel = new AccountsInfoManager().GetAccountsInfoByName(username);
        if (txtCode.Text.Trim().ToLower() != Session["ValidCode"].ToString().ToLower())
        {
            lblMessage.Text = "验证码错误！";
            return;
        }
        else
        {
            if (UserMD5(password, 32) != accountsinfomodel.LogonPass)
            {

                lblMessage.Text = "旧密码错误！";
                txtOldPass.Focus();
                return;
            }
            else
            {
                if (string.IsNullOrEmpty(txtNewPass_1.Text))
                {
                    lblMessage.Text = "新密码不能为空！";

                    return;
                }
                else
                {
                    if (txtNewPass_1.Text != txtNewPass_2.Text)
                    {
                        lblMessage.Text = "两次密码不一致！";

                        return;
                    }
                    else
                    {
                        am.UpdatePassWord(username, pwd);

                        Response.Redirect("UserCenter.aspx");
                    }
                }

            }
        }
    }
}
