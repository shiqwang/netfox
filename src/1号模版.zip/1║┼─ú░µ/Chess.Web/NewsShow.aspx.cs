﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;

public partial class NewsShow : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            UpdateUI();
            Upload();
        }

    }
    private void UpdateUI()
    {
        if (Request.QueryString["id"] == null)
        {
            Response.Redirect("default.aspx");
        }
        else
        {
            int id = int.Parse(Request.QueryString["id"]);
            HdModel hd = new HdManager().GetHdById(id);
            this.Label2.Text = hd.tit.ToString();
            this.Label3.Text = hd.sj.ToString();
            this.divnr.InnerHtml = hd.nr.ToString();
            
        }
    }
    private void Upload()
    {
        ContactModel cont = new ContactManager().GetContact();

        this.tit.Text = this.Label2.Text+" "+cont.Co_Name + " " + cont.Co_Url;
    }
}
