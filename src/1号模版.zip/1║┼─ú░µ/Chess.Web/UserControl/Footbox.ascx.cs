﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;

public partial class UserControl_Footbox : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Upload();
        }
    }
    private void Upload()
    {
        ContactModel cont = new ContactManager().GetContact();
        this.tel.Text = cont.Tel;
        this.post.Text = cont.Post_Code;
        this.icp.Text = cont.icp;
        this.coname.Text = cont.Co_Name;
    }
}
