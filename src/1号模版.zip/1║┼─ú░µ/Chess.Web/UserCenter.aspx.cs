﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.Models.QPTreasureDBModels;
using Chess.BLL.QPTreasureDBBLL;
using Chess.BLL.QPGameUserDBBLL;
using Chess.Models.QPGameUserDBModels;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;

public partial class UserCenter : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            UpdateUI();
            Upload();
            

        }
    }
    private void Upload()
    {
        ContactModel cont = new ContactManager().GetContact();

        this.tit.Text = cont.Co_Name + " " + cont.Co_Url;
    }
    private void UpdateUI()
    {
        if (Session["UserName"] != null)
        {
            string name = "" + Session["UserName"];
            AccountsInfoModel accountsinfomodel = new AccountsInfoManager().GetAccountsInfoByName(name);
            this.lalGameID.Text = accountsinfomodel.GameID.ToString();
            this.lalAcc.Text = accountsinfomodel.Accounts.ToString();
            //this.txtNickName.Text = accountsinfomodel.RegAccounts.ToString();
            if (accountsinfomodel.Gender == 1)
            {
                this.DropDownList1.Items[0].Selected = true;
            }
            if (accountsinfomodel.Gender == 2)
            {
                this.DropDownList1.Items[1].Selected = true;

            }
            if (accountsinfomodel.Gender == 0)
            {
                this.DropDownList1.Items[2].Selected = true;
            }
            if (accountsinfomodel.MasterOrder == 0)
            {
                this.lalVip.Text = "普通会员";
            }
            if (accountsinfomodel.MasterOrder == 1)
            {
                this.lalVip.Text = "红钻会员";
            }
            if (accountsinfomodel.MasterOrder == 2)
            {
                this.lalVip.Text = "蓝钻会员";
            }
            if (accountsinfomodel.MasterOrder == 3)
            {
                this.lalVip.Text = "黄钻会员";
            }
            if (accountsinfomodel.MasterOrder == 4)
            {
                this.lalVip.Text = "紫钻会员";
            }


            this.lalLove.Text = accountsinfomodel.Loveliness.ToString();
            this.txtMobile.Text = accountsinfomodel.Phone.ToString();
            this.txtSign.Text = accountsinfomodel.UnderWrite.ToString();
            this.txtQQ.Text = accountsinfomodel.QQ.ToString();
            this.txtQuestion.Text = accountsinfomodel.C_PROTECTQUES.ToString();
            this.txtAnswer.Text = accountsinfomodel.C_PROTECTANSW.ToString();
            int UserID = int.Parse(accountsinfomodel.UserID.ToString());
            GameScoreInfoModel gamesm = new GameScoreInfoManager().GetGameScoreInfoById(UserID);
            this.lblScore.Text = int.Parse(gamesm.Score.ToString()) + int.Parse(gamesm.InsureScore.ToString()) + "";
        }
        else
        {
            Response.Redirect("userPage.aspx");
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        string username = "" + Session["UserName"];
        string question = this.txtQuestion.Text;
        string answer = this.txtAnswer.Text;
        string mobile = this.txtMobile.Text;
        string underwrite = this.txtSign.Text;
        string qq = this.txtQQ.Text;
        int gender = 0;
        if (this.DropDownList1.Items[0].Selected == true)
        {
            gender = 1;
        }
        if (this.DropDownList1.Items[1].Selected == true)
        {
            gender = 2;
        }
        if (this.DropDownList1.Items[2].Selected == true)
        {
            gender = 0;
        }
        AccountsInfoManager am = new AccountsInfoManager();
        am.UpdateAccInfo(username, question, underwrite, gender, qq, mobile, answer);
        Response.Write(" <script>alert('修改成功');window.location.href='UserCenter.aspx'; </script>");


    }
}
