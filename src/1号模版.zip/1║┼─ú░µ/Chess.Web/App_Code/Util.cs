﻿using System.Collections;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Wuqi.Webdiyer;

/// <summary>
/// 工具类
/// </summary>
public static class Util
{
    public static string UserMD5(string pwd, MD5Model model)
    {
        // ReSharper disable PossibleNullReferenceException
        string md5 = FormsAuthentication.HashPasswordForStoringInConfigFile(pwd, "MD5").ToLower();
        // ReSharper restore PossibleNullReferenceException

        return model == MD5Model.Model16 ? md5.Substring(8, 16) : md5;
    }

    /// <summary>
    ///   输出客户端对话框
    /// </summary>
    /// <param name = "page">当前page</param>
    /// <param name = "msg">对话框信息</param>
    public static void Alert(Page page, string msg)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("<script>alert('").Append(msg).Append("');</script>");
        page.ClientScript.RegisterStartupScript(page.GetType(), "alertMsg", sb.ToString());

        //write方法容易丢失CSS样式
        //page.Response.Write(sb.ToString());
    }

    /// <summary>
    ///   输出客户端对话框并重载页面
    /// </summary>
    /// <param name = "page">当前页</param>
    /// <param name = "msg">对话框信息</param>
    public static void AlertAndReload(Page page, string msg)
    {
        string script = string.Format("<script>alert('{0}');location.href='{1}'</script>", msg, page.Request.Url);
        page.ClientScript.RegisterStartupScript(page.GetType(), "alertAndReload", script);
    }

    /// <summary>
    ///   输出客户端对话框并重定向新页面
    /// </summary>
    /// <param name = "page">当前页</param>
    /// <param name = "msg">对话框信息</param>
    /// <param name = "redirectUrl">新页面地址</param>
    public static void AlertAndRedirect(Page page, string msg, string redirectUrl)
    {
        string script = string.Format("<script>alert('{0}');location.href='{1}'</script>", msg, redirectUrl);
        page.ClientScript.RegisterStartupScript(page.GetType(), "alertAndRedirect", script);
    }

    public static void Confirm(Page page, string msg)
    {
        string script = string.Format("<script>return confirm('{0}');</script>", msg);
        page.ClientScript.RegisterStartupScript(page.GetType(), "alertAndRedirect", script);
    }

    /// <summary>
    ///   获取客户端IP
    /// </summary>
    /// <param name = "page">当前页</param>
    /// <returns></returns>
    public static string GetIP(Page page)
    {
        string ip = page.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

        if (string.IsNullOrEmpty(ip))
        {
            ip = page.Request.ServerVariables["REMOTE_ADDR"];
        }

        if (string.IsNullOrEmpty(ip))
        {
            ip = page.Request.UserHostAddress;
        }

        if (string.IsNullOrEmpty(ip) || !IsIP(ip))
        {
            ip = "127.0.0.1";
        }

        return ip;
    }

    public static bool IsIP(string ip)
    {
        const string exp = @"^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\." +
                           @"(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\." +
                           @"(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\." +
                           @"(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$";
        Regex regex = new Regex(exp);
        return regex.IsMatch(ip);
    }

    /// <summary>
    ///   数据分页
    /// </summary>
    /// <param name = "list"></param>
    /// <param name = "aspNetPager"></param>
    /// <returns></returns>
    public static PagedDataSource PagedData(IList list, AspNetPager aspNetPager)
    {
        aspNetPager.RecordCount = list.Count;

        PagedDataSource pds = new PagedDataSource();
        pds.DataSource = list;
        pds.AllowPaging = true;
        pds.PageSize = aspNetPager.PageSize;
        pds.CurrentPageIndex = aspNetPager.CurrentPageIndex - 1;
        return pds;
    }
}

public enum MD5Model
{
    Model16,
    Model32
}
