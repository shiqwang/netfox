﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Configuration;

/// <summary>
/// ConfigHelp 的摘要说明
/// </summary>
public class ConfigHelp
{
    private Configuration config;

    public ConfigHelp()
    {
        config = WebConfigurationManager.OpenWebConfiguration("~/");
    }

    public ConfigHelp(string root)
    {
        config = WebConfigurationManager.OpenWebConfiguration(root);
    }
    private AppSettingsSection GetApp()
    {
        AppSettingsSection app = null;
        if (config != null)
        {
            app = config.GetSection("appSettings") as AppSettingsSection;
        }
        return app;
    }

    public string Get(string key)
    {
        AppSettingsSection app = GetApp();
        if (app != null)
        {
            if (app.Settings[key] != null)
                return app.Settings[key].Value;
        }
        return "";
    }

    public void Add(string key, string value)
    {
        AppSettingsSection app = GetApp();
        if (app != null)
        {
            app.Settings.Add(key, value);
            config.Save();
        }
    }

    public void Edit(string key, string value)
    {
        AppSettingsSection app = GetApp();
        if (app != null)
        {
            if (app.Settings[key] != null)
            {
                app.Settings[key].Value = value;
            }
            else
            {
                app.Settings.Add(key, value);
            }
            config.Save();
        }
    }

    public void Delete(string key)
    {
        AppSettingsSection app = GetApp();
        if (app != null)
        {
            app.Settings.Remove(key);
            config.Save();
        }
    }
}
