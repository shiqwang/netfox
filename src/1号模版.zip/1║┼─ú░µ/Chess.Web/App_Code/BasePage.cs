﻿using System;
using System.Text;
using System.Web.UI;

namespace App_Code
{
    /// <summary>
    /// BasePage 的摘要说明
    /// </summary>
    public class BasePage : Page
    {
        public virtual string BackUrl
        {
            get { return string.Empty; }
        }

        protected override void OnPreLoad(EventArgs e)
        {
            base.OnPreLoad(e);

            if (Session["UserName"] == null)
            {
                RedirectUrl();
            }
        }

        private void RedirectUrl()
        {
            StringBuilder url = new StringBuilder();
            url.Append("login.aspx");
            if (!string.IsNullOrEmpty(BackUrl))
                url.AppendFormat("?{0}", BackUrl);
            Response.Redirect(url.ToString());
        }
    }
}
