﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Security.Cryptography;

/// <summary>
/// Common 的摘要说明
/// </summary>
public class Common
{
    public static string Encrypt(string Password)
    {
        // Force the string to lower case
        //
        Password = Password.ToLower();

        Byte[] clearBytes = new UnicodeEncoding().GetBytes(Password);
        Byte[] hashedBytes = ((HashAlgorithm)CryptoConfig.CreateFromName("MD5")).ComputeHash(clearBytes);

        return BitConverter.ToString(hashedBytes);
    }
}
