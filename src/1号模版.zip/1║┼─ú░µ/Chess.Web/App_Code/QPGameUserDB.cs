﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// QPGameUserDB 的摘要说明
/// </summary>
public class QPGameUserDB
{
    public QPGameUserDB()
    {
        //
        // TODO: 在此处添加构造函数逻辑
        //
    }
    public static string TYPE_SECTION = string.Empty;
    public static SqlConnection GetCon()
    {
        return new SqlConnection(ConfigurationManager.AppSettings["connectQPGameUserDB"]);
    }
    public static bool ExSql(string str)
    {
        SqlConnection conn = QPGameUserDB.GetCon();//连接上数据库，并打开了连接
        conn.Open();
        SqlCommand com = new SqlCommand(str, conn);
        try
        {
            com.ExecuteNonQuery();//返回受影响的行数
            return true;
        }
        catch
        {
            return false;
        }
        finally
        {
            com.Dispose();
            conn.Dispose();
            conn.Close(); //关闭连接

        }
    }
    public static DataSet reDs(string str)
    {
        SqlConnection conn = QPGameUserDB.GetCon();//连接上数据库
        SqlDataAdapter da = new SqlDataAdapter(str, conn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        return ds;//返回DataSet对象
    }
    public static SqlDataReader reDr(string str)
    {
        SqlConnection conn = QPGameUserDB.GetCon();//连接上数据库，并打开了连接
        conn.Open();
        SqlCommand com = new SqlCommand(str, conn);
        SqlDataReader dr = com.ExecuteReader(CommandBehavior.CloseConnection);
        return dr;//返回SqlDataReader对象dr
    }
    public static DataTable ExcuteDataTable(string cmdText)
    {
        SqlConnection con = QPGameUserDB.GetCon();
        SqlDataAdapter sda = new SqlDataAdapter(cmdText, con);
        DataSet ds = new DataSet();
        sda.Fill(ds);
        return (ds.Tables[0]);
    }
}
