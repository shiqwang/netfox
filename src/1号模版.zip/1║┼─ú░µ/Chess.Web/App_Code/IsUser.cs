﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;

/// <summary>
///IsUser 的摘要说明
/// </summary>
public class IsUser : IHttpHandler
{
    public IsUser()
    {
        
    }
    #region 方法

    public bool IsReusable
    {
        get { throw new NotImplementedException(); }
    }

    public void ProcessRequest(HttpContext context)
    {
        string flag = "0";
        //获取js传递过来的id值
        string username = System.Web.HttpContext.Current.Request.QueryString["context"];
        if (string.IsNullOrEmpty(username))
        {
            //this.ClientScript.RegisterStartupScript(this.GetType(), "", "<script>alert('用户名不能为空！');</script>");
            flag = "<DIV class=\"re\"><P class=\"tipsError\"><IMG class=\"iconError\" src=\"images/b.gif\" />用户名不能为空!</P></DIV>";
        }
        else
        {

            SqlDataReader sdr = Chess.DAL.DBHelper.QPGameUserDBHelper.GetDataReader("select * from AccountsInfo where Accounts='" + username + "'");
            sdr.Read();
            if (!sdr.HasRows)
            {
                SqlDataReader sdrs = Chess.DAL.DBHelper.QPGameUserDBHelper.GetDataReader("select * from ConfineContent where String ='" + username + "'");
                sdrs.Read();
                if (!sdrs.HasRows)
                {
                    if (int.Parse(username.Length.ToString()) > 1)
                    {
                        //可以注册
                        flag = "1";
                    }
                    else
                    {
                        //this.ClientScript.RegisterStartupScript(this.GetType(), "", "<script>alert('抱歉，用户名最少为2位！');</script>");
                        //this.TextBox1.Text = "";
                        flag = "<DIV class=\"re\"><P class=\"tipsError\"><IMG class=\"iconError\" src=\"images/b.gif\" />抱歉，用户名最少为2位！</P></DIV>";
                    }
                }
                else
                {
                    //this.ClientScript.RegisterStartupScript(this.GetType(), "", "<script>alert('抱歉，该用户名为禁用账户，不能注册！');</script>");
                    //this.TextBox1.Text = "";
                    flag = "<DIV class=\"re\"><P class=\"tipsError\"><IMG class=\"iconError\" src=\"images/b.gif\" />抱歉，该用户名为禁用账户，不能注册！</P></DIV>";
                }
                sdrs.Close();
            }
            else
            {
                //this.ClientScript.RegisterStartupScript(this.GetType(), "", "<script>alert('抱歉，该用户名已经存在，不能使用！');</script>");
                //this.TextBox1.Text = "";
                flag = "<DIV class=\"re\"><P class=\"tipsError\"><IMG class=\"iconError\" src=\"images/b.gif\" />抱歉，该用户名已经存在，不能使用！</P></DIV>";
            }
            sdr.Close();
        }

        context.Response.Write(flag);
    }

    #endregion
}
