﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Collections.Generic;
using System.Xml;
using System.Text;
using System.Net;

/// <summary>
/// BaseGeneralPage 的摘要说明
/// </summary>
public abstract partial class BaseGeneralPage : Page
{
    private ConfigHelp config = new ConfigHelp();
    private ConfigHelp rootconfig = new ConfigHelp("~/");

    #region Properties
    protected abstract string WebSite { get; }
    protected string Code = "utf-8";
    #endregion
    #region Methods

    public void Verification()
    {
        string url =WebSite;

        //1111自定义。自行修改
        string[] keystr ={ "www.ceshi.com", "1111" };

        string key = Creat(keystr, Code, DataStandardTime());
        string jkey = rootconfig.Get("Key");
        //判段是否过期
        if (jkey.Length == 64)
        {
            //判段日期是否小于今天日期
            try
            {
                string sss = GetMD5("1111" + url, Code);
                string u1rl = rootconfig.Get("Key").Substring(0, 32);
                if (GetMD5("1111" + "www.ceshi.com", Code) != rootconfig.Get("Key").Substring(0, 32))
                {
                    writemsg();
                    return;
                }

                int StartTime = int.Parse(Decrypt(jkey.Substring(32, 32)));//结束时间

                int EndTime = int.Parse(DataStandardTime());//今天时间

                //这里可以去除 StartTime == EndTime;
                if (StartTime < EndTime)
                {
                    //if (key != jkey)
                    //{
                        writemsg();
                    //}
                }
            }
            catch
            {
                writemsg();
            }
        }
        else
        {
            writemsg();
        }
    }
    /// <summary>
    /// 输出信息
    /// </summary>
    /// <returns></returns>
    public static void writemsg()
    {
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.Write("<title>未授权版本 </title>");
        HttpContext.Current.Response.Write("未授权版本,购买正版请联系QQ：63196");
        HttpContext.Current.Response.End();

    }
    /// <summary>
    /// 加密算法
    /// </summary>
    /// <param name="Input"></param>
    /// <param name="endtime"></param>
    /// <returns></returns>
    public static string GetMD5(string Input, string endtime)
    {
        MD5 md5 = new MD5CryptoServiceProvider();
        byte[] t = md5.ComputeHash(Encoding.GetEncoding(endtime).GetBytes(Input));
        StringBuilder sb = new StringBuilder(32);
        for (int i = 0; i < t.Length; i++)
        {
            sb.Append(t[i].ToString("x").PadLeft(2, '0'));
        }
        return sb.ToString().ToUpper();
    }
    /// <summary>
    /// 获取时间
    /// </summary>
    /// <returns></returns>
    public static string DataStandardTime()
    {
        string contenthtml = DateTime.Now.ToString("yyyyMMdd");
        return contenthtml;
        //try
        //{
        //    string pageurl = "  http://www.88764.com/regtime.aspx";
        //    WebRequest request = WebRequest.Create(pageurl);
        //    WebResponse response = request.GetResponse();
        //    Stream resstream = response.GetResponseStream();
        //    StreamReader sr = new StreamReader(resstream, System.Text.Encoding.Default);
        //    contenthtml = sr.ReadToEnd().Replace("\r\n", "");
        //    return contenthtml;
        //}
        //catch
        //{
        //    return contenthtml;
        //}
    }
    //public static string DataStandardTime()
    //{
    //    string contenthtml = DateTime.Now.ToString("yyyyMMdd");
    //    try
    //    {
    //        string pageurl = " http://www.88764.com/regtime.aspx";
    //        WebRequest request = WebRequest.Create(pageurl);
    //        WebResponse response = request.GetResponse();
    //        Stream resstream = response.GetResponseStream();
    //        StreamReader sr = new StreamReader(resstream, System.Text.Encoding.Default);
    //        contenthtml = sr.ReadToEnd().Replace("\r\n", "");
    //        return contenthtml;
    //    }
    //    catch
    //    {
    //        return contenthtml;
    //    }
    //}

    /// <summary>
    /// 可自己修改参数
    /// </summary>
    /// <param name="Input"></param>
    /// <returns></returns>
    public static string[] BubbleSort(string[] Input)
    {
        int i, j;
        string temp;

        bool exchange;

        for (i = 0; i < Input.Length; i++)
        {
            exchange = false;

            for (j = Input.Length - 2; j >= i; j--)
            {
                if (System.String.CompareOrdinal(Input[j + 1], Input[j]) < 0)
                {
                    temp = Input[j + 1];
                    Input[j + 1] = Input[j];
                    Input[j] = temp;

                    exchange = true;
                }
            }

            if (!exchange)
            {
                break;
            }
        }
        return Input;
    }
    /// <summary>
    /// 创建
    /// </summary>
    /// <param name="keystr">KEY</param>
    /// <param name="code">code</param>
    /// <param name="endtime">自定义</param>
    /// <returns></returns>
    public static string Creat(string[] keystr, string code, string endtime)
    {
        int i;
        string[] Sortedstr = BubbleSort(keystr);
        StringBuilder prestr = new StringBuilder();

        for (i = 0; i < Sortedstr.Length; i++)
        {
            if (i == Sortedstr.Length - 1)
            {
                prestr.Append(Sortedstr[i]);

            }
            else
            {
                prestr.Append(Sortedstr[i]);
            }

        }

        prestr.Append(endtime);
        string sign = GetMD5(prestr.ToString(), code);
        return sign + Encrypt(endtime);
    }

    #endregion
    #region 结束时间加密/解密算法.
    /// <summary> 
    /// 加密字符串 
    /// </summary> 
    /// <param name="pToEncrypt">待加密字符串</param> 
    /// <returns></returns> 
    public static string Encrypt(string pToEncrypt)
    {
        byte[] desKey = new byte[] { 0x16, 0x09, 0x14, 0x15, 0x07, 0x01, 0x05, 0x08 };
        byte[] desIV = new byte[] { 0x16, 0x09, 0x14, 0x15, 0x07, 0x01, 0x05, 0x08 };
        DESCryptoServiceProvider des = new DESCryptoServiceProvider();
        try
        {
            byte[] inputByteArray = Encoding.Default.GetBytes(pToEncrypt);
            des.Key = desKey;
            des.IV = desIV;
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write);

            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();

            StringBuilder ret = new StringBuilder();
            foreach (byte b in ms.ToArray())
            {
                //Format as hex. 
                ret.AppendFormat("{0:X2}", b);
            }
            ret.ToString();
            return ret.ToString();
        }
        catch
        {
            return pToEncrypt;
        }
        finally
        {
            des = null;
        }
    }
    /// <summary> 
    /// 解密字符串 
    /// </summary> 
    /// <param name="pToDecrypt">待解密字符串</param> 
    /// <returns></returns> 
    public static string Decrypt(string pToDecrypt)
    {
        byte[] desKey = new byte[] { 0x16, 0x09, 0x14, 0x15, 0x07, 0x01, 0x05, 0x08 };
        byte[] desIV = new byte[] { 0x16, 0x09, 0x14, 0x15, 0x07, 0x01, 0x05, 0x08 };

        DESCryptoServiceProvider des = new DESCryptoServiceProvider();
        try
        {
            //Put the input string into the byte array. 
            byte[] inputByteArray = new byte[pToDecrypt.Length / 2];
            for (int x = 0; x < pToDecrypt.Length / 2; x++)
            {
                int i = (Convert.ToInt32(pToDecrypt.Substring(x * 2, 2), 16));
                inputByteArray[x] = (byte)i;
            }
            des.Key = desKey;
            des.IV = desIV;
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            StringBuilder ret = new StringBuilder();
            return System.Text.Encoding.Default.GetString(ms.ToArray());
        }
        catch
        {
            return pToDecrypt;
        }
        finally
        {
            des = null;
        }
    }
    #endregion
}
