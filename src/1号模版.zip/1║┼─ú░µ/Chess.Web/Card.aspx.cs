﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Chess.BLL.QPGameUserDBBLL;
using Chess.BLL.QPTreasureDBBLL;
using Chess.Models.QPTreasureDBModels;
using Chess.Models.QPGameUserDBModels;
using System.Data.SqlClient;

public partial class Card : System.Web.UI.Page
{
    AccountsInfoManager am = new AccountsInfoManager();
    GameCardNoInfoManager gm = new GameCardNoInfoManager();
    GameScoreInfoManager gam = new GameScoreInfoManager();
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["UserName"] == null)
        //{
        //    Response.Redirect("userPage.aspx");
        //}
    }

    public string UserMD5(string str, int code)
    {
        if (code == 16)
        {
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(str, "MD5").ToLower().Substring(8, 16);
        }
        else
        {
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(str, "MD5").ToLower();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (this.txtCode.Text != Session["ValidCode"].ToString())
        {
            this.lblMessage.Text = "验证码错误!";
            return;
        }
        else
        {
            if (this.txtUser1.Text != this.txtUser2.Text)
            {
                this.lblMessage.Text = "两次输入用户名不一直!";
                return;

            }
            else
            {
                string username = this.txtUser1.Text;
                bool druser = am.GetAccountsBe(username);
                if (druser != true)
                {
                    this.lblMessage.Text = "用户名不存在!";
                }
                else
                {
                    string cardno = this.txtcardno.Text;
                    bool cardBe = gm.GetCardNoBe(cardno);
                    if (cardBe != true)
                    {
                        this.lblMessage.Text = "卡号错误!";
                        return;
                    }
                    else
                    {
                        GameCardNoInfoModel gmodel = new GameCardNoInfoManager().GetGameCardNoInfoByCardNo(cardno);
                        if (gmodel.Nullity == true)
                        {
                            this.lblMessage.Text = "充值卡已被使用!";
                            return;
                        }
                        else
                        {
                            GameCardTmpInfoModel tmodel = new GameCardTmpInfoManager().GetCardPwdByCardNo(cardno);
                            GameCardTypeInfoModel tymodel = new GameCardTypeInfoManager().GetGameCardTypeInfoByID(gmodel.CardTypeID);
                            SqlDataReader _dr = Chess.DAL.DBHelper.QPTreasureDBHelper.GetDataReader("select * from GameCardNoInfo where Accounts='" + username + "'");
                            _dr.Read();
                            if (_dr.HasRows && tymodel.CardTitle == "新手卡")
                            {
                                this.lblMessage.Text = "你已经使用过新手卡!";
                                return;
                            }
                            else
                            {
                                if (gmodel.CardPass != UserMD5(this.txtcardpass.Text, 32))
                                {
                                    this.lblMessage.Text = "充值卡密码错误!";
                                    return;
                                }
                                else
                                {
                                    AccountsInfoModel accmodel = new AccountsInfoManager().GetAccountsInfoByName(username);
                                    
                                    GameScoreInfoModel gamemodel = new GameScoreInfoManager().GetGameScroseInfoByID(accmodel.UserID);
                                    int userid = accmodel.UserID;
                                    string usedate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                                    bool nullity = bool.Parse("True");
                                    gm.UpdateGameNoInfoByCardNo(cardno, nullity, usedate, userid, username);
                                    long InsureScore = long.Parse(gamemodel.InsureScore.ToString()) + tymodel.Score;
                                    gam.UpdateInsureScore(accmodel.UserID, InsureScore);


                                    if (accmodel.MemberOrder < tymodel.Memberorder)
                                    {
                                        int MemberOrder = tymodel.Memberorder;
                                        string MemberOverDate = DateTime.Now.AddDays(tymodel.OverDate).ToString("yyyy-MM-dd HH:mm:ss");
                                        am.UpdateMemberOrderByUserID(accmodel.UserID, MemberOrder, MemberOverDate);
                                        this.lblMessage.Text = "恭喜你,充值成功!";
                                        return;
                                    }
                                    else
                                    {
                                        string MemberOverDate = DateTime.Now.AddDays(tymodel.OverDate).ToString("yyyy-MM-dd HH:mm:ss");
                                        am.UpdateMemberOrderByUserID(accmodel.UserID, accmodel.MemberOrder, MemberOverDate);
                                        this.lblMessage.Text = "恭喜你,充值成功!";
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }
    }
}
