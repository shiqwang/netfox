﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;

public partial class ad_GameListAd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            UpdateUI();
        }

    }
    protected string url;
    protected string link;
    private void UpdateUI()
    {
        AdInfoModel adin = new AdInfoManager().GetAdInfo();
        url = adin.Ad2Url;
        link = adin.Ad2Link;
    }
}
