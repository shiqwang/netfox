﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;

public partial class ad_rolltxt : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            UpdateUI();
        }
    }
    protected string color;
    private void UpdateUI()
    {
        AdInfoModel adin = new AdInfoManager().GetAdInfo();
        this.litTxt.Text = adin.AdRoll.ToString();
        color = adin.AdRollColor.ToString();
    }
}
