﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.MobileControls;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;
using Chess.Models.QPGameUserDBModels;
using Chess.BLL.QPGameUserDBBLL;


public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {

            Upload();
            listNew();
            Loveliness();
            HotPic();
            
            

        }
    }
    private void listNew()
    {
        List<HdModel> list = new List<HdModel>();
        list = new HdManager().GetHdListByTypeID(8);
        listNews.DataSource = list;
        listNews.DataBind();
    }
    private void Loveliness()
    {
        List<AccountsInfoModel> list = new List<AccountsInfoModel>();
        list = new AccountsInfoManager().GetLoveliness();
        rptLove.DataSource = list;
        rptLove.DataBind();
    }
    private void HotPic()
    {
        List<HotPicmodel> list = new List<HotPicmodel>();
        list = new HotPicManager().GetHotPic();
        rptHotPic.DataSource = list;
        rptHotPic.DataBind();

    }
    private void Upload()
    {
        ContactModel cont = new ContactManager().GetContact();
        keywords = cont.keyword;
        description = cont.Description;
        tit = cont.Co_Name + " " + cont.Co_Url; 
    }
    protected string keywords ;
    protected string description ;
    protected string tit;
    
    
}
