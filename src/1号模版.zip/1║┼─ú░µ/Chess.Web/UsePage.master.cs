﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.BLL.QPGameUserDBBLL;
using Chess.Models.QPGameUserDBModels;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;

public partial class UsePage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            UserNull();
            Upload();
        }
    }
    private void Upload()
    {
        ContactModel cont = new ContactManager().GetContact();
        keywords = cont.keyword;
        description = cont.Description;

    }
    protected string keywords;
    protected string description;
    private void UserNull()
    {
        if (Session["UserName"] != null)
        {
            
            labUserName.Text = "" + Session["UserName"];
            AccountsInfoModel accountsinfomodel = new AccountsInfoManager().GetAccountsInfoByName(labUserName.Text);
            this.urlpassword.Text = accountsinfomodel.LogonPass.ToString();
            this.labGameID.Text = accountsinfomodel.GameID.ToString();
            if (accountsinfomodel.MemberOrder == 0)
            {
                this.labVip.Text = "普通会员";
            }
            if (accountsinfomodel.MemberOrder == 1)
            {
                this.labVip.Text = "红钻会员";
            }
            if (accountsinfomodel.MemberOrder == 2)
            {
                this.labVip.Text = "蓝钻会员";
            }
            if (accountsinfomodel.MemberOrder == 3)
            {
                this.labVip.Text = "黄钻会员";
            }
            if (accountsinfomodel.MemberOrder == 4)
            {
                this.labVip.Text = "紫钻会员";
            }
        }
        else
        {
            Response.Redirect("userPage.aspx");
        }
    }
}
