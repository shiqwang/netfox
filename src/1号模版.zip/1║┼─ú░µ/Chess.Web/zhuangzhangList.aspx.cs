﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.Models.QPTreasureDBModels;
using Chess.BLL.QPTreasureDBBLL;
using System.Collections;
using Wuqi.Webdiyer;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;

public partial class zhuangzhangList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] == null)
        {
            Response.Redirect("Login.aspx");
            return;
        }
        Upload();
        UpdateUI();


    }

    private void Upload()
    {
        ContactModel cont = new ContactManager().GetContact();

        this.tit.Text = cont.Co_Name + " " + cont.Co_Url;
    }

    private void UpdateUI()
    {
        string username = "" + Session["Username"];
        List<RecordInsureModel> list = new List<RecordInsureModel>();
        list = new RecordInsureManager().GetRecordInsureByName(username);
        Repeater1.DataSource = PagedData(list, AspNetPager1);
        Repeater1.DataBind();
    }
    protected void AspNetPager1_PageChanged(object sender, EventArgs e)
    {
        UpdateUI();
    }
    public static PagedDataSource PagedData(IList list, AspNetPager aspNetPager)
    {
        aspNetPager.RecordCount = list.Count;
        PagedDataSource page = new PagedDataSource();
        page.DataSource = list;
        page.AllowPaging = true;
        page.PageSize = aspNetPager.PageSize;
        page.CurrentPageIndex = aspNetPager.CurrentPageIndex - 1;

        return page;
    }
}
