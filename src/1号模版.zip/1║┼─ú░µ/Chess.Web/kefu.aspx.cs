﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;

public partial class kefu : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Upload();
        }

    }
    private void Upload()
    {
        ContactModel cont = new ContactManager().GetContact();
        
        this.tit.Text = cont.Co_Name + " " + cont.Co_Url;
        this.qq1.Text = cont.QQ;
        this.qq2.Text = cont.QQ2;
        this.tel.Text = cont.Tel;
    }
   
    
}
