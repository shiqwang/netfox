﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;


public partial class leftbox : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ListHelp();
            Upload();
        }
    }
    private void ListHelp()
    {
        List<HdModel> list = new List<HdModel>();
        list = new HdManager().GetHdListByTypeIDLeft(4);
        rptHelp.DataSource = list;
        rptHelp.DataBind();
    }
    private void Upload()
    {
        ContactModel cont = new ContactManager().GetContact();

        this.qq1.Text = cont.QQ;
        this.qq2.Text = cont.QQ2;
        this.tel.Text = cont.Tel;
    }
}
