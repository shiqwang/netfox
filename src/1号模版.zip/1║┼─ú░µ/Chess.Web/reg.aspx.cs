﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.BLL.QPGameUserDBBLL;
using Chess.Models.QPGameUserDBModels;
using Chess.BLL.QPTreasureDBBLL;
using Chess.Models.QPTreasureDBModels;
using System.Configuration;
using Chess.BLL.Command;
using System.Text.RegularExpressions;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;

public partial class reg : System.Web.UI.Page
{
    private readonly AccountsInfoManager accManager = new AccountsInfoManager();
    private readonly G_Communications qqManager = new G_Communications();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
            Updata();
            Upload();
           

        }
    }
    private void Upload()
    {
        ContactModel cont = new ContactManager().GetContact();

        this.tit.Text = cont.Co_Name + " " + cont.Co_Url;
    }
    private void Updata()
    {
        tb_tjr.Text = Request.QueryString["UserName"];
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            ValidateAccount();
            ValidateCode();
            ValidateOtherInfo();
            ValidateInsurePW();
            ValidateQQ();
            ValidateTjr();

            //ValidateRegAccount();
            ValidatePhone();

        }
        catch (Exception exception)
        {
            Util.Alert(this, exception.Message);
            return;
        }

        accManager.InsertAccountsInfo(SetAccountInfo());
        AccountsInfoModel accountsModel = accManager.GetAccountsInfoByName(tb_loginname.Text);


        UpdateGameID(false, accountsModel.UserID);
        new GameScoreInfoManager().InsertGameScoreInfo(SetGameModel(
                                                                    accountsModel.UserID,
                                                                    accountsModel.RegisterDate));
        //qqManager.InsertG_Communications(SetQQ(accountsModel.UserID));

        Session["UserName"] = tb_loginname.Text;
        Util.AlertAndRedirect(this, "注册成功", "UserCenter.aspx");
    }
    private AccountsInfoModel SetAccountInfo()
    {
        AccountsInfoModel accModel = new AccountsInfoModel();
        accModel.Accounts = tb_loginname.Text;

        accModel.Gender = int.Parse(RadioButtonList1_0.SelectedValue);
        accModel.LogonPass = Util.UserMD5(tb_password.Text, MD5Model.Model32);
        accModel.InsurePass = Util.UserMD5(tb_InsurePW2.Text, MD5Model.Model32);
        accModel.LastLogonDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        accModel.C_IDNO = tb_cardno.Text;
        accModel.QQ = txtQQ.Text;
        accModel.SpreaderID = string.IsNullOrEmpty(tb_tjr.Text)
            ? "0" : tb_tjr.Text;
        accModel.RegisterIP = Util.GetIP(this);
        accModel.LastLogonIP = Util.GetIP(this);
        accModel.RegAccounts = tb_loginname.Text;
        accModel.WebLogonTimes = 1;
        accModel.Phone = tb_Mobile.Text;
        accModel.UserRight = 28;
        accModel.RegisterDate = accModel.LastLogonDate;
        accModel.LoginDateTime = accModel.LastLogonDate;
        accModel.FaceID = int.Parse(hf_faceID.Value);
        //accModel.InsurePass = string.IsNullOrEmpty(tb_password.Text)
        //                              ? accModel.LogonPass
        //                              : Util.UserMD5(tb_password.Text, MD5Model.Model32);
        return accModel;
    }
    private GameScoreInfoModel SetGameModel(int userID, string time)
    {
        long score = string.IsNullOrEmpty(tb_tjr.Text) ? long.Parse(ConfigurationManager.AppSettings["score"]) : long.Parse(ConfigurationManager.AppSettings["scorePromotion"]);
        GameScoreInfoModel model = new GameScoreInfoModel();
        model.UserID = userID;
        model.Score = score;
        model.RegisterIP = Util.GetIP(this);
        model.RegisterDate = time;
        model.LastLogonDate = time;
        model.LastLogonIP = model.RegisterIP;
        return model;
    }

    private void UpdateGameID(bool isPromotion, int userID)
    {
        int gameID = isPromotion
                             ? new Random().Next(99999, 999999) + userID
                             : new Random().Next(userID, 600000) + 99999;

        accManager.UpdateGameID(tb_loginname.Text, new RegCom()._isGoodHao(gameID));
    }

    #region 验证方法

    private void ValidateAccount()
    {
        if (string.IsNullOrEmpty(tb_loginname.Text))
            throw new ApplicationException("用户名不能为空");

        //if (tb_loginname.Text.Length < 4 || tb_loginname.Text.Length > 12)
        //    throw new ApplicationException("用户名长度在2-12个字符内");

        //Regex regex = new Regex("^[0-9A-Za-z_]{4,12}$");
        //if (!regex.IsMatch(tb_loginname.Text))
        //    throw new ApplicationException("用户名必须是4-12字符内,a-z,0-9以及下划线");

        if (accManager.IsReg(tb_loginname.Text))
            throw new ApplicationException("用户名已经被使用，请更换用户名");

        if (accManager.isIP(Request.UserHostAddress))
            throw new ApplicationException("5分钟内只能注册一次");

        ConfineContentModel confine = new ConfineContentManager().GetConfineContentByString(tb_loginname.Text);
        if (!string.IsNullOrEmpty(confine.String))
            throw new ApplicationException("该用户名为禁用账号，不能注册");
    }
    private void ValidateTjr()
    {
        if (!string.IsNullOrEmpty(tb_tjr.Text))
        {
            if (!accManager.IsReg(tb_tjr.Text))
            {
                throw new ApplicationException("推荐人不存在");
            }
        }
    }
    //private void ValidateRegAccount()
    //{
    //    if (string.IsNullOrEmpty(txtRegAcc.Text)) return;

    //    Regex regex = new Regex("^[0-9A-Za-z_\u4e00-\u9fa5]{4,16}$");
    //    if (!regex.IsMatch(txtRegAcc.Text))
    //    {
    //        throw new ApplicationException("昵称4-16字符内,可以是a-z,0-9,下划线汉字");
    //    }

    //    if (accManager.HasRegAccount(txtRegAcc.Text))
    //    {
    //        throw new ApplicationException("昵称已被注册");
    //    }


    //}

    private void ValidatePhone()
    {
        if (string.IsNullOrEmpty(tb_Mobile.Text))
            return;

        Regex regex = new Regex(@"\d{11}");
        if (!regex.IsMatch(tb_Mobile.Text))
            throw new ApplicationException("手机格式错误");
    }

    private void ValidateQQ()
    {
        if (string.IsNullOrEmpty(txtQQ.Text))
            return;

        if (Regex.Matches(@"^[1-9]\d{4,10}$", txtQQ.Text).Count > 0)
            throw new ApplicationException("QQ输入有误");
    }

    private void ValidateCode()
    {
        if (Session["ValidCode"] == null)
            throw new ApplicationException("验证码出错");

        if (string.IsNullOrEmpty(tb_code.Text))
            throw new ApplicationException("请输入验证码");

        if (tb_code.Text.ToLower() != Session["ValidCode"].ToString().ToLower())
            throw new ApplicationException("验证码输入错误");
    }

    private void ValidateOtherInfo()
    {

        if (string.IsNullOrEmpty(tb_password.Text) || string.IsNullOrEmpty(tb_password2.Text))
            throw new ApplicationException("密码不能为空");

        if (tb_password.Text != tb_password2.Text)
            throw new ApplicationException("两次密码输入不一致");

        if (tb_password.Text.Length < 8)
            throw new ApplicationException("密码长度过短");

        if (!string.IsNullOrEmpty(tb_password.Text) || !string.IsNullOrEmpty(tb_password2.Text))
        {
            if (tb_password.Text != tb_password2.Text)
                throw new ApplicationException("两次输入密码不一致");
        }
    }
    private void ValidateInsurePW()
    {
        if (string.IsNullOrEmpty(tb_InsurePW.Text) || string.IsNullOrEmpty(tb_InsurePW2.Text))
            throw new ApplicationException("二级密码不能为空");
        if (tb_InsurePW.Text != tb_InsurePW2.Text)
            throw new ApplicationException("两次密码输入不一致");
        if (!string.IsNullOrEmpty(tb_InsurePW.Text) || !string.IsNullOrEmpty(tb_InsurePW2.Text))
        {
            if (tb_InsurePW.Text != tb_InsurePW2.Text)
                throw new ApplicationException("两次输入密码不一致");
        }
    }



    #endregion
}
