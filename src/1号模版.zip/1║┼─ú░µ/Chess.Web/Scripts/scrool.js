﻿

var isDebug = false;

var isIE = $.browser.msie;
var isIE6 = $.browser.msie && $.browser.version == "6.0";

function MarqueeScroll(params)
{
	// params' key: selector, unit, direction, speed, delay, group, unitFix, auto, cbScroll, cbPrev, cbNext
	// old param: selector, direction, speed, delay, left, leftFix, groupCount, cbScroll, auto
	with (params)
	{
		this.scrollSelector = (typeof(selector) != "undefined" && selector) ? selector : "";
		this.scrollUnit = (typeof(unit) != "undefined" && unit) ? unit : 0;	// width or height for wrapper
		// 1 for up, 2 for right, 3 for down, 4 for left
		this.scrollDirection = (typeof(direction) != "undefined" && direction) ? direction : 4;
		this.scrollSpeed = (typeof(speed) != "undefined" && speed) ? speed : "normal";
		this.scrollDelay = (typeof(delay) != "undefined" && delay) ? delay : 5000;
		this.scrollUnitFix = (typeof(unitFix) != "undefined" && unitFix) ? unitFix : 0;
		this.scrollGroupCount = (typeof(group) != "undefined" && group) ? group : 1;
		this.scrollCallBack = (typeof(cbScroll) != "undefined" && cbScroll) ? cbScroll : null;
		this.scrollPrevCallBack = (typeof(cbPrev) != "undefined" && cbPrev) ? cbPrev : null;
		this.scrollNextCallBack = (typeof(cbNext) != "undefined" && cbNext) ? cbNext : null;
		this.autoScroll = (typeof(auto) != "undefined") ? auto : true;
		this.scrollParams = params;

		this.scrollObject = null;
		this.scrollItemCount = 0;
		this.scrollCurrentItem = 0;
		this.scrollCurrentUnit = 0;
		this.scrollDestUnit = 0;
		this.scrollInterval = null;
	}
}

function scrollInit(marqueeScroll)
{
	if (!marqueeScroll) return;
	with (marqueeScroll)
	{
		if (!scrollSelector || !scrollSpeed || !scrollDelay || !scrollUnit)
			return;
		scrollObject = $(scrollSelector);
		var ul = $("ul", scrollObject);
		var li = $("li", ul);
		scrollItemCount = li.length;
		if (scrollItemCount == 0) return;
		// append blank item
		if (scrollItemCount % scrollGroupCount != 0)
		{
			for (var i = 0; i < scrollGroupCount - scrollItemCount % scrollGroupCount; i++)
			{
				ul.append("<li></li>");
			}
		}
		// clone first page
		if (autoScroll)
		{
			for (var i = 0; i < scrollGroupCount; i++)
			{
				ul.append($(li[i]).clone());
			}
		}
		scrollItemCount = Math.ceil(scrollItemCount / scrollGroupCount);
		if (scrollItemCount < 2)
			return;
		if ((scrollDirection & 1) != 1)
			ul.width((scrollUnit + scrollUnitFix) * (scrollItemCount + 1));
		
		if (autoScroll)
			scrollInterval = setInterval(function() { startScroll(marqueeScroll); }, scrollDelay);
	}
}

function startScroll(marqueeScroll)
{
	if (!marqueeScroll) return;
	with (marqueeScroll)
	{
		if (scrollCurrentUnit == scrollDestUnit)
		{
			scrollCurrentItem++;
			if (scrollCurrentItem > scrollItemCount)
			{
				scrollCurrentItem = 1;
				if ((scrollDirection & 1) != 1)
					scrollObject.scrollLeft(0);
				else
					scrollObject.scrollTop(0);
			}
			scrollDestUnit = scrollUnit * scrollCurrentItem + scrollCurrentItem * scrollUnitFix;
		}
		doScrolling(marqueeScroll);
	}
}

function doScrolling(marqueeScroll, cbOnce)
{
	if (!marqueeScroll) return;
	with (marqueeScroll)
	{
		var config = {scrollLeft: scrollDestUnit};
		if ((scrollDirection & 1) == 1)
			config = {scrollTop: scrollDestUnit};
		scrollObject.animate(config, scrollSpeed, function()
			{
				scrollCurrentUnit = scrollDestUnit;
				if (scrollCallBack)
					scrollCallBack(scrollCurrentItem);
				if (cbOnce)
					cbOnce(scrollCurrentItem);
			});
	}
}

function scrollPrev(marqueeScroll)
{
	if (!marqueeScroll) return;
	with (marqueeScroll)
	{
		if (autoScroll)
			clearInterval(marqueeScroll.scrollInterval);
		else if (scrollCurrentItem == 0)
			return;
		scrollObject.stop();
		
		scrollCurrentItem--;
		if (scrollCurrentItem < 0)
		{
			scrollCurrentItem = scrollItemCount - 1;
			if ((scrollDirection & 1) == 1)
				scrollObject.scrollTop(scrollUnit * scrollItemCount - 1);
			else
				scrollObject.scrollLeft(scrollUnit * scrollItemCount - 1);
		}
		scrollDestUnit = scrollUnit * scrollCurrentItem;

		doScrolling(marqueeScroll, scrollPrevCallBack);
		
		if (autoScroll)
			scrollInterval = setInterval(function() { startScroll(marqueeScroll); }, scrollDelay);
	}
}

function scrollNext(marqueeScroll)
{
	if (!marqueeScroll) return;
	with (marqueeScroll)
	{
		if (autoScroll)
			clearInterval(scrollInterval);
		else if (scrollCurrentItem + 1 >= scrollItemCount)
			return;
		scrollObject.stop();

		scrollCurrentItem++;
		var index = scrollCurrentItem;
		if (scrollCurrentItem > scrollItemCount - 1)
			index = scrollCurrentItem - scrollItemCount;
		if (scrollCurrentItem > scrollItemCount)
		{
			scrollCurrentItem = 1;
			if ((scrollDirection & 1) == 1)
				scrollObject.scrollTop(0);
			else
				scrollObject.scrollLeft(0);
		}
		scrollDestUnit = scrollUnit * scrollCurrentItem;

		doScrolling(marqueeScroll, scrollNextCallBack);
		
		if (autoScroll)
			scrollInterval = setInterval(function() { startScroll(marqueeScroll); }, scrollDelay);
	}
}

function scrollIndex(marqueeScroll, index)
{
	if (!marqueeScroll) return;
	with (marqueeScroll)
	{
		if (autoScroll)
			clearInterval(scrollInterval);
		scrollObject.stop();

		scrollCurrentItem = index;
		scrollDestUnit = scrollUnit * scrollCurrentItem;

		doScrolling(marqueeScroll);
		
		if (autoScroll)
			scrollInterval = setInterval(function() { startScroll(marqueeScroll); }, scrollDelay);
	}
}

function scrollChangeIndex(marqueeScroll, index)
{
	if (!marqueeScroll) return;
	with (marqueeScroll)
	{
		if (autoScroll)
			clearInterval(scrollInterval);
		scrollObject.stop();

		scrollCurrentItem = index;
		scrollDestUnit = scrollUnit * scrollCurrentItem;

		if ((scrollDirection & 1) == 1)
			scrollObject.scrollTop(scrollDestUnit);
		else
			scrollObject.scrollLeft(scrollDestUnit);
		scrollCurrentUnit = scrollDestUnit;
		if (scrollCallBack)
			scrollCallBack(scrollCurrentItem);
		
		if (autoScroll)
			scrollInterval = setInterval(function() { startScroll(marqueeScroll); }, scrollDelay);
	}
}

function scrollStop(marqueeScroll)
{
	if (!marqueeScroll) return;
	with (marqueeScroll)
	{
		clearInterval(scrollInterval);
		scrollObject.stop();
	}
}


$(document).ready(function scrollObjecjInit()
{
	// 大眼睛
	var bigeyeScroll = new MarqueeScroll({selector: "#bigeye .scrollWrapper", unit: 476, cbScroll: function(index) {
		var items = $("#bigeye .scrollLocat li");
		items.removeClass("current");
		$(items[index >= 5 ? 0 : index]).addClass("current");
	}});
	$("#bigeye .scrollLocat li").each(function(index, element)
	{
		var li = $(element);
		if (index == 0) li.addClass("current");
		$("a", li).click(function(){ scrollIndex(bigeyeScroll, index); });
	});
	scrollInit(bigeyeScroll);
});











