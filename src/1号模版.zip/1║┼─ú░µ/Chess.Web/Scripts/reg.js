﻿//$(function() {
//    $(".input0").focus(function() {
//		$(this).removeClass("input0");
//		$(this).addClass("input1");
//	});
//    $(".input0").blur(function() {
//		$(this).removeClass("input1");
//		$(this).addClass("input0");
//	});
//}); 

function judgeString(str){
 	var len = str.length;
	var tt=0;
    for(var i=0;i<len;i++){
       var txt = str.charCodeAt(i);
       if(txt>128){     //ascii码大于128的是汉字
          tt= tt+2; 
       } else{
          tt= tt+1;
       }
    }
 	return tt;
}

function showxieyi(id){
	 if(getObj(id).style.display==''){
		 getObj(id).style.display='none';}
	 else{getObj(id).style.display='';}
}
function trimspace(obj)
{
	String.prototype.Trim = function()
	{
		return this.replace(/(^\s*)|(\s*$)/g, "");
	}			
	obj.value = obj.value.Trim();
}
 function select_face(obj,choice){
	var obj_img=document.createElement("img");
	obj_img.src=obj.src;	
	var my_text=getObj("img1").appendChild(obj_img);//显示表情道输入区域
     getObj('boy').style.display="none";
 getObj('faceid').value=choice.toString();
		}
		 function select_face1(obj,choice){
	var obj_img=document.createElement("img");
	obj_img.src=obj.src;
	
	var my_text=getObj("img2").appendChild(obj_img);//显示表情道输入区域
     getObj("girl").style.display="none";
		 getObj('faceid').value=choice.toString();
		}
		 function check_radio(){
var chkObjs = document.getElementsByName("sex");
if(chkObjs[0].checked)
{

getObj("boy").style.display="";
getObj("girl").style.display="none";
getObj("img1").innerHTML="";
getObj("img2").innerHTML="";
getObj('sexid').value="0";
}
if(chkObjs[1].checked)
{
getObj("boy").style.display="none";
getObj("girl").style.display="";
getObj("img1").innerHTML="";
getObj("img2").innerHTML="";
getObj('sexid').value="1";
}
}
function checkUser()
{
trimspace(getObj("txtLoginId"));
 var strname=getObj("txtLoginId").value;
 trimspace(getObj("txtLoginId"));
 var str=getObj("txtLoginId").value;
 if(str.length==0)
 {
 getObj("mess1").innerHTML="<img src='images/exclamation.png'/>用户名不能为空";
 getObj("message1").style.display="none";
 return false;
 }
 if(judgeString(str)>str.length)
 {
 getObj("mess1").innerHTML="<img src='images/exclamation.png'/>用户名不能含有中文";
 getObj("message1").style.display="none";
 return false;
 }
 if(str.length<4||str.length>12)
 {
 getObj("mess1").innerHTML="<img src='images/exclamation.png'/>用户名长度为4-12位";
 getObj("message1").style.display="none";
 return false;
 }	
 else
 {
	var xmlHttp=ajaxFunction();
	if(xmlHttp!=null)
	{var  Digital=new  Date();
	Digital=Digital+40000;
	xmlHttp.open("get", "Check.aspx?UserName="+escape(str)+"&k="+Digital, true)
	xmlHttp.onreadystatechange=requestUser;
	xmlHttp.send(null);
	}

   function requestUser()
   {
    if(xmlHttp.readyState == 4)
    
    {if(xmlHttp.status==200)
        {if(xmlHttp.responseText==1)
        { getObj("message1").style.display="";
        getObj("message1").innerHTML="<img src='images/accept.png'/>该用户名可用";
        getObj("mess1").innerHTML="";
        }
        else
        {
        getObj("mess1").innerHTML=xmlHttp.responseText;
         getObj("message1").style.display="none";
         }
        }
    }

   }
}
 
}
function checkNickName()
{

trimspace(getObj("txtLoginId"));
 var strname=getObj("txtLoginId").value;
trimspace(getObj("txtUserName"));
 var str=getObj("txtUserName").value;
 if(str.length==0)
 {
 getObj("mess2").innerHTML="<img src='images/exclamation.png'/>用户昵称不能为空";
 getObj("message2").style.display="none";
 return false;
 }
 if(str==strname)
 {
 getObj("mess2").innerHTML="<img src='images/exclamation.png'/>昵称不能与用户名相同";
 getObj("message2").style.display="none";
 return false;
 }
if(judgeString(str)>str.length&&judgeString(str)>16)
{
 getObj("mess2").innerHTML="<img src='images/exclamation.png'/>中文等于2个字符！";
 getObj("message2").style.display="none";
 return false;
}
if(judgeString(str)<4||judgeString(str)>16)
{
 getObj("mess2").innerHTML="<img src='images/exclamation.png'/>昵称长度为4-16位！";
 getObj("message2").style.display="none";
 return false;
}
else
{
var xmlHttp=ajaxFunction();
	if(xmlHttp!=null)
	{var  Digital=new  Date();
	Digital=Digital+40000;
	xmlHttp.open("get", "Check.aspx?nickName="+escape(str)+"&k="+Digital, true)
	xmlHttp.onreadystatechange=requestNickName;
	xmlHttp.send(null);
	}

   function requestNickName()
   {
    if(xmlHttp.readyState == 4)
    
    {if(xmlHttp.status==200)
        {
        if(xmlHttp.responseText==1)
        {getObj("message2").style.display="";
        getObj("message2").innerHTML="<img src='images/accept.png'/>该用户昵称可用";
         getObj("mess2").innerHTML="";
        }
        else
        {
        getObj("mess2").innerHTML=xmlHttp.responseText;
         getObj("message2").style.display="none";
         }
        }
    }

   }
}
}
function isnumber(pass)
{
var reg=/^[0-9]*$/;
if(reg.test(pass))
{
return true;
}
else
{
return false;
}
}
 function checkPass1()
     {
      trimspace(getObj("txtPassword_1"));
      var str=getObj("txtPassword_1").value;
        if(str.length==0)
      {
   
      getObj("mess3").innerHTML="<img src='images/exclamation.png'/>密码不能为空";
      getObj("message3").style.display="none";
      return false;
      }
      if(str.length<8||str.length>12)
      {
      
         getObj("mess3").innerHTML="<img src='images/exclamation.png'/>密码长度为8-12位";
          getObj("message3").style.display="none";
      return false;
     }
//     if(isnumber(str))
//     {
//     getObj("mess3").innerHTML="<img src='images/exclamation.png'/>密码不能只是纯数字";
//          getObj("message3").style.display="none";
//     }
//     else
//     {
      getObj("mess3").innerHTML="";
          getObj("message3").style.display="none";
      return false;
//     }
     }
  function checkPass2()
     { 
     trimspace(getObj("txtPassword_2"));
      var str=getObj("txtPassword_2").value;
   
        if(str!=getObj("txtPassword_1").value)
      {
   
      getObj("mess4").innerHTML="<img src='images/exclamation.png'/>密码不一致";
     getObj("message4").style.display="none";
    
      return false;
      }
      else
      {
       getObj("mess4").innerHTML="";
       getObj("message4").style.display="none";
    
      return false;
      }
     
     }
      function checkPass21()
     {
    
      trimspace(getObj("Password1"));
      var str=getObj("Password1").value;
        if(str.length==0)
      {
   
      getObj("mess5").innerHTML="<img src='images/exclamation.png'/>二级密码不能为空！";
      getObj("message5").style.display="none";
      return false;
      }
      if(str.length<6||str.length>12)
      {
      
         document.getElementById("mess5").innerHTML="<img src='images/exclamation.png'/>密码长度为6-12位！";
          document.getElementById("message5").style.display="none";
      return false;
     }
      if(str==getObj("txtPassword_1").value)
      {
       getObj("mess5").innerHTML="<img src='images/exclamation.png'/>不能与登录密码相同！";
        getObj("message5").style.display="none";
    
      return false;
      }
     else
     {
      getObj("mess5").innerHTML="";
          getObj("message5").style.display="none";
      return false;
     }
     }
     function checkPass22()
     {
    
       trimspace(getObj("Password2"));
      var str=getObj("Password2").value;
     
        if(str!=getObj("Password1").value)
      {
   
      getObj("mess6").innerHTML="<img src='images/exclamation.png'/>密码不一致！";
      getObj("message6").style.display="none";
    
      return false;
      }
      else
      {
       getObj("mess6").innerHTML="";
       getObj("message6").style.display="none";
    
      return false;
      }
     
     }
function checkPermit()
{
 trimspace(getObj("permit"));
 var str=getObj("permit").value;
 if(str.length==0)
 {
 getObj("mess7").innerHTML="<img src='images/exclamation.png'/>身份证号必填";
       getObj("message7").style.display="none";
    
      return false;
 }
 else
 {
 getObj("message7").style.display="none";
     getObj("mess7").innerHTML="";
      return false;
 }
}
function checkqq()
{
 trimspace(getObj("QQ"));
 var str=getObj("QQ").value;
 if(str.length==0)
 {
 getObj("mess9").innerHTML="<img src='images/exclamation.png'/>QQ号码必填";
       getObj("message9").style.display="none";
    
      return false;
 }
 if(str.length<4||str.length>12)
 {
 getObj("mess9").innerHTML="<img src='images/exclamation.png'/>QQ号码在4-10位数之间";
       getObj("message9").style.display="none";
    
      return false;
 }
 else
 {
 getObj("message9").style.display="none";
     getObj("mess9").innerHTML="";
      return false;
 }
}

function isRightPhone(phone) {
   
     var reg0=/^13\d{9,9}$/;   //130--139
     var reg1=/^15\d{9,9}$/;   //15
     var reg2=/^18\d{9,9}$/;   //18
     
     var my=false;
     if (reg0.test(phone))my=true;
     if (reg1.test(phone))my=true;
     if (reg2.test(phone))my=true; 
     
       if(!my)
           return false;
       else
           return true;
}
function checkPhone()
{
trimspace(getObj("phone"));
 var str=getObj("phone").value;
 if(str.length==0)
 {
 getObj("mess8").innerHTML="<img src='images/exclamation.png'/>手机号必填";
       getObj("message8").style.display="none";
    
      return false;
 }
 if(!isRightPhone(str))
 {
  getObj("mess8").innerHTML="<img src='images/exclamation.png'/>手机号错误";
       getObj("message8").style.display="none";
    
      return false;
 }
 else
 {
 getObj("mess8").innerHTML="";
 getObj("message8").style.display="none";
 }
}

 function select_face(obj,choice){
	var obj_img=document.createElement("img");
	obj_img.src=obj.src;	
	var my_text=getObj("img1").appendChild(obj_img);//显示表情道输入区域
     getObj('boy').style.display="none";
 getObj('faceid').value=choice.toString();
		}
		 function select_face1(obj,choice){
	var obj_img=document.createElement("img");
	obj_img.src=obj.src;
	
	var my_text=getObj("img2").appendChild(obj_img);//显示表情道输入区域
     getObj("girl").style.display="none";
		 getObj('faceid').value=choice.toString();
		}
		
function register()
{if(!getObj("checkxieyi").checked)
{
alert("请先同意注册协议！");
return false;
}
trimspace(getObj("txtLoginId"));
   var name=getObj("txtLoginId").value;
    trimspace(getObj("txtPassword_1"));
   var pass=getObj("txtPassword_1").value;
    trimspace(getObj("txtPassword_2"));
   var pass1=getObj("txtPassword_2").value;
    trimspace(getObj("txtVadlitor"));
   var ma=getObj("txtVadlitor").value;
    trimspace(getObj("Password1"));
   var pass2=getObj("Password1").value;
   trimspace(getObj("Password2"));
   var pass3=getObj("Password2").value;
   trimspace(getObj("permit"));
   var permit=getObj("permit").value;
   trimspace(getObj("phone"));
   var phone=getObj("phone").value;
   var sexid=getObj("sexid").value;
   var faceid=getObj("faceid").value;
   var qq = getObj("QQ").value;
   var anwser=1;
   var tjr = getObj("tjr").value;
var xmlHttp=ajaxFunction();
	if(xmlHttp!=null)
	{var  Digital=new  Date();
	Digital=Digital+40000;
	xmlHttp.open("get", "Check.aspx?name=" + escape(name)  + "&pass1=" + escape(pass) + "&pass=" + escape(pass1) + "&pass2=" + escape(pass2) + "&pass3=" + escape(pass3) + "&permit=" + escape(permit) + "&ma=" + escape(ma) + "&phone=" + escape(phone) + "&sexid=" + sexid + "&faceid=" + faceid + "&qq=" + qq + "&anwser=" + anwser + "&tjr=" + escape(tjr) + "&k=" + Digital, true)
	xmlHttp.onreadystatechange=requestNickName;
	xmlHttp.send(null);
	
	}

   function requestNickName()
   {
    if(xmlHttp.readyState == 4)
    
    {if(xmlHttp.status==200)
        {if(xmlHttp.responseText==1)
        {
        window.location.href="userRegsucess.aspx";
        }
        else
        {
        alert(xmlHttp.responseText);
        getObj("vadimg").src="VerifyCode.aspx?"+(new Date().getTime());
        }
        }
    }

   }

}
function checkanswer()
{getObj("question").style.display='';
getObj("secanswer").value='';
  var xmlHttp=ajaxFunction();
	if(xmlHttp!=null)
	{var  Digital1=new  Date();
	
	var Digital=Digital1.getMinutes();
	xmlHttp.open("get", "Check.aspx?action=anwser&digital="+Digital, true)
	xmlHttp.onreadystatechange=requestquestion;
	xmlHttp.send(null);
	}
	function requestquestion()
	{if(xmlHttp.readyState == 4)
	{
	if(xmlHttp.status==200)
	{
	getObj("question").innerHTML=xmlHttp.responseText;
	}
	}	
	}
}
function checkyanma()
{
getObj("yanma").style.display='';
getObj("txtVadlitor").value='';
}
function checkyanma1()
{
getObj("yanma").style.display='none';
}
function next()
{getObj("yanma").style.display='';
getObj("vadimg").src='VerifyCode.aspx?'+(new Date().getTime());
getObj("txtVadlitor").focus();
}

