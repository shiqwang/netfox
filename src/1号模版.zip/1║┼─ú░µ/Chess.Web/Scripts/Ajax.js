﻿function ajaxFunction()
{
var xmlHttp;

try
    {
   // Firefox, Opera 8.0+, Safari
    xmlHttp=new XMLHttpRequest();
    }
catch (e)
    {

// Internet Explorer
   try
      {
      xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
      }
   catch (e)
      {
      try
         {
         xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
         }
      catch (e)
         {
         alert("您的浏览器不支持AJAX！");
         return xmlhttp=null;
         }
      }
    }
    return xmlHttp;
}
function getObj(ob)
{
	var obj=document.getElementById(ob);
	return obj;
}
function SubmitCheck(url,handler)
{
	var  Digital=new  Date();
	Digital=Digital+40000;
	url=url+"&k="+Digital;
	var xmlHttp;
	xmlHttp=ajaxFunction();
	xmlHttp.open("get", url , true)
	xmlHttp.onreadystatechange=handler;
	xmlHttp.send(null);
}
function keydown(e)
    { var currKey;
    if(e==null)
    {
    currKey=event.keyCode;
    }
    else
    {
    currKey=e.which;
    }
 
       if(currKey==13)
       {
        document.getElementById('submit').onclick();
        }
 

   }