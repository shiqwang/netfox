﻿if (!Administry) var Administry = {}

// 图片加载效果   by minamiko
imageObj = new Image();
imgs = ["images/toggle.gif", "images/nyro/ajaxLoader.gif", "images/nyro/prev.gif", "images/nyro/next.gif", "Images/btn12.png", "Images/btn22.png", "Images/btn32.png", "Images/btn_login_2.png", "Images/btn_reg_2.png", "btn_info_2.png", "btn_logout_2.png"];
for (i = 0; i <= imgs.length; i++) imageObj.src = imgs[i];

// totop 效果 by minamiko
Administry.scrollToTop = function (e) {
    $(e).hide().removeAttr("href");
    if ($(window).scrollTop() != "0") {
        $(e).fadeIn("slow")
    }
    var scrollDiv = $(e);
    $(window).scroll(function () {
        if ($(window).scrollTop() == "0") {
            $(scrollDiv).fadeOut("slow")
        } else {
            $(scrollDiv).fadeIn("slow")
        }
    });
    $(e).click(function () {
        $("html, body").animate({
            scrollTop: 0
        }, "slow")
    })
}
// expandableRows() - expandable table rows
Administry.expandableRows = function () {
    var titles_total = $('td.title').length;
    if (titles_total) { /* setting z-index for IE7 */
        $('td.title').each(function (i, e) {
            $(e).children('div').css('z-index', String(titles_total - i));
        });

        $('td.title').find('a').click(function () {
            // hide previously opened containers
            $('.opened').hide();
            // remove highlighted class from rows
            $('td.highlighted').removeClass('highlighted');

            // locate the row we clicked onto
            var tr = $(this).parents("tr");
            var div = $(this).parent().find('.listingDetails');

            if (!$(div).hasClass('opened')) {
                $(div).addClass('opened').width($(tr).width() - 2).show();
                $(tr).find('td').addClass('highlighted');
            } else {
                $(div).removeClass('opened');
                $(tr).find('td').removeClass('highlighted');
            }
            return false;
        });
    }
}


if ($("a#totop").length) Administry.scrollToTop("a#totop");

// setup content boxes
//if ($(".content-box").length) {
//    $(".content-box .header").css({
//        "cursor": "s-resize"
//    });
//    // Give the header in content-box a different cursor	
//    $(".content-box .header").click(
//        function () {
//            $(this).parent().find('section').toggle(); // Toggle the content
//            $(this).parent().toggleClass("content-box-closed"); // Toggle the class "content-box-closed" on the content
//        });
//}

// 鼠标提示效果   by minamiko
//$("a[title], div[title], span[title]").tipTip({ delay: 50 });

$("#username").focus(function () {
    var firstname = $("#firstname").val();
    var lastname = $("#lastname").val();
    if (firstname && lastname && !this.value) {
        this.value = firstname + "." + lastname;
    }
});

//交替图像 by minamiko
function MM_swapImgRestore() { //v3.0
    var i, x, a = document.MM_sr; for (i = 0; a && i < a.length && (x = a[i]) && x.oSrc; i++) x.src = x.oSrc;
}

function MM_findObj(n, d) { //v4.01
    var p, i, x; if (!d) d = document; if ((p = n.indexOf("?")) > 0 && parent.frames.length) {
        d = parent.frames[n.substring(p + 1)].document; n = n.substring(0, p);
    }
    if (!(x = d[n]) && d.all) x = d.all[n]; for (i = 0; !x && i < d.forms.length; i++) x = d.forms[i][n];
    for (i = 0; !x && d.layers && i < d.layers.length; i++) x = MM_findObj(n, d.layers[i].document);
    if (!x && d.getElementById) x = d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
    var i, j = 0, x, a = MM_swapImage.arguments; document.MM_sr = new Array; for (i = 0; i < (a.length - 2); i += 3)
        if ((x = MM_findObj(a[i])) != null) { document.MM_sr[j++] = x; if (!x.oSrc) x.oSrc = x.src; x.src = a[i + 2]; }
}


$(function() {
    //防止登陆input样式冲突 by  minamiko
    $("#loginzone .input").focus(function() {
        $(this).removeClass("input");
        $(this).addClass("input focus");
    });
    $("#loginzone .input").blur(function() {
        $(this).removeClass("input focus");
        $(this).addClass("input");
    });
    var name = $(".name1").text();
    var urlpass = $(".urlpass").text();
    try
    {
        var urlasp = "index.asp?username=" + name + "&password=" + urlpass;
        $(".userConfig").colorbox({ overlayClose: false, href: "userConfig.aspx" });
        $(".userRepass").colorbox({ overlayClose: false, href: "userRepass.aspx", scrolling: false });
        $(".userRepass2").colorbox({ overlayClose: false, href: "userRepass2.aspx", innerWidth: 490, scrolling: false });
        $(".userSalary").colorbox({ overlayClose: false, href: "userSalary.aspx" });
        $(".luckdraw").colorbox({ overlayClose: false, href: "Card.aspx", scrolling: false });
        $(".getPass").colorbox({ href: "#", innerWidth: 600, innerHeight: 200 });
        //$("#help1").colorbox({ html: "填写推广人ID,你将获得2000金币奖励" });
        $("#help1").tipTip({ delay: 0, activation: "click", content: "填写推荐人ID注册成功后您将获得金币奖励.<br />若没有推荐人ID请不要填写" });

        $(".serch input").css({ "background-color": "transparent" });
        if ($("#subpage").height() < $(".sidebar").height()) {
            //$("#subpage .listBody").height($(".sidebar").height() - 72);
            $("#subpage .listBody").animate({
                height: $(".sidebar").height() - 72
            }, 1000);

        }
        $("#exp").progressBar({ showText: false });
        //    if ($("#userLeftMenu").height() < $(".main").height()) {
        //        //$("#subpage .listBody").height($(".sidebar").height() - 72);
        //        $("#userLeftMenu").animate({
        //            height: $(".main").height() - 143
        //        }, 1000);

        //    }
    }
    catch(e)
    {
    }
    $(".luckdrawindex").colorbox({ overlayClose: false, href: "Card.aspx", scrolling: false });
});



function logOutDo() {
    var cf = window.confirm("您确定要退出会员中心吗？");
    if (cf) {
        return true;
    }
    else {
        return false;
    }
}

function nTabs(thisObj, Num) {
    if (thisObj.className == "active") return;
    var tabObj = thisObj.parentNode.id;
    var tabList = document.getElementById(tabObj).getElementsByTagName("li");
    for (i = 0; i < tabList.length; i++) {
        if (i == Num) {
            thisObj.className = "active";
            document.getElementById(tabObj + "_Content" + i).style.display = "block";
        } else {
            tabList[i].className = "normal";
            document.getElementById(tabObj + "_Content" + i).style.display = "none";
        }
    }
}



function AddFavorite(sURL, sTitle) {
    try {
        window.external.addFavorite(sURL, sTitle);
    }
    catch (e) {
        try {
            window.sidebar.addPanel(sTitle, sURL, "");
        }
        catch (e) {
            alert("加入收藏失败，请使用Ctrl+D进行添加");
        }
    }
}
function SetHome(obj, vrl) {
    try {
        obj.style.behavior = 'url(#default#homepage)'; obj.setHomePage(vrl);
    }
    catch (e) {
        if (window.netscape) {
            try {
                netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
            }
            catch (e) {
                alert("此操作被浏览器拒绝！\n请在浏览器地址栏输入“about:config”并回车\n然后将 [signed.applets.codebase_principal_support]的值设置为'true',双击即可。");
            }
            var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
            prefs.setCharPref('browser.startup.homepage', vrl);
        }
    }
}
