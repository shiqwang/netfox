﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Upload();
        }
    }
    private void Upload()
    {
        ContactModel cont = new ContactManager().GetContact();
        keywords = cont.keyword;
        description = cont.Description;
       
    }
    protected string keywords ;
    protected string description ;
    
    
}
