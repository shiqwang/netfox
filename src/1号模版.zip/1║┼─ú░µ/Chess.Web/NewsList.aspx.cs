﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;
using Wuqi.Webdiyer;
using System.Collections;

public partial class NewsList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Updata();

            Upload();

        }
    }
    private void Updata()
    {
        List<HdModel> list = new List<HdModel>();
        list = new HdManager().GetHdList();
        rptList.DataSource = PagedData(list, AspNetPager1);
        rptList.DataBind();
    }
    public static PagedDataSource PagedData(IList list, AspNetPager aspNetPager)
    {
        aspNetPager.RecordCount = list.Count;
        PagedDataSource page = new PagedDataSource();
        page.DataSource = list;
        page.AllowPaging = true;
        page.PageSize = aspNetPager.PageSize;
        page.CurrentPageIndex = aspNetPager.CurrentPageIndex - 1;

        return page;
    }
    protected void AspNetPager1_PageChanged(object sender, EventArgs e)
    {
        Updata();
    }
    private void Upload()
    {
        ContactModel cont = new ContactManager().GetContact();

        this.tit.Text = cont.Co_Name + " " + cont.Co_Url;
    }
}
