﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Chess.Models.QPGameUserDBModels;
using Chess.BLL.QPGameUserDBBLL;


public partial class UserControl_userLogin : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
            DIVXinshi();
            UserLogins();
        }
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        AccountsInfoManager am = new AccountsInfoManager();
        string strReturn = "";
        if (Session["ValidCode"] == null)
        {
            Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('验证码错误！');</script>");

            return;
        }
        if (this.txtCode.Text.Trim() == Session["ValidCode"].ToString().ToLower())
        {
            if ((strReturn = am.Login(this.txtUserName.Text.Trim(), UserMD5(this.txtPassWord.Text.Trim(), 32))) == "成功")
            {
                Session["UserName"] = this.txtUserName.Text;
                Panel1.Visible = true;
                Panel2.Visible = false;

                UserLogins();
                Response.Redirect("default.aspx");

            }
            if ((strReturn = am.Login(this.txtUserName.Text.Trim(), UserMD5(this.txtPassWord.Text.Trim(), 32))) == "密码错误")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "", "<script>alert('密码错误！');</script>");
                return;
            }
            if ((strReturn = am.Login(this.txtUserName.Text.Trim(), UserMD5(this.txtPassWord.Text.Trim(), 32))) == "无此用户")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "", "<script>alert('无此用户！');</script>");
                return;
            }
        }
        else
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "", "<script>alert('验证码错误，请输入正确的验证码！');</script>");

            return;
        }
    }
    private void UserLogins()
    {
        if (Session["UserName"] != null)
        {
            labUserName.Text = "" + Session["UserName"];
            AccountsInfoModel accountsinfomodel = new AccountsInfoManager().GetAccountsInfoByName(labUserName.Text);
            //this.Label12.Text = accountsinfomodel.RegAccounts.ToString();
            this.labGameID.Text = accountsinfomodel.GameID.ToString();
            if (accountsinfomodel.MemberOrder == 0)
            {
                this.labVip.Text = "普通会员";
            }
            if (accountsinfomodel.MemberOrder == 1)
            {
                this.labVip.Text = "红钻会员";
            }
            if (accountsinfomodel.MemberOrder == 2)
            {
                this.labVip.Text = "蓝钻会员";
            }
            if (accountsinfomodel.MemberOrder == 3)
            {
                this.labVip.Text = "黄钻会员";
            }
            if (accountsinfomodel.MemberOrder == 4)
            {
                this.labVip.Text = "紫钻会员";
            }

        }
    }
    private void DIVXinshi()
    {
        if (Session["UserName"] == null)
        {
            Panel1.Visible = false;
            Panel2.Visible = true;
        }
        else
        {
            Panel1.Visible = true;
            Panel2.Visible = false;
        }
    }
    public string UserMD5(string str, int code)
    {
        if (code == 16) //16位MD5加密（取32位加密的9~25字符） 
        {
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(str, "MD5").ToLower().Substring(8, 16);
        }
        else//32位加密 
        {
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(str, "MD5").ToLower();
        }
    }
}
