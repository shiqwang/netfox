﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Chess.BLL.QPGameUserDBBLL;
using Chess.Models.QPGameUserDBModels;
using Chess.BLL.QPTreasureDBBLL;
using Chess.Models.QPTreasureDBModels;
using System.Configuration;
using Chess.BLL.Command;
using System.Text.RegularExpressions;
using Chess.Models.QPAdminModels;
using Chess.BLL.QPAdminBLL;

public partial class findpwd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
        }
    }
    /// <summary>
    /// 是否下一步
    /// </summary>
    public bool IsNext
    {
        get {
            if (ViewState["IsNext"] != null && (bool)ViewState["IsNext"] == true)
            {
                return true;
            }
            return false;
        }
        set
        {
            ViewState["IsNext"] = value;
        }
    }
    /// <summary>
    /// 用户信息
    /// </summary>
    public AccountsInfoModel CurrentModel
    {
        get
        {
            if (ViewState["CurrentModel"] != null )
            {
                AccountsInfoModel model = (AccountsInfoModel)ViewState["CurrentModel"];
                return model;
            }
            return null;
        }
        set
        {
            ViewState["CurrentModel"] = value;
        }
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        //忘记密码
        try
        {
            ValidateAccount();
            ValidateQQ();

        }
        catch (Exception exception)
        {
            Util.Alert(this, exception.Message);
            return;
        }

        AccountsInfoManager am = new AccountsInfoManager();
        AccountsInfoModel accountsinfomodel = am.FindPwd(this.tb_loginname.Text.Trim(), this.txtQQ.Text.Trim());
        if (accountsinfomodel != null)
        {
            CurrentModel = accountsinfomodel;
            IsNext = true;
        }
        else
        {
            IsNext = false;
            Util.AlertAndRedirect(this, "帐号或QQ不正确,请重新输入！", "default.aspx");
            return;
        }
    }

    #region 验证方法

    private void ValidateAccount()
    {
        if (string.IsNullOrEmpty(tb_loginname.Text))
            throw new ApplicationException("用户名不能为空");

        //if (tb_loginname.Text.Length < 4 || tb_loginname.Text.Length > 12)
        //    throw new ApplicationException("用户名长度在2-12个字符内");

        //Regex regex = new Regex("^[0-9A-Za-z_]{4,12}$");
        //if (!regex.IsMatch(tb_loginname.Text))
        //    throw new ApplicationException("用户名必须是4-12字符内,a-z,0-9以及下划线");

        //if (accManager.IsReg(tb_loginname.Text))
        //    throw new ApplicationException("用户名已经被使用，请更换用户名");

        //if (accManager.isIP(Request.UserHostAddress))
        //    throw new ApplicationException("5分钟内只能提交一次");

        ConfineContentModel confine = new ConfineContentManager().GetConfineContentByString(tb_loginname.Text);
        if (!string.IsNullOrEmpty(confine.String))
            throw new ApplicationException("该用户名为禁用账号，不能注册");
    }
    //private void ValidateRegAccount()
    //{
    //    if (string.IsNullOrEmpty(txtRegAcc.Text)) return;

    //    Regex regex = new Regex("^[0-9A-Za-z_\u4e00-\u9fa5]{4,16}$");
    //    if (!regex.IsMatch(txtRegAcc.Text))
    //    {
    //        throw new ApplicationException("昵称4-16字符内,可以是a-z,0-9,下划线汉字");
    //    }

    //    if (accManager.HasRegAccount(txtRegAcc.Text))
    //    {
    //        throw new ApplicationException("昵称已被注册");
    //    }


    //}
    private void ValidateQQ()
    {
        if (string.IsNullOrEmpty(txtQQ.Text))
            return;

        if (Regex.Matches(@"^[1-9]\d{4,10}$", txtQQ.Text).Count > 0)
            throw new ApplicationException("QQ输入有误");
    }

    //private void ValidateCode()
    //{
    //    if (Session["ValidCode"] == null)
    //        throw new ApplicationException("验证码出错");

    //    if (string.IsNullOrEmpty(tb_code.Text))
    //        throw new ApplicationException("请输入验证码");

    //    if (tb_code.Text.ToLower() != Session["ValidCode"].ToString().ToLower())
    //        throw new ApplicationException("验证码输入错误");
    //}

    private void ValidateOtherInfo()
    {

        if (string.IsNullOrEmpty(tb_password.Text) || string.IsNullOrEmpty(tb_password2.Text))
            throw new ApplicationException("密码不能为空");

        if (tb_password.Text != tb_password2.Text)
            throw new ApplicationException("两次密码输入不一致");

        if (tb_password.Text.Length < 8)
            throw new ApplicationException("密码长度过短");

        if (!string.IsNullOrEmpty(tb_password.Text) || !string.IsNullOrEmpty(tb_password2.Text))
        {
            if (tb_password.Text != tb_password2.Text)
                throw new ApplicationException("两次输入密码不一致");
        }
    }

    #endregion

    public string UserMD5(string str, int code)
    {
        if (code == 16) //16位MD5加密（取32位加密的9~25字符） 
        {
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(str, "MD5").ToLower().Substring(8, 16);
        }
        else//32位加密 
        {
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(str, "MD5").ToLower();
        }
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {

        try
        {
            ValidateOtherInfo();

        }
        catch (Exception exception)
        {
            Util.Alert(this, exception.Message);
            return;
        }
        if (CurrentModel != null)
        {
            //更新密码
            AccountsInfoManager am = new AccountsInfoManager();
            AccountsInfoModel accountsinfomodel = CurrentModel;
            accountsinfomodel.LogonPass = UserMD5(this.tb_password.Text.Trim(), 32);
            if (am.UpdateAccountsInfo(accountsinfomodel))
            {
                Util.AlertAndRedirect(this, "密码已修改,您现在可使用新密码登录！", "default.aspx");
            }
            else
            {
                Util.AlertAndRedirect(this, "操作不成功,请联系管理员！", "findpwd.aspx");
            }
        }
        else
        {
            Util.AlertAndRedirect(this, "操作超时！", "findpwd.aspx");
        }
    }
}
